import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    // Product photos added from the admin panel can be hosted anywhere (Cloudinary, S3, Shopify CDN…)
    remotePatterns: [{ protocol: "https", hostname: "**" }],
  },
};

export default nextConfig;
