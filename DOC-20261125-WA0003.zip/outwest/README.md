# OUT WEST — Premium streetwear store

Next.js 15 (App Router) · React 19 · Tailwind CSS v4 · TypeScript

## Quick start

```bash
npm install
cp .env.example .env.local     # then edit the values
npm run dev                    # http://localhost:3000
```

Without `DATABASE_URL`, data is stored in `data/db.json` (created with 22 demo products on first request). Run `npm run reset-db` to start fresh. With `DATABASE_URL` set, Postgres is used instead.

**Admin:** go to `/admin` and sign in with `ADMIN_EMAIL` / `ADMIN_PASSWORD` from your env. If they aren't set, the demo login is `admin@outwest.in` / `outwest-admin`. To change the admin login later, update the two variables and restart or redeploy. Once you set your own, the demo login stops working.

## Deploy: Supabase + Vercel

**1. Create the database (Supabase, free tier)**
1. Sign up at supabase.com → New project. Pick the **Mumbai (ap-south-1)** region and save the database password.
2. Open **Connect** (top bar) → **Transaction pooler** and copy the connection string. It looks like
   `postgresql://postgres.xxxx:[YOUR-PASSWORD]@aws-0-ap-south-1.pooler.supabase.com:6543/postgres`.
3. Replace `[YOUR-PASSWORD]` with your password. This is your `DATABASE_URL`.

You don't need to create tables. The site creates them and adds the demo products on its first request. The tables have row level security turned on, so Supabase's public API can't read them.

**2. Put the code on GitHub**
Create a private repository and upload this folder (without `node_modules`, `.next` or `data`).

**3. Deploy on Vercel**
1. vercel.com → Add New → Project → import the repository. The framework is detected as Next.js.
2. Under **Environment Variables**, add:
   - `DATABASE_URL`: from step 1
   - `AUTH_SECRET`: a long random string (for example from `openssl rand -hex 32`)
   - `ADMIN_EMAIL` and `ADMIN_PASSWORD`: your admin login
   - `NEXT_PUBLIC_SITE_URL`: `https://yourdomain.com`
   - `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` (Supabase → Project Settings → API): needed for photo uploads
   - `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`: when ready
   - `INSTAGRAM_ACCESS_TOKEN`, `NEXT_PUBLIC_INSTAGRAM_HANDLE`: optional
3. Click **Deploy**. Open the site once to create the tables, then go to `/admin`.
4. Settings → Domains: add your domain and copy the DNS records Vercel shows into your domain registrar.

After changing any environment variable, redeploy (Deployments → ⋯ → Redeploy).

## What's included

| Area | Where |
| --- | --- |
| Animated homepage (campaign hero, categories, new arrivals, best sellers, Instagram, newsletter) | `src/app/(store)/page.tsx`, `src/components/home` |
| Shop with category, size, colour and price filters, sorting and search | `src/app/(store)/shop`, `src/components/shop` |
| Product page with gallery, colour and size selection, stock-aware sizes, size guide, PIN code delivery check | `src/app/(store)/product/[slug]`, `src/components/product` |
| Bag drawer, bag page, coupons (`WELCOME10`, `OUTWEST15`), wishlist | `src/components/layout/Overlays.tsx`, `src/app/(store)/cart` |
| Checkout with Razorpay (UPI, cards, netbanking, wallets) and Cash on Delivery | `src/app/(checkout)`, `src/components/checkout`, `src/app/api/orders`, `src/app/api/payments` |
| Customer sign-in, registration and order history | `src/app/(store)/account`, `src/app/api/auth` |
| Order tracking by order number + email or phone | `src/app/(store)/track`, `src/app/(store)/order/[number]` |
| Admin panel (see below) | `src/app/admin`, `src/components/admin`, `src/app/api/admin` |
| Instagram feed | `src/lib/server/instagram.ts`, `src/components/home/InstagramSection.tsx` |

### Admin panel (`/admin`)

- **Dashboard:** revenue with comparison to the previous period (7 days, 30 days, 90 days or all time), a daily revenue chart, online vs COD split, orders by status, top products, sales by category, low stock and recent orders.
- **Orders:** status tabs, search, payment filter, bulk status updates and CSV export. Each order page has fulfilment steps with courier and AWB, cancel & restock, internal notes, mark refunded, WhatsApp/call/email links and a printable GST invoice and packing slip.
- **Customers:** account holders and guest buyers with order count, total spent and last order, plus newsletter subscribers. Both lists export to CSV.
- **Coupons:** create percentage or flat-₹ codes with a minimum order, usage limit and expiry date. You can pause or delete them, and the panel tracks how many times each was used.
- **Products:** filter by live, hidden, low stock or sold out. Bulk publish, hide or delete, duplicate a product, export to CSV, and upload photos by drag and drop (then reorder or remove them).
- **Categories:** show or hide each category with a switch, rename it, change its tile, reorder it or add new ones. Shirts, Pants and Accessories start hidden. Their products stay saved, and shoppers can't see or buy them until you switch the category on.
- **Inventory:** edit stock for every colour and size, highlight low stock and export to CSV.
- **Settings:** shipping fee and free-shipping threshold, COD on/off with fee and limit, the low-stock alert level, homepage campaign text, announcement bar messages, business name/address/GSTIN for invoices, support contacts, admin team members and a status check of every connection.

Shared business rules live in `src/lib`: `pricing.ts` (totals and default settings), `catalog.ts` (categories and demo products), `types.ts`. Shipping, COD and coupons are edited in the admin panel and stored in the database.

## Payments (Razorpay)

1. Create an account at razorpay.com and copy your **test** keys into `RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET`.
2. Restart the dev server. Checkout now opens real Razorpay Checkout. Test UPI ID: `success@razorpay`.
3. In the Razorpay Dashboard, add a webhook pointing to `https://YOUR-DOMAIN/api/payments/razorpay/webhook` for `payment.captured`, and set `RAZORPAY_WEBHOOK_SECRET`.
4. Switch to live keys after Razorpay activates your account.

Without keys, checkout runs in **demo mode** with a simulated payment window, so you can test the full flow.

The server always recalculates prices, discounts, shipping and stock, and verifies the Razorpay signature before it marks an order as paid. Stock is reserved when a COD order is placed or a payment is captured, and returned if an order is cancelled.

## Product images

Every demo product uses a generated studio render (`src/lib/art.ts`). The renders match the selected colour and include front, back, detail and flat-lay views. To use real photography, open a product in **Admin → Products** and upload photos, or paste image URLs. The first photo is the main image and the second shows on hover. Uploads go to a public Supabase Storage bucket called `products`, which is created automatically. In local development without Supabase keys, uploads are saved to `public/uploads`.

## Instagram

Set `INSTAGRAM_ACCESS_TOKEN`, a long-lived token from the Instagram API with Instagram Login for your professional account. The homepage then shows your latest 6 posts, refreshed hourly. `NEXT_PUBLIC_INSTAGRAM_HANDLE` sets the @handle used in links.

## Before going live

- **Database:** make sure `DATABASE_URL` is set in production. Without it, the site falls back to the file store, and on Vercel that data is lost.
- **Secrets:** set a long random `AUTH_SECRET` and your own `ADMIN_EMAIL` / `ADMIN_PASSWORD`.
- **Backups:** Supabase's free plan doesn't include daily backups. Upgrade, or export the `orders` table regularly.
- **Emails/SMS:** order confirmations aren't sent yet. Hook into `insertOrder` / `markPaid` / `setOrderStatus` in `src/lib/server/orders.ts` with Resend, AWS SES or MSG91.
- **Shipping:** connect Shiprocket or Delhivery in `setOrderStatus` to create shipments and fetch AWB numbers automatically.
- **Legal:** review the copy in `src/app/(store)/help/[slug]/page.tsx` (shipping, returns, privacy, terms, contact details).
