import type { Metadata } from "next";
import Link from "next/link";
import { OrderDetail } from "@/components/order/OrderDetail";
import { getCurrentUser } from "@/lib/server/auth";
import { getOrderByNumber, publicOrder } from "@/lib/server/orders";

export const metadata: Metadata = { title: "Your order", robots: { index: false } };

export default async function OrderPage({
  params,
  searchParams,
}: {
  params: Promise<{ number: string }>;
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const { number } = await params;
  const sp = await searchParams;
  const order = await getOrderByNumber(number);
  const user = await getCurrentUser();
  const allowed = !!order && (sp.k === order.accessKey || user?.role === "admin" || (!!user && (order.userId === user.id || order.email === user.email)));

  if (!order || !allowed)
    return (
      <div className="wrap flex min-h-[60vh] flex-col items-center justify-center gap-4 py-20 text-center">
        <h1 className="display text-[40px]">Order not found</h1>
        <p className="max-w-sm text-ash">Track any order with its number and the email or phone used at checkout.</p>
        <Link href="/track" className="btn-dark">Track an order</Link>
      </div>
    );

  return (
    <div className="wrap max-w-5xl py-10 md:py-16">
      {sp.placed && (
        <div className="mb-12 bg-ink p-8 text-bone md:p-12">
          <p className="eyebrow text-bone/60">Thank you, {order.address.name.split(" ")[0]}</p>
          <h1 className="display mt-3 text-[clamp(36px,6vw,72px)]">Order confirmed.</h1>
          <p className="mt-4 max-w-lg text-bone/70">
            Your order ships within 24 hours. Save your order number <b className="text-bone">#{order.number}</b> — you can track it any time with {order.email} or your phone number.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link href="/shop" className="btn-light">Continue shopping</Link>
            {!user && <Link href="/account/register" className="btn border border-bone/30 text-bone hover:bg-bone hover:text-ink">Create account</Link>}
          </div>
        </div>
      )}
      <OrderDetail order={publicOrder(order)} />
    </div>
  );
}
