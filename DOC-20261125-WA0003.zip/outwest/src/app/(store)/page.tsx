import { HomeView } from "@/components/home/HomeView";
import { listProducts } from "@/lib/server/products";
import { getInstagramPosts } from "@/lib/server/instagram";

export default async function HomePage() {
  const [products, instagram] = await Promise.all([listProducts(), getInstagramPosts()]);
  return <HomeView products={products} instagram={instagram} />;
}
