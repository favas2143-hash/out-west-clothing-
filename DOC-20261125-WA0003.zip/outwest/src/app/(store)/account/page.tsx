import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/server/auth";
import { ordersForUser } from "@/lib/server/orders";
import { STATUS_LABEL } from "@/lib/orderStatus";
import { inr } from "@/lib/pricing";
import { SignOutButton } from "@/components/account/SignOutButton";
import { ProductArt } from "@/components/product/ProductArt";

export const metadata = { title: "My account" };

export default async function AccountPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/account/login?next=/account");
  const orders = await ordersForUser(user.id, user.email);

  return (
    <div className="wrap py-10 md:py-16">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow text-ash">My account</p>
          <h1 className="display mt-2 text-[clamp(40px,6vw,80px)]">Hi, {user.name.split(" ")[0]}</h1>
          <p className="mt-2 text-ash">{user.email}{user.phone ? ` · +91 ${user.phone}` : ""}</p>
        </div>
        <div className="flex gap-2">
          {user.role === "admin" && <Link href="/admin" className="btn-dark">Admin panel</Link>}
          <SignOutButton />
        </div>
      </div>

      <h2 className="display mb-6 mt-14 text-[30px]">My orders</h2>
      {orders.length === 0 ? (
        <div className="bg-white p-10 text-center">
          <p className="text-ash">You haven&apos;t placed any orders yet.</p>
          <Link href="/shop" className="btn-dark mt-5">Start shopping</Link>
        </div>
      ) : (
        <ul className="divide-y divide-ink/10 border-y border-ink/10">
          {orders.map((o) => (
            <li key={o.id}>
              <Link href={`/order/${o.number}`} className="flex flex-wrap items-center gap-4 py-5 hover:bg-white sm:flex-nowrap sm:px-3">
                <div className="flex -space-x-6">
                  {o.items.slice(0, 3).map((i, n) => (
                    <div key={n} className="aspect-[4/5] w-14 border-2 border-bone bg-beige"><ProductArt kind={i.kind} hex={i.hex} alt="" /></div>
                  ))}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-semibold">#{o.number}</p>
                  <p className="text-[13px] text-ash">{new Date(o.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })} · {o.items.reduce((a, b) => a + b.qty, 0)} items</p>
                </div>
                <span className="border border-ink/15 px-3 py-1 text-[12px] font-semibold uppercase tracking-[0.1em]">{STATUS_LABEL[o.status]}</span>
                <p className="w-24 text-right font-semibold">{inr(o.total)}</p>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
