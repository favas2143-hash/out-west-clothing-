"use client";

import { useState } from "react";
import type { Order } from "@/lib/types";
import { OrderDetail } from "@/components/order/OrderDetail";
import { Icon } from "@/components/ui/Icon";
import { useStore } from "@/components/providers/StoreProvider";

export default function TrackPage() {
  const { settings } = useStore();
  const [number, setNumber] = useState("");
  const [contact, setContact] = useState("");
  const [order, setOrder] = useState<Omit<Order, "accessKey"> | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    setOrder(null);
    const r = await fetch(`/api/orders/track?number=${encodeURIComponent(number.replace("#", ""))}&contact=${encodeURIComponent(contact)}`);
    const j = await r.json();
    setBusy(false);
    if (!r.ok) return setError(j.error);
    setOrder(j.order);
  };

  return (
    <div className="wrap max-w-5xl py-10 md:py-16">
      <p className="eyebrow mb-3 text-ash">Order tracking</p>
      <h1 className="display text-[clamp(40px,6vw,80px)]">Where&apos;s my order?</h1>
      <form onSubmit={submit} className="mt-8 grid gap-4 bg-white p-6 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
        <div>
          <label htmlFor="num" className="label">Order number</label>
          <input id="num" required value={number} onChange={(e) => setNumber(e.target.value.toUpperCase())} placeholder="e.g. OW240117" className="field" />
        </div>
        <div>
          <label htmlFor="contact" className="label">Email or mobile number</label>
          <input id="contact" required value={contact} onChange={(e) => setContact(e.target.value)} className="field" />
        </div>
        <button disabled={busy} className="btn-dark"><Icon name="truck" size={18} /> {busy ? "Finding…" : "Track"}</button>
      </form>
      {error && <p role="alert" className="mt-4 text-[14px] text-sale">{error}</p>}
      {order && <div className="mt-12"><OrderDetail order={order} /></div>}
      {!order && (
        <p className="mt-6 text-[14px] text-ash">Your order number is on the confirmation page and in your account under My orders. Need help? Write to {settings.supportEmail}.</p>
      )}
    </div>
  );
}
