import { Header } from "@/components/layout/Header";
import { AnnouncementBar, Footer } from "@/components/layout/Footer";
import { Overlays } from "@/components/layout/Overlays";

export default function StoreLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <AnnouncementBar />
      <Header />
      <main className="min-h-[60vh]">{children}</main>
      <Footer />
      <Overlays />
    </>
  );
}
