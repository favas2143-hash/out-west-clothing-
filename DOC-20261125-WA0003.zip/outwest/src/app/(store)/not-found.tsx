import Link from "next/link";

export default function NotFound() {
  return (
    <div className="wrap flex min-h-[60vh] flex-col items-center justify-center gap-4 py-20 text-center">
      <p className="display text-[clamp(80px,16vw,200px)] text-ink/10">404</p>
      <h1 className="display -mt-6 text-[36px]">Lost out west.</h1>
      <p className="text-ash">This page doesn&apos;t exist — but the new drop does.</p>
      <Link href="/shop?tag=new" className="btn-dark mt-2">Shop new in</Link>
    </div>
  );
}
