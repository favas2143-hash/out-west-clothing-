import type { Metadata } from "next";
import { ShopView } from "@/components/shop/ShopView";
import { categoryBySlug } from "@/lib/catalog";
import { listProducts } from "@/lib/server/products";
import { getSettings } from "@/lib/server/settings";

type SP = Promise<Record<string, string | string[] | undefined>>;
const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) ?? "";

export async function generateMetadata({ searchParams }: { searchParams: SP }): Promise<Metadata> {
  const sp = await searchParams;
  const cat = categoryBySlug(one(sp.category), (await getSettings()).categories);
  const tag = one(sp.tag);
  return { title: cat?.name ?? (tag === "new" ? "New Arrivals" : tag === "bestseller" ? "Best Sellers" : "Shop All") };
}

export default async function ShopPage({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  return (
    <ShopView
      products={await listProducts()}
      initial={{
        category: one(sp.category),
        tag: one(sp.tag),
        q: one(sp.q),
        sort: one(sp.sort) || "featured",
        size: one(sp.size),
        colour: one(sp.colour),
      }}
    />
  );
}
