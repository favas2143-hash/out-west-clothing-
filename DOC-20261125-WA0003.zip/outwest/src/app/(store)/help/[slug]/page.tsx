import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { SizeGuideInline } from "./SizeGuideInline";
import { getSettings } from "@/lib/server/settings";
import { inr } from "@/lib/pricing";

const PAGES: Record<string, { title: string; body: [string, string][] }> = {
  shipping: {
    title: "Shipping & delivery",
    body: [
      ["Dispatch", "Orders placed before 2 pm ship the same day; everything else ships within 24 hours (Mon–Sat)."],
      ["Delivery times", "Metro cities: 2–4 days. Rest of India: 4–7 days. You'll get a tracking number once your order ships."],
      ["Charges", "Free shipping on orders above {FREE}. A flat {SHIP} applies below that."],
      ["Cash on Delivery", "{COD}"],
    ],
  },
  returns: {
    title: "Returns & exchanges",
    body: [
      ["7-day window", "Return or exchange unworn items with tags within 7 days of delivery."],
      ["How to start", "Write to {EMAIL} with your order number. We'll arrange a free reverse pickup."],
      ["Refunds", "Prepaid orders are refunded to the original payment method within 5–7 business days of the return reaching us. COD orders are refunded to your bank account or UPI ID."],
      ["Exceptions", "Accessories, sale items marked final, and items without tags can't be returned."],
    ],
  },
  "size-guide": { title: "Size guide", body: [] },
  contact: {
    title: "Contact us",
    body: [
      ["Email", "{EMAIL} — we reply within one business day."],
      ["WhatsApp", "{PHONE}, Mon–Sat, 10 am–7 pm IST."],
      ["Studio", "OUT WEST, Indiranagar, Bengaluru 560038, Karnataka."],
    ],
  },
  privacy: {
    title: "Privacy policy",
    body: [
      ["What we collect", "Your name, contact details and address to deliver orders, and your order history if you create an account."],
      ["Payments", "Card, UPI and bank details are handled by Razorpay and never stored on our servers."],
      ["Your choices", "You can unsubscribe from emails at any time and ask us to delete your account by writing to {EMAIL}."],
    ],
  },
  terms: {
    title: "Terms of service",
    body: [
      ["Pricing", "All prices are in Indian Rupees and include GST. We may correct pricing errors before an order ships."],
      ["Orders", "An order is confirmed once payment is received or a COD order is verified."],
      ["Governing law", "These terms are governed by the laws of India, with courts in Bengaluru having jurisdiction."],
    ],
  },
};

type P = Promise<{ slug: string }>;

export async function generateMetadata({ params }: { params: P }): Promise<Metadata> {
  const { slug } = await params;
  return { title: PAGES[slug]?.title ?? "Help" };
}

export default async function HelpPage({ params }: { params: P }) {
  const { slug } = await params;
  const page = PAGES[slug];
  if (!page) notFound();
  const st = await getSettings();
  const fill = (t: string) =>
    t
      .replace("{FREE}", inr(st.freeShippingThreshold))
      .replace("{SHIP}", inr(st.shippingFee))
      .replace("{COD}", st.codEnabled ? `Available pan-India for orders up to ${inr(st.codMaxOrder)}, with a ${inr(st.codFee)} handling fee. Pay with cash or UPI at your door.` : "Cash on Delivery is currently paused. Pay securely online with UPI, cards or netbanking.")
      .replaceAll("{EMAIL}", st.supportEmail)
      .replace("{PHONE}", st.supportPhone);
  return (
    <div className="wrap grid gap-10 py-10 md:grid-cols-[220px_1fr] md:py-16">
      <nav className="flex flex-wrap gap-2 md:flex-col md:gap-1" aria-label="Help topics">
        {Object.entries(PAGES).map(([k, v]) => (
          <Link key={k} href={`/help/${k}`} className={`text-[14px] md:py-1.5 ${k === slug ? "font-semibold" : "text-ash hover:text-ink"} max-md:border max-md:border-ink/15 max-md:px-3 max-md:py-2`}>
            {v.title}
          </Link>
        ))}
      </nav>
      <article className="max-w-2xl">
        <h1 className="display text-[clamp(36px,5vw,64px)]">{page.title}</h1>
        {slug === "size-guide" && <div className="mt-8"><SizeGuideInline /></div>}
        <div className="mt-8 divide-y divide-ink/10 border-y border-ink/10">
          {page.body.map(([h, t]) => (
            <section key={h} className="py-6">
              <h2 className="text-[13px] font-semibold uppercase tracking-[0.14em]">{h}</h2>
              <p className="mt-2 text-[16px] leading-relaxed text-ink/75">{fill(t)}</p>
            </section>
          ))}
        </div>
      </article>
    </div>
  );
}
