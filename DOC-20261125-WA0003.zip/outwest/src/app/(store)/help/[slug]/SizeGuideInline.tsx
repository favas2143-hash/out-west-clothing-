"use client";

import { SizeGuide } from "@/components/product/SizeGuide";

export function SizeGuideInline() {
  return <SizeGuide open inline onClose={() => {}} category="oversized-t-shirts" />;
}
