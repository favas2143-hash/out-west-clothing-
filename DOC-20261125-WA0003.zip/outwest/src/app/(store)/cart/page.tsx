"use client";

import Link from "next/link";
import { computeTotals, inr } from "@/lib/pricing";
import { CouponField } from "@/components/checkout/CouponField";
import { Icon } from "@/components/ui/Icon";
import { lineKey, useStore } from "@/components/providers/StoreProvider";
import { ProductArt } from "@/components/product/ProductArt";

export default function CartPage() {
  const { cart, setQty, removeFromCart, subtotal, hydrated, toggleWishlist, settings, coupon } = useStore();
  const t = computeTotals(subtotal, { coupon, settings });
  const mrpTotal = cart.reduce((a, b) => a + b.mrp * b.qty, 0);

  if (!hydrated) return <div className="wrap min-h-[60vh] py-16" />;

  if (cart.length === 0)
    return (
      <div className="wrap flex min-h-[60vh] flex-col items-center justify-center gap-5 py-20 text-center">
        <Icon name="bag" size={44} strokeWidth={1.2} />
        <h1 className="display text-[clamp(36px,5vw,64px)]">Your bag is empty</h1>
        <p className="max-w-sm text-ash">Nothing here yet. Start with the pieces everyone&apos;s wearing this season.</p>
        <div className="flex flex-wrap justify-center gap-3">
          <Link href="/shop?tag=new" className="btn-dark">Shop new in</Link>
          <Link href="/wishlist" className="btn-line">View wishlist</Link>
        </div>
      </div>
    );

  return (
    <div className="wrap py-10 md:py-16">
      <h1 className="display mb-10 text-[clamp(40px,6vw,80px)]">Your bag</h1>
      <div className="grid gap-12 lg:grid-cols-[1fr_400px]">
        <ul className="divide-y divide-ink/10 border-y border-ink/10">
          {cart.map((i) => {
            const k = lineKey(i);
            return (
              <li key={k} className="flex gap-4 py-6 sm:gap-6">
                <Link href={`/product/${i.slug}?colour=${encodeURIComponent(i.colour)}`} className="aspect-[4/5] w-28 shrink-0 overflow-hidden bg-beige sm:w-36">
                  <ProductArt kind={i.kind} hex={i.hex} src={i.image} alt={i.name} />
                </Link>
                <div className="flex min-w-0 flex-1 flex-col">
                  <div className="flex flex-col justify-between gap-1 sm:flex-row sm:gap-4">
                    <Link href={`/product/${i.slug}`} className="text-[16px] font-medium hover:underline">{i.name}</Link>
                    <p className="whitespace-nowrap font-semibold">{inr(i.price * i.qty)} {i.mrp > i.price && <s className="ml-1 text-[13px] font-normal text-ash">{inr(i.mrp * i.qty)}</s>}</p>
                  </div>
                  <p className="mt-1 text-[14px] text-ash">Colour: {i.colour} · Size: {i.size}</p>
                  <div className="mt-auto flex flex-wrap items-center gap-4 pt-4">
                    <div className="flex h-11 items-center border border-ink/15 bg-white">
                      <button aria-label="Decrease" className="grid h-11 w-11 place-items-center" onClick={() => setQty(k, i.qty - 1)}><Icon name="minus" size={14} /></button>
                      <span className="w-6 text-center font-semibold">{i.qty}</span>
                      <button aria-label="Increase" className="grid h-11 w-11 place-items-center" onClick={() => setQty(k, i.qty + 1)}><Icon name="plus" size={14} /></button>
                    </div>
                    <button onClick={() => { toggleWishlist(i.productId); removeFromCart(k); }} className="text-[12px] uppercase tracking-[0.12em] underline-offset-4 hover:underline">Move to wishlist</button>
                    <button onClick={() => removeFromCart(k)} className="text-[12px] uppercase tracking-[0.12em] text-ash underline-offset-4 hover:text-ink hover:underline">Remove</button>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>

        <aside className="h-fit space-y-5 bg-white p-6 lg:sticky lg:top-28">
          <p className="eyebrow">Order summary</p>
          <CouponField subtotal={subtotal} />
          {t.couponError && <p className="-mt-2 text-[13px] text-sale">{t.couponError}</p>}
          <dl className="space-y-2.5 text-[15px]">
            <div className="flex justify-between"><dt>MRP total</dt><dd>{inr(mrpTotal)}</dd></div>
            <div className="flex justify-between"><dt>Discount on MRP</dt><dd className="text-sale">−{inr(mrpTotal - subtotal)}</dd></div>
            {t.discount > 0 && <div className="flex justify-between"><dt>Coupon</dt><dd className="text-sale">−{inr(t.discount)}</dd></div>}
            <div className="flex justify-between"><dt>Shipping</dt><dd>{t.shipping ? inr(t.shipping) : "Free"}</dd></div>
            <div className="flex justify-between border-t border-ink/10 pt-3 text-[18px] font-semibold"><dt>Total</dt><dd>{inr(t.total)}</dd></div>
          </dl>
          {t.toFreeShipping > 0 && <p className="bg-beige p-3 text-[13px]">Add <b>{inr(t.toFreeShipping)}</b> more for free shipping.</p>}
          <Link href="/checkout" className="btn-dark w-full"><Icon name="lock" size={16} /> Checkout securely</Link>
          <p className="text-center text-[12px] text-ash">UPI · Cards · Netbanking · Wallets{settings.codEnabled ? " · Cash on Delivery" : ""}</p>
        </aside>
      </div>
    </div>
  );
}
