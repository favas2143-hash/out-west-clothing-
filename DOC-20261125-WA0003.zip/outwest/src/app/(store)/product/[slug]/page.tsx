import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ProductView } from "@/components/product/ProductView";
import { getProduct, isOnSale, listProducts } from "@/lib/server/products";

type Params = Promise<{ slug: string }>;
type SP = Promise<Record<string, string | string[] | undefined>>;

export async function generateMetadata({ params }: { params: Params }): Promise<Metadata> {
  const { slug } = await params;
  const p = await getProduct(slug);
  if (!p) return { title: "Not found" };
  return { title: p.name, description: p.description, openGraph: { images: p.images.slice(0, 1) } };
}

export default async function ProductPage({ params, searchParams }: { params: Params; searchParams: SP }) {
  const { slug } = await params;
  const sp = await searchParams;
  const product = await getProduct(slug);
  if (!product || !(await isOnSale(product))) notFound();

  const all = (await listProducts()).filter((p) => p.id !== product.id);
  const related = [
    ...all.filter((p) => p.category === product.category),
    ...all.filter((p) => p.category !== product.category && p.tags.includes("bestseller")),
  ].slice(0, 4);

  const colour = typeof sp.colour === "string" ? sp.colour : undefined;
  return <ProductView product={product} related={related} initialColour={colour} />;
}
