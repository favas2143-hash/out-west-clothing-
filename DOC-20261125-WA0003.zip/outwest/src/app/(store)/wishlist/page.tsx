import { WishlistView } from "@/components/shop/WishlistView";
import { listProducts } from "@/lib/server/products";

export const metadata = { title: "Wishlist" };

export default async function WishlistPage() {
  return <WishlistView products={await listProducts()} />;
}
