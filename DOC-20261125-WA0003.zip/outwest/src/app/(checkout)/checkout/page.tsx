import type { Metadata } from "next";
import { CheckoutView } from "@/components/checkout/CheckoutView";
import { razorpayEnabled } from "@/lib/server/razorpay";

export const metadata: Metadata = { title: "Secure checkout", robots: { index: false } };

export default function CheckoutPage() {
  return <CheckoutView gatewayLive={razorpayEnabled()} />;
}
