import { NextResponse } from "next/server";
import { findForTracking, publicOrder } from "@/lib/server/orders";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const number = searchParams.get("number") ?? "";
  const contact = searchParams.get("contact") ?? "";
  if (!number || !contact) return NextResponse.json({ error: "Enter your order number and email or phone" }, { status: 400 });
  const o = await findForTracking(number, contact);
  if (!o) return NextResponse.json({ error: "We couldn't find an order with those details" }, { status: 404 });
  return NextResponse.json({ order: publicOrder(o) });
}
