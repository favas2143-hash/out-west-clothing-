import { NextResponse } from "next/server";
import { computeTotals, INDIAN_STATES, inr } from "@/lib/pricing";
import { getSettings } from "@/lib/server/settings";
import { checkCoupon, toApplied } from "@/lib/server/coupons";
import type { Address, OrderItem, PaymentMethod } from "@/lib/types";
import { getCurrentUser } from "@/lib/server/auth";
import { getProduct, isOnSale } from "@/lib/server/products";
import { insertOrder, ordersForUser, publicOrder, saveOrder, StockError } from "@/lib/server/orders";
import { createRazorpayOrder, razorpayEnabled, razorpayKeyId } from "@/lib/server/razorpay";

interface Body {
  items: { productId: string; colour: string; size: string; qty: number }[];
  email: string;
  address: Address;
  paymentMethod: PaymentMethod;
  coupon?: string;
}

const bad = (error: string, status = 400) => NextResponse.json({ error }, { status });

export async function POST(req: Request) {
  let body: Body;
  try {
    body = await req.json();
  } catch {
    return bad("Invalid request");
  }
  const { items, email, address, paymentMethod, coupon } = body;

  if (!Array.isArray(items) || items.length === 0) return bad("Your bag is empty");
  if (!/^\S+@\S+\.\S+$/.test(email ?? "")) return bad("Enter a valid email address");
  if (!address?.name?.trim()) return bad("Enter your full name");
  if (!/^[6-9]\d{9}$/.test((address.phone ?? "").replace(/\D/g, "").slice(-10))) return bad("Enter a valid 10-digit mobile number");
  if (!address.line1?.trim() || !address.city?.trim()) return bad("Enter your full address");
  if (!INDIAN_STATES.includes(address.state)) return bad("Select your state");
  if (!/^[1-9]\d{5}$/.test(address.pincode ?? "")) return bad("Enter a valid 6-digit PIN code");
  if (paymentMethod !== "cod" && paymentMethod !== "razorpay") return bad("Choose a payment method");

  // Prices always come from the catalogue, never from the browser
  const lines: OrderItem[] = [];
  for (const it of items) {
    const p = await getProduct(it.productId);
    const qty = Math.max(1, Math.min(10, Math.floor(Number(it.qty) || 1)));
    if (!p || !(await isOnSale(p))) return bad(`${p?.name ?? "An item in your bag"} is no longer available — please remove it from your bag`);
    const colour = p.colours.find((c) => c.name === it.colour);
    if (!colour || !p.sizes.includes(it.size)) return bad(`${p.name}: choose a valid colour and size`);
    lines.push({ productId: p.id, slug: p.slug, name: p.name, kind: p.kind, colour: colour.name, hex: colour.hex, size: it.size, qty, price: p.price });
  }
  const subtotal = lines.reduce((a, l) => a + l.price * l.qty, 0);
  const settings = await getSettings();
  let applied = null;
  if (coupon?.trim()) {
    const r = await checkCoupon(coupon, subtotal);
    if (r.error) return bad(r.error);
    applied = toApplied(r.coupon!);
  }
  const t = computeTotals(subtotal, { coupon: applied, cod: paymentMethod === "cod", settings });
  if (paymentMethod === "cod" && !settings.codEnabled) return bad("Cash on Delivery isn't available right now");
  if (paymentMethod === "cod" && t.total > settings.codMaxOrder) return bad(`Cash on Delivery is available for orders up to ${inr(settings.codMaxOrder)}`);

  const user = await getCurrentUser();
  let order: Awaited<ReturnType<typeof insertOrder>>;
  try {
    order = await insertOrder({
      userId: user?.id,
      email: email.trim().toLowerCase(),
      address: { ...address, phone: address.phone.replace(/\D/g, "").slice(-10) },
      items: lines,
      subtotal,
      discount: t.discount,
      coupon: t.coupon,
      shipping: t.shipping,
      codFee: t.codFee,
      total: t.total,
      paymentMethod,
      paymentStatus: paymentMethod === "cod" ? "cod_pending" : "pending",
      status: paymentMethod === "cod" ? "placed" : "pending_payment",
    });
  } catch (e) {
    if (e instanceof StockError) return bad(e.message, 409);
    throw e;
  }

  const res: Record<string, unknown> = { order: { number: order.number, accessKey: order.accessKey, total: order.total } };

  if (paymentMethod === "razorpay") {
    if (razorpayEnabled()) {
      try {
        const rp = await createRazorpayOrder(order.total, order.number);
        order.razorpayOrderId = rp.id;
        await saveOrder(order);
        res.razorpay = { keyId: razorpayKeyId(), orderId: rp.id, amount: rp.amount, currency: rp.currency };
      } catch (e) {
        console.error(e);
        return bad("Couldn't reach the payment gateway. Please try again or choose Cash on Delivery.", 502);
      }
    } else {
      res.demo = true;
    }
  }
  return NextResponse.json(res);
}

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return bad("Please sign in", 401);
  return NextResponse.json({ orders: (await ordersForUser(user.id, user.email)).map(publicOrder) });
}
