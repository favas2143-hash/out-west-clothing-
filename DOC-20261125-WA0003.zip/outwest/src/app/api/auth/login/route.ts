import { NextResponse } from "next/server";
import { findUserByEmail, publicUser, startSession, verifyPassword } from "@/lib/server/auth";

export async function POST(req: Request) {
  const b = (await req.json().catch(() => ({}))) as { email?: string; password?: string };
  const user = b.email ? await findUserByEmail(b.email) : null;
  if (!user || !verifyPassword(b.password ?? "", user.passwordHash)) {
    return NextResponse.json({ error: "Incorrect email or password" }, { status: 401 });
  }
  await startSession(user.id);
  return NextResponse.json({ user: publicUser(user) });
}
