import { NextResponse } from "next/server";
import { createUser, findUserByEmail, publicUser, startSession } from "@/lib/server/auth";

export async function POST(req: Request) {
  const b = (await req.json().catch(() => ({}))) as { name?: string; email?: string; phone?: string; password?: string };
  if (!b.name?.trim()) return NextResponse.json({ error: "Enter your name" }, { status: 400 });
  if (!/^\S+@\S+\.\S+$/.test(b.email ?? "")) return NextResponse.json({ error: "Enter a valid email address" }, { status: 400 });
  if (b.phone && !/^[6-9]\d{9}$/.test(b.phone.replace(/\D/g, "").slice(-10))) return NextResponse.json({ error: "Enter a valid 10-digit mobile number" }, { status: 400 });
  if ((b.password ?? "").length < 8) return NextResponse.json({ error: "Password must be at least 8 characters" }, { status: 400 });
  if (await findUserByEmail(b.email!)) return NextResponse.json({ error: "An account with this email already exists — sign in instead" }, { status: 409 });
  const user = await createUser({ name: b.name, email: b.email!, phone: b.phone, password: b.password! });
  await startSession(user.id);
  return NextResponse.json({ user: publicUser(user) });
}
