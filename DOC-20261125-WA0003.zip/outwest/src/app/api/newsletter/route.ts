import { NextResponse } from "next/server";
import { store } from "@/lib/server/db";

export async function POST(req: Request) {
  const { email } = (await req.json().catch(() => ({}))) as { email?: string };
  if (!/^\S+@\S+\.\S+$/.test(email ?? "")) return NextResponse.json({ error: "Invalid email" }, { status: 400 });
  const e = email!.trim().toLowerCase();
  const s = await store();
  if (!(await s.get("subscribers", e))) await s.put("subscribers", { id: e, email: e, at: new Date().toISOString() });
  return NextResponse.json({ ok: true });
}
