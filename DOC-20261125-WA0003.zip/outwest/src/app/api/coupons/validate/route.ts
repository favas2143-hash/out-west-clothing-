import { NextResponse } from "next/server";
import { checkCoupon, toApplied } from "@/lib/server/coupons";

export async function POST(req: Request) {
  const { code, subtotal } = (await req.json().catch(() => ({}))) as { code?: string; subtotal?: number };
  if (!code?.trim()) return NextResponse.json({ error: "Enter a code" }, { status: 400 });
  const r = await checkCoupon(code, Number(subtotal) || 0);
  if (r.error) return NextResponse.json({ error: r.error }, { status: 400 });
  return NextResponse.json({ coupon: toApplied(r.coupon!), description: r.coupon!.description });
}
