import { NextResponse } from "next/server";
import { getOrderByRazorpayId, markPaid } from "@/lib/server/orders";
import { verifyWebhookSignature } from "@/lib/server/razorpay";

/**
 * Razorpay webhook — set it up in Dashboard → Webhooks with the event `payment.captured`
 * and RAZORPAY_WEBHOOK_SECRET in your env. Catches payments where the shopper closed the tab.
 */
export async function POST(req: Request) {
  const raw = await req.text();
  const sig = req.headers.get("x-razorpay-signature") ?? "";
  if (!verifyWebhookSignature(raw, sig)) return NextResponse.json({ error: "Bad signature" }, { status: 400 });
  const evt = JSON.parse(raw) as { event: string; payload?: { payment?: { entity?: { id: string; order_id: string } } } };
  const pay = evt.payload?.payment?.entity;
  if (evt.event === "payment.captured" && pay) {
    const order = await getOrderByRazorpayId(pay.order_id);
    if (order && order.paymentStatus !== "paid") await markPaid(order.id, pay.id);
  }
  return NextResponse.json({ ok: true });
}
