import { NextResponse } from "next/server";
import { getOrderByNumber, markPaid, markPaymentFailed } from "@/lib/server/orders";
import { checkStock } from "@/lib/server/products";
import { razorpayEnabled, verifyRazorpaySignature } from "@/lib/server/razorpay";

export async function POST(req: Request) {
  const b = (await req.json().catch(() => ({}))) as {
    orderNumber?: string;
    accessKey?: string;
    razorpay_order_id?: string;
    razorpay_payment_id?: string;
    razorpay_signature?: string;
    demo?: boolean;
    fail?: boolean;
  };
  const order = b.orderNumber ? await getOrderByNumber(b.orderNumber) : null;
  if (!order || order.accessKey !== b.accessKey) return NextResponse.json({ error: "Order not found" }, { status: 404 });
  if (order.paymentStatus === "paid") return NextResponse.json({ ok: true });

  if (b.fail) {
    await markPaymentFailed(order.id);
    return NextResponse.json({ error: "Payment failed" }, { status: 402 });
  }

  if (b.demo) {
    // Demo payments are only accepted while no Razorpay keys are configured
    if (razorpayEnabled()) return NextResponse.json({ error: "Demo payments are disabled" }, { status: 403 });
    const problems = await checkStock(order.items);
    if (problems.length) return NextResponse.json({ error: problems.join("; ") }, { status: 409 });
    await markPaid(order.id, `pay_demo_${Date.now().toString(36)}`);
    return NextResponse.json({ ok: true });
  }

  const { razorpay_order_id: oid, razorpay_payment_id: pid, razorpay_signature: sig } = b;
  if (!oid || !pid || !sig || oid !== order.razorpayOrderId || !verifyRazorpaySignature(oid, pid, sig)) {
    await markPaymentFailed(order.id);
    return NextResponse.json({ error: "Payment verification failed" }, { status: 400 });
  }
  await markPaid(order.id, pid);
  return NextResponse.json({ ok: true });
}
