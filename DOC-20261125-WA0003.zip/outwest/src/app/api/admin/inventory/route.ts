import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/auth";
import { setStock } from "@/lib/server/products";

export async function PATCH(req: Request) {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  const { updates } = (await req.json()) as { updates: { productId: string; key: string; qty: number }[] };
  if (!Array.isArray(updates)) return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  await setStock(updates);
  return NextResponse.json({ ok: true, updated: updates.length });
}
