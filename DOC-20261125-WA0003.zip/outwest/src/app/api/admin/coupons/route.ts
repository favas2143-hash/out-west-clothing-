import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/auth";
import { listCoupons, saveCoupon, validateCoupon } from "@/lib/server/coupons";
import type { Coupon } from "@/lib/types";

export async function GET() {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  return NextResponse.json({ coupons: await listCoupons() });
}

export async function POST(req: Request) {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  const input = (await req.json()) as Partial<Coupon>;
  const err = validateCoupon(input);
  if (err) return NextResponse.json({ error: err }, { status: 400 });
  try {
    return NextResponse.json({ coupon: await saveCoupon(input) });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 409 });
  }
}
