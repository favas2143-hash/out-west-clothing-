import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/auth";
import { deleteCoupon, saveCoupon, validateCoupon } from "@/lib/server/coupons";
import type { Coupon } from "@/lib/types";

type Ctx = { params: Promise<{ id: string }> };

export async function PUT(req: Request, { params }: Ctx) {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  const { id } = await params;
  const input = (await req.json()) as Partial<Coupon>;
  const err = validateCoupon(input);
  if (err) return NextResponse.json({ error: err }, { status: 400 });
  try {
    return NextResponse.json({ coupon: await saveCoupon(input, id) });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 409 });
  }
}

export async function DELETE(_req: Request, { params }: Ctx) {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  const { id } = await params;
  return (await deleteCoupon(id)) ? NextResponse.json({ ok: true }) : NextResponse.json({ error: "Not found" }, { status: 404 });
}
