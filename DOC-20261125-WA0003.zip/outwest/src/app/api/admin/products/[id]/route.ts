import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/auth";
import { deleteProduct, setActive, updateProduct, validateProduct, type ProductInput } from "@/lib/server/products";

type Ctx = { params: Promise<{ id: string }> };
const unauth = () => NextResponse.json({ error: "Unauthorised" }, { status: 401 });
const notFound = () => NextResponse.json({ error: "Not found" }, { status: 404 });

export async function PUT(req: Request, { params }: Ctx) {
  if (!(await requireAdmin())) return unauth();
  const { id } = await params;
  const input = (await req.json()) as ProductInput;
  const err = validateProduct(input);
  if (err) return NextResponse.json({ error: err }, { status: 400 });
  const p = await updateProduct(id, input);
  return p ? NextResponse.json({ product: p }) : notFound();
}

/** Quick show/hide toggle from the product list */
export async function PATCH(req: Request, { params }: Ctx) {
  if (!(await requireAdmin())) return unauth();
  const { id } = await params;
  const b = (await req.json()) as { active?: boolean };
  if (typeof b.active !== "boolean") return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  const p = await setActive(id, b.active);
  return p ? NextResponse.json({ product: p }) : notFound();
}

export async function DELETE(_req: Request, { params }: Ctx) {
  if (!(await requireAdmin())) return unauth();
  const { id } = await params;
  return (await deleteProduct(id)) ? NextResponse.json({ ok: true }) : notFound();
}
