import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/auth";
import { duplicateProduct } from "@/lib/server/products";

export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  const { id } = await params;
  const p = await duplicateProduct(id);
  return p ? NextResponse.json({ product: p }) : NextResponse.json({ error: "Not found" }, { status: 404 });
}
