import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/auth";
import { createProduct, listProducts, validateProduct, type ProductInput } from "@/lib/server/products";

export async function GET() {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  return NextResponse.json({ products: await listProducts({ includeInactive: true }) });
}

export async function POST(req: Request) {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  const input = (await req.json()) as ProductInput;
  const err = validateProduct(input);
  if (err) return NextResponse.json({ error: err }, { status: 400 });
  return NextResponse.json({ product: await createProduct(input) });
}
