import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/auth";
import { deleteProduct, setActive } from "@/lib/server/products";

export async function POST(req: Request) {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  const { ids, action } = (await req.json()) as { ids?: string[]; action?: "show" | "hide" | "delete" };
  if (!Array.isArray(ids) || !ids.length || !["show", "hide", "delete"].includes(action ?? "")) return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  for (const id of ids.slice(0, 500)) {
    if (action === "delete") await deleteProduct(id);
    else await setActive(id, action === "show");
  }
  return NextResponse.json({ ok: true, count: ids.length });
}
