import fs from "fs";
import path from "path";
import crypto from "crypto";
import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/auth";

/**
 * Product photo upload.
 * - With SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY: stored in a public Supabase Storage bucket "products".
 * - Local development without them: saved to /public/uploads.
 */
const BUCKET = "products";
const TYPES: Record<string, string> = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "image/avif": "avif" };

export async function POST(req: Request) {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  const form = await req.formData();
  const file = form.get("file");
  if (!(file instanceof File)) return NextResponse.json({ error: "No file" }, { status: 400 });
  const ext = TYPES[file.type];
  if (!ext) return NextResponse.json({ error: "Use JPG, PNG, WebP or AVIF images" }, { status: 400 });
  if (file.size > 5 * 1024 * 1024) return NextResponse.json({ error: "Images must be under 5 MB" }, { status: 400 });

  const name = `${new Date().toISOString().slice(0, 7)}/${crypto.randomBytes(8).toString("hex")}.${ext}`;
  const bytes = await file.arrayBuffer();
  const url = process.env.SUPABASE_URL?.replace(/\/$/, "");
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (url && key) {
    const headers = { Authorization: `Bearer ${key}`, apikey: key };
    const put = () =>
      fetch(`${url}/storage/v1/object/${BUCKET}/${name}`, { method: "POST", headers: { ...headers, "Content-Type": file.type, "x-upsert": "true" }, body: bytes });
    let r = await put();
    if (!r.ok) {
      // first upload: create the public bucket, then retry
      await fetch(`${url}/storage/v1/bucket`, { method: "POST", headers: { ...headers, "Content-Type": "application/json" }, body: JSON.stringify({ id: BUCKET, name: BUCKET, public: true }) });
      r = await put();
    }
    if (!r.ok) return NextResponse.json({ error: `Upload failed: ${await r.text()}` }, { status: 502 });
    return NextResponse.json({ url: `${url}/storage/v1/object/public/${BUCKET}/${name}` });
  }

  if (process.env.VERCEL) return NextResponse.json({ error: "Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY to upload images, or paste an image URL." }, { status: 501 });
  const dest = path.join(process.cwd(), "public", "uploads", name);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.writeFileSync(dest, Buffer.from(bytes));
  return NextResponse.json({ url: `/uploads/${name}` });
}
