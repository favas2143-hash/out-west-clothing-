import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/auth";
import { cleanCategories, getSettings, saveSettings } from "@/lib/server/settings";
import { listProducts } from "@/lib/server/products";
import type { StoreSettings } from "@/lib/types";

export async function PUT(req: Request) {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  const input = (await req.json()) as Partial<StoreSettings>;
  if (input.supportEmail && !/^\S+@\S+\.\S+$/.test(input.supportEmail)) return NextResponse.json({ error: "Enter a valid support email" }, { status: 400 });
  if (input.categories) {
    const clean = cleanCategories(input.categories);
    if (typeof clean === "string") return NextResponse.json({ error: clean }, { status: 400 });
    // don't let a category with products disappear
    const removed = (await getSettings()).categories.filter((c) => !clean.some((n) => n.slug === c.slug));
    const products = await listProducts({ includeInactive: true });
    const blocked = removed.find((c) => products.some((p) => p.category === c.slug));
    if (blocked) return NextResponse.json({ error: `“${blocked.name}” still has products. Move or delete them first, or just hide the category.` }, { status: 409 });
  }
  return NextResponse.json({ settings: await saveSettings(input) });
}
