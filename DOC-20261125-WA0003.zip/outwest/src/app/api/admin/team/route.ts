import { NextResponse } from "next/server";
import { requireAdmin, setUserRole } from "@/lib/server/auth";

/** { email, role: "admin" | "customer" } — the person must already have an account */
export async function POST(req: Request) {
  const me = await requireAdmin();
  if (!me) return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  const { email, role } = (await req.json()) as { email?: string; role?: "admin" | "customer" };
  if (!email || (role !== "admin" && role !== "customer")) return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  if (email.trim().toLowerCase() === me.email) return NextResponse.json({ error: "You can't change your own access" }, { status: 400 });
  if (role === "customer" && email.trim().toLowerCase() === (process.env.ADMIN_EMAIL || "").toLowerCase())
    return NextResponse.json({ error: "This is the main admin from ADMIN_EMAIL. Change it in your environment settings." }, { status: 400 });
  const u = await setUserRole(email, role);
  if (!u) return NextResponse.json({ error: "No account with that email. Ask them to create one on the store first." }, { status: 404 });
  return NextResponse.json({ user: u });
}
