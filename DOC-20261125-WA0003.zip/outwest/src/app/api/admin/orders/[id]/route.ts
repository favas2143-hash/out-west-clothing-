import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/auth";
import { addOrderNote, canMoveTo, getOrderById, markRefunded, publicOrder, setOrderStatus } from "@/lib/server/orders";
import type { OrderStatus } from "@/lib/types";
import { STATUS_LABEL } from "@/lib/orderStatus";

/**
 * Body is one of:
 *  { status, note?, courier?, awb? }  — move the order along
 *  { note }                           — add an internal note
 *  { refund: true }                   — record a refund
 */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  const { id } = await params;
  const order = await getOrderById(id);
  if (!order) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const b = (await req.json()) as { status?: OrderStatus; note?: string; courier?: string; awb?: string; refund?: boolean };

  if (b.refund) {
    if (order.paymentStatus !== "paid") return NextResponse.json({ error: "Only paid orders can be refunded" }, { status: 409 });
    const o = await markRefunded(order.id, admin.name);
    return NextResponse.json({ order: o && publicOrder(o) });
  }
  if (!b.status) {
    if (!b.note?.trim()) return NextResponse.json({ error: "Write a note first" }, { status: 400 });
    const o = await addOrderNote(order.id, b.note, admin.name);
    return NextResponse.json({ order: o && publicOrder(o) });
  }
  if (!(b.status in STATUS_LABEL)) return NextResponse.json({ error: "Invalid status" }, { status: 400 });
  if (!canMoveTo(order.status, b.status))
    return NextResponse.json({ error: `Can't move an order from “${STATUS_LABEL[order.status]}” to “${STATUS_LABEL[b.status]}”` }, { status: 409 });
  const o = await setOrderStatus(order.id, b.status, b);
  return NextResponse.json({ order: o && publicOrder(o) });
}
