import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/server/auth";
import { canMoveTo, getOrderById, setOrderStatus } from "@/lib/server/orders";
import type { OrderStatus } from "@/lib/types";
import { STATUS_LABEL } from "@/lib/orderStatus";

export async function PATCH(req: Request) {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  const { ids, status } = (await req.json()) as { ids?: string[]; status?: OrderStatus };
  if (!Array.isArray(ids) || !ids.length || !status || !(status in STATUS_LABEL)) return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  let updated = 0;
  let skipped = 0;
  for (const id of ids.slice(0, 200)) {
    const o = await getOrderById(id);
    if (o && canMoveTo(o.status, status)) {
      await setOrderStatus(o.id, status);
      updated++;
    } else skipped++;
  }
  return NextResponse.json({ updated, skipped });
}
