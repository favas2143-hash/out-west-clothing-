import { listOrders, publicOrder } from "@/lib/server/orders";
import { AdminTitle } from "@/components/admin/AdminShell";
import { OrdersTable } from "@/components/admin/OrdersTable";
import type { OrderStatus } from "@/lib/types";

export default async function AdminOrders({ searchParams }: { searchParams: Promise<{ status?: string; q?: string }> }) {
  const sp = await searchParams;
  const orders = (await listOrders()).map(publicOrder);
  return (
    <div>
      <AdminTitle title="Orders" sub={`${orders.length} orders in total`} />
      <OrdersTable orders={orders} initialStatus={(sp.status as OrderStatus) || ""} initialQuery={sp.q ?? ""} />
    </div>
  );
}
