import Link from "next/link";
import { notFound } from "next/navigation";
import { getOrderById, publicOrder } from "@/lib/server/orders";
import { inr } from "@/lib/pricing";
import { STATUS_LABEL } from "@/lib/orderStatus";
import { AdminTitle } from "@/components/admin/AdminShell";
import { OrderActions, OrderNotes, RefundButton } from "@/components/admin/OrderActions";
import { Card, PaymentBadge, StatusBadge, abtnLine } from "@/components/admin/ui";
import { OrderTimeline } from "@/components/order/OrderDetail";
import { ProductArt } from "@/components/product/ProductArt";
import { Icon } from "@/components/ui/Icon";

export default async function AdminOrder({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const order = await getOrderById(id);
  if (!order) notFound();
  const o = publicOrder(order);
  const a = o.address;
  return (
    <div>
      <AdminTitle
        back={{ href: "/admin/orders", label: "Orders" }}
        title={`Order #${o.number}`}
        sub={`Placed ${new Date(o.createdAt).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" })}`}
        action={
          <>
            <Link href={`/admin/orders/${o.id}/invoice`} className={abtnLine}><Icon name="box" size={16} /> Invoice / packing slip</Link>
            {o.paymentStatus === "paid" && <RefundButton id={o.id} />}
          </>
        }
      />
      <div className="mb-6 flex flex-wrap gap-2"><StatusBadge status={o.status} /><PaymentBadge status={o.paymentStatus} /><span className="text-[13px] text-ash">{o.paymentMethod === "cod" ? "Cash on Delivery" : `Razorpay${o.razorpayPaymentId ? ` · ${o.razorpayPaymentId}` : ""}`}</span></div>

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_360px]">
        <div className="space-y-6">
          <Card title="Progress"><OrderTimeline order={o} />{o.awb && <p className="mt-6 rounded-lg bg-beige/60 p-3 text-[14px]">Shipped with <b>{o.courier || "courier"}</b> · AWB <b className="tabular-nums">{o.awb}</b></p>}</Card>

          <Card title={`Items (${o.items.reduce((x, i) => x + i.qty, 0)})`} pad={false}>
            <ul className="divide-y divide-ink/[0.06]">
              {o.items.map((i, n) => (
                <li key={n} className="flex items-center gap-4 px-5 py-3">
                  <div className="aspect-[4/5] w-12 shrink-0 overflow-hidden rounded bg-beige"><ProductArt kind={i.kind} hex={i.hex} alt="" /></div>
                  <div className="min-w-0 flex-1">
                    <Link href={`/admin/products/${i.productId}`} className="font-medium hover:underline">{i.name}</Link>
                    <p className="text-[13px] text-ash">{i.colour} · {i.size}</p>
                  </div>
                  <p className="text-[13px] text-ash tabular-nums">{inr(i.price)} × {i.qty}</p>
                  <p className="w-20 text-right font-semibold tabular-nums">{inr(i.price * i.qty)}</p>
                </li>
              ))}
            </ul>
            <dl className="space-y-1.5 border-t border-ink/[0.06] px-5 py-4 text-[14px]">
              <div className="flex justify-between"><dt className="text-ash">Subtotal</dt><dd className="tabular-nums">{inr(o.subtotal)}</dd></div>
              {o.discount > 0 && <div className="flex justify-between"><dt className="text-ash">Coupon {o.coupon}</dt><dd className="tabular-nums">−{inr(o.discount)}</dd></div>}
              <div className="flex justify-between"><dt className="text-ash">Shipping</dt><dd className="tabular-nums">{o.shipping ? inr(o.shipping) : "Free"}</dd></div>
              {o.codFee > 0 && <div className="flex justify-between"><dt className="text-ash">COD fee</dt><dd className="tabular-nums">{inr(o.codFee)}</dd></div>}
              <div className="flex justify-between pt-1 text-[16px] font-semibold"><dt>Total</dt><dd className="tabular-nums">{inr(o.total)}</dd></div>
            </dl>
          </Card>

          <Card title="Internal notes"><OrderNotes id={o.id} notes={o.notes ?? []} /></Card>

          <Card title="History">
            <ul className="space-y-2 text-[13px]">
              {[...o.timeline].reverse().map((t, i) => (
                <li key={i} className="flex gap-3"><span className="w-36 shrink-0 text-ash">{new Date(t.at).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" })}</span><span>{STATUS_LABEL[t.status]}{t.note ? ` — ${t.note}` : ""}</span></li>
              ))}
            </ul>
          </Card>
        </div>

        <div className="space-y-6">
          <OrderActions key={`${o.status}-${o.timeline.length}`} order={o} />
          <Card title="Customer">
            <p className="font-medium">{a.name}</p>
            <a href={`mailto:${o.email}`} className="mt-1 block text-[14px] underline-offset-4 hover:underline">{o.email}</a>
            <a href={`tel:+91${a.phone}`} className="block text-[14px] underline-offset-4 hover:underline">+91 {a.phone}</a>
            <a href={`https://wa.me/91${a.phone}?text=${encodeURIComponent(`Hi ${a.name.split(" ")[0]}, this is OUT WEST about your order #${o.number}.`)}`} target="_blank" rel="noreferrer" className={`${abtnLine} mt-3 w-full`}>Message on WhatsApp</a>
            <Link href={`/admin/orders?q=${encodeURIComponent(o.email)}`} className="mt-3 block text-[13px] text-ash underline underline-offset-4">All orders from this customer</Link>
          </Card>
          <Card title="Shipping address">
            <p className="text-[14px] leading-relaxed">{a.name}<br />{a.line1}{a.line2 ? <><br />{a.line2}</> : null}<br />{a.city}, {a.state} {a.pincode}<br />+91 {a.phone}</p>
          </Card>
        </div>
      </div>
    </div>
  );
}
