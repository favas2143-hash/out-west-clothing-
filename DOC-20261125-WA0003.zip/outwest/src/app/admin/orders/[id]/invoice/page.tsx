import { notFound } from "next/navigation";
import { getOrderById } from "@/lib/server/orders";
import { getSettings } from "@/lib/server/settings";
import { inr } from "@/lib/pricing";
import { AdminTitle } from "@/components/admin/AdminShell";
import { PrintButton } from "@/components/admin/PrintButton";

export default async function Invoice({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [o, st] = await Promise.all([getOrderById(id), getSettings()]);
  if (!o) notFound();
  const a = o.address;
  const date = new Date(o.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });
  return (
    <div>
      <AdminTitle back={{ href: `/admin/orders/${o.id}`, label: `Order #${o.number}` }} title="Invoice & packing slip" action={<PrintButton />} />
      <article className="mx-auto max-w-3xl bg-white p-8 text-[14px] shadow-sm print:max-w-none print:p-0 print:shadow-none sm:p-12">
        <header className="flex flex-wrap items-start justify-between gap-6 border-b border-ink pb-6">
          <div>
            <p className="display text-[32px]">{st.businessName}</p>
            <p className="mt-2 max-w-xs whitespace-pre-line text-ash">{st.businessAddress}</p>
            {st.gstin && <p className="mt-1">GSTIN: <b>{st.gstin}</b></p>}
          </div>
          <div className="text-right">
            <p className="text-[20px] font-semibold">Tax invoice</p>
            <p className="mt-1">Invoice no. <b>INV-{o.number.replace("OW", "")}</b></p>
            <p>Order <b>#{o.number}</b></p>
            <p>{date}</p>
            <p className="mt-1 text-ash">{o.paymentMethod === "cod" ? "Cash on Delivery" : "Prepaid (Razorpay)"}</p>
          </div>
        </header>
        <section className="grid gap-6 py-6 sm:grid-cols-2">
          <div>
            <p className="mb-1 text-[12px] font-semibold uppercase tracking-[0.12em] text-ash">Bill & ship to</p>
            <p className="font-medium">{a.name}</p>
            <p>{a.line1}{a.line2 ? `, ${a.line2}` : ""}</p>
            <p>{a.city}, {a.state} {a.pincode}</p>
            <p>+91 {a.phone} · {o.email}</p>
          </div>
          <div className="sm:text-right">
            <p className="mb-1 text-[12px] font-semibold uppercase tracking-[0.12em] text-ash">Place of supply</p>
            <p>{a.state}</p>
          </div>
        </section>
        <table className="w-full">
          <thead><tr className="border-y border-ink text-left text-[12px] uppercase tracking-[0.08em]"><th className="py-2">Item</th><th>Variant</th><th className="text-right">Qty</th><th className="text-right">Rate</th><th className="text-right">Amount</th></tr></thead>
          <tbody>
            {o.items.map((i, n) => (
              <tr key={n} className="border-b border-ink/10"><td className="py-2.5 pr-3">{i.name}</td><td className="pr-3">{i.colour} / {i.size}</td><td className="text-right tabular-nums">{i.qty}</td><td className="text-right tabular-nums">{inr(i.price)}</td><td className="text-right tabular-nums">{inr(i.price * i.qty)}</td></tr>
            ))}
          </tbody>
        </table>
        <dl className="ml-auto mt-4 w-full max-w-xs space-y-1.5">
          <div className="flex justify-between"><dt>Subtotal</dt><dd className="tabular-nums">{inr(o.subtotal)}</dd></div>
          {o.discount > 0 && <div className="flex justify-between"><dt>Discount {o.coupon ? `(${o.coupon})` : ""}</dt><dd className="tabular-nums">−{inr(o.discount)}</dd></div>}
          <div className="flex justify-between"><dt>Shipping</dt><dd className="tabular-nums">{o.shipping ? inr(o.shipping) : "Free"}</dd></div>
          {o.codFee > 0 && <div className="flex justify-between"><dt>COD handling</dt><dd className="tabular-nums">{inr(o.codFee)}</dd></div>}
          <div className="flex justify-between border-t border-ink pt-2 text-[16px] font-semibold"><dt>Total {o.paymentMethod === "cod" ? "to collect" : "paid"}</dt><dd className="tabular-nums">{inr(o.total)}</dd></div>
          <p className="pt-1 text-right text-[12px] text-ash">Prices are inclusive of GST.</p>
        </dl>
        <footer className="mt-10 border-t border-ink/10 pt-4 text-[12px] text-ash">
          Thank you for shopping with {st.businessName}. Returns and exchanges within 7 days of delivery — write to {st.supportEmail}. This is a computer-generated invoice.
        </footer>
      </article>
    </div>
  );
}
