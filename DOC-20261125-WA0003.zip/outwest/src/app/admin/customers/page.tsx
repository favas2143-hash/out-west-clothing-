import { listOrders } from "@/lib/server/orders";
import { listUsers } from "@/lib/server/auth";
import { store } from "@/lib/server/db";
import { AdminTitle } from "@/components/admin/AdminShell";
import { CustomersView, type CustomerRow } from "@/components/admin/CustomersView";

export default async function Customers() {
  const [orders, users, subs] = await Promise.all([listOrders(), listUsers(), (await store()).list<{ id: string; email: string; at: string }>("subscribers")]);
  const map = new Map<string, CustomerRow>();
  for (const u of users) {
    if (u.role === "admin") continue;
    map.set(u.email, { email: u.email, name: u.name, phone: u.phone, city: "", account: true, orders: 0, spent: 0, joined: u.createdAt, subscribed: false });
  }
  for (const o of [...orders].reverse()) {
    const c = map.get(o.email) ?? { email: o.email, name: o.address.name, phone: o.address.phone, city: "", account: false, orders: 0, spent: 0, joined: o.createdAt, subscribed: false };
    c.orders++;
    if (o.status !== "cancelled" && o.status !== "pending_payment" && o.paymentStatus !== "refunded") c.spent += o.total;
    c.lastOrder = o.createdAt;
    c.phone = c.phone || o.address.phone;
    c.city = `${o.address.city}, ${o.address.state}`;
    map.set(o.email, c);
  }
  for (const s of subs) {
    const c = map.get(s.email);
    if (c) c.subscribed = true;
  }
  const rows = [...map.values()].sort((a, b) => (b.lastOrder ?? b.joined).localeCompare(a.lastOrder ?? a.joined));
  return (
    <div>
      <AdminTitle title="Customers" sub={`${rows.length} customers · ${subs.length} newsletter subscribers`} />
      <CustomersView customers={rows} subscribers={subs} />
    </div>
  );
}
