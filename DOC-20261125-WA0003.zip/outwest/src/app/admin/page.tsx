import Link from "next/link";
import { STATUS_LABEL } from "@/lib/orderStatus";
import { inr } from "@/lib/pricing";
import type { Order, OrderStatus } from "@/lib/types";
import { listOrders } from "@/lib/server/orders";
import { listProducts } from "@/lib/server/products";
import { getSettings } from "@/lib/server/settings";
import { AdminTitle } from "@/components/admin/AdminShell";
import { Card, StatusBadge, abtnDark, abtnLine } from "@/components/admin/ui";
import { ProductArt } from "@/components/product/ProductArt";

const RANGES = [
  ["7", "7 days"],
  ["30", "30 days"],
  ["90", "90 days"],
  ["all", "All time"],
] as const;

const counted = (o: Order) => o.status !== "cancelled" && o.status !== "pending_payment" && o.paymentStatus !== "refunded";
const day = (d: Date) => d.toISOString().slice(0, 10);

function Delta({ now, before }: { now: number; before: number }) {
  if (!before) return null;
  const pct = Math.round(((now - before) / before) * 100);
  return <span className={`text-[12px] font-semibold ${pct >= 0 ? "text-emerald-700" : "text-rose-600"}`}>{pct >= 0 ? "▲" : "▼"} {Math.abs(pct)}%</span>;
}

export default async function AdminDashboard({ searchParams }: { searchParams: Promise<{ range?: string }> }) {
  const { range = "30" } = await searchParams;
  const [orders, products, settings] = await Promise.all([listOrders(), listProducts({ includeInactive: true }), getSettings()]);

  const days = range === "all" ? 0 : Number(range) || 30;
  const now = Date.now();
  const from = days ? now - days * 86400000 : 0;
  const prevFrom = days ? from - days * 86400000 : 0;
  const inRange = orders.filter((o) => new Date(o.createdAt).getTime() >= from);
  const prev = days ? orders.filter((o) => { const t = new Date(o.createdAt).getTime(); return t >= prevFrom && t < from; }) : [];
  const sales = inRange.filter(counted);
  const prevSales = prev.filter(counted);
  const revenue = sales.reduce((a, o) => a + o.total, 0);
  const prevRevenue = prevSales.reduce((a, o) => a + o.total, 0);
  const units = sales.reduce((a, o) => a + o.items.reduce((x, i) => x + i.qty, 0), 0);
  const customers = new Set(sales.map((o) => o.email)).size;

  // revenue per day (last N days, or last 30 for all time)
  const chartDays = days || 30;
  const series = Array.from({ length: chartDays }, (_, i) => {
    const d = new Date(now - (chartDays - 1 - i) * 86400000);
    const key = day(d);
    const list = sales.filter((o) => o.createdAt.slice(0, 10) === key);
    return { key, label: d.toLocaleDateString("en-IN", { day: "numeric", month: "short" }), value: list.reduce((a, o) => a + o.total, 0), count: list.length };
  });
  const peak = Math.max(1, ...series.map((s) => s.value));

  const byStatus = (Object.keys(STATUS_LABEL) as OrderStatus[]).map((s) => ({ s, n: orders.filter((o) => o.status === s).length })).filter((x) => x.n);
  const toFulfil = orders.filter((o) => ["placed", "confirmed", "packed"].includes(o.status));
  const cod = sales.filter((o) => o.paymentMethod === "cod").reduce((a, o) => a + o.total, 0);

  const productSales = new Map<string, { name: string; units: number; revenue: number; kind: string; hex: string }>();
  sales.forEach((o) => o.items.forEach((i) => {
    const cur = productSales.get(i.productId) ?? { name: i.name, units: 0, revenue: 0, kind: i.kind, hex: i.hex };
    cur.units += i.qty;
    cur.revenue += i.qty * i.price;
    productSales.set(i.productId, cur);
  }));
  const top = [...productSales.entries()].sort((a, b) => b[1].revenue - a[1].revenue).slice(0, 5);

  const byCat = settings.categories.filter((c) => c.active || products.some((p) => p.category === c.slug && sales.some((o) => o.items.some((i) => i.productId === p.id)))).map((c) => ({
    c,
    v: sales.reduce((a, o) => a + o.items.filter((i) => products.find((p) => p.id === i.productId)?.category === c.slug).reduce((x, i) => x + i.price * i.qty, 0), 0),
  }));
  const maxCat = Math.max(1, ...byCat.map((b) => b.v));
  const low = products.flatMap((p) => Object.entries(p.stock).filter(([, n]) => n <= settings.lowStockThreshold).map(([k, n]) => ({ p, k, n }))).sort((a, b) => a.n - b.n);

  const stats = [
    { l: "Revenue", v: inr(revenue), d: <Delta now={revenue} before={prevRevenue} />, s: `${sales.length} orders` },
    { l: "Average order", v: sales.length ? inr(revenue / sales.length) : "—", d: <Delta now={sales.length ? revenue / sales.length : 0} before={prevSales.length ? prevRevenue / prevSales.length : 0} />, s: `${units} units sold` },
    { l: "Customers", v: String(customers), d: null, s: "unique buyers" },
    { l: "To fulfil", v: String(toFulfil.length), d: null, s: "placed, confirmed or packed" },
  ];

  return (
    <div className="space-y-6">
      <AdminTitle
        title="Dashboard"
        sub={`Welcome back. Here's how OUT WEST is doing${days ? ` in the last ${days} days` : " overall"}.`}
        action={
          <>
            <div className="flex rounded-lg border border-ink/15 bg-white p-0.5">
              {RANGES.map(([k, l]) => (
                <Link key={k} href={`/admin?range=${k}`} className={`rounded-md px-3 py-1.5 text-[13px] font-medium ${range === k ? "bg-ink text-white" : "text-ash hover:text-ink"}`}>{l}</Link>
              ))}
            </div>
            <Link href="/admin/products/new" className={abtnDark}>+ Add product</Link>
          </>
        }
      />

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        {stats.map((x) => (
          <div key={x.l} className="rounded-xl border border-ink/[0.07] bg-white p-5">
            <p className="text-[13px] text-ash">{x.l}</p>
            <div className="mt-2 flex flex-wrap items-baseline gap-2">
              <p className="text-[clamp(22px,2.6vw,30px)] font-semibold tracking-tight tabular-nums">{x.v}</p>
              {x.d}
            </div>
            <p className="mt-1 text-[12px] text-ash">{x.s}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.7fr_1fr]">
        <Card title="Revenue" action={<span className="text-[13px] text-ash">{days ? `Last ${days} days` : "Last 30 days"} · peak {inr(peak === 1 ? 0 : peak)}</span>}>
          {sales.length === 0 ? (
            <p className="py-16 text-center text-[14px] text-ash">No sales in this period yet. Place a test order from the store to see it here.</p>
          ) : (
            <div>
              <div className="flex h-48 items-end gap-[2px]">
                {series.map((s) => (
                  <div key={s.key} className="group relative flex h-full min-w-0 flex-1 items-end" title={`${s.label}: ${inr(s.value)} · ${s.count} orders`}>
                    <div className="w-full rounded-t-sm bg-ink/85 transition group-hover:bg-ink" style={{ height: `${Math.max(s.value ? 3 : 0.5, (s.value / peak) * 100)}%`, opacity: s.value ? 1 : 0.15 }} />
                  </div>
                ))}
              </div>
              <div className="mt-2 flex justify-between text-[11px] text-ash">
                <span>{series[0].label}</span>
                <span>{series[Math.floor(series.length / 2)].label}</span>
                <span>{series[series.length - 1].label}</span>
              </div>
              <div className="mt-5 grid grid-cols-2 gap-3 border-t border-ink/[0.06] pt-4 text-[13px]">
                <div><p className="text-ash">Online (Razorpay)</p><p className="mt-0.5 font-semibold tabular-nums">{inr(revenue - cod)}</p></div>
                <div><p className="text-ash">Cash on Delivery</p><p className="mt-0.5 font-semibold tabular-nums">{inr(cod)}</p></div>
              </div>
            </div>
          )}
        </Card>

        <Card title="Orders by status" action={<Link href="/admin/orders" className="text-[13px] font-medium underline underline-offset-4">All orders</Link>}>
          {byStatus.length === 0 ? (
            <p className="py-10 text-center text-[14px] text-ash">No orders yet.</p>
          ) : (
            <ul className="space-y-2.5">
              {byStatus.map(({ s, n }) => (
                <li key={s}>
                  <Link href={`/admin/orders?status=${s}`} className="flex items-center justify-between rounded-lg px-2 py-1.5 hover:bg-ink/[0.03]">
                    <StatusBadge status={s} />
                    <span className="text-[14px] font-semibold tabular-nums">{n}</span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
          {toFulfil.length > 0 && <Link href="/admin/orders?status=placed" className={`${abtnDark} mt-4 w-full`}>Fulfil {toFulfil.length} order{toFulfil.length === 1 ? "" : "s"}</Link>}
        </Card>
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        <Card title="Top products" className="xl:col-span-1">
          {top.length === 0 ? <p className="text-[14px] text-ash">Sales will show here.</p> : (
            <ul className="space-y-3">
              {top.map(([id, t], i) => (
                <li key={id} className="flex items-center gap-3">
                  <span className="w-4 text-[12px] font-semibold text-ash">{i + 1}</span>
                  <div className="aspect-[4/5] w-9 shrink-0 overflow-hidden rounded bg-beige"><ProductArt kind={t.kind as never} hex={t.hex} alt="" /></div>
                  <div className="min-w-0 flex-1"><p className="truncate text-[14px] font-medium">{t.name}</p><p className="text-[12px] text-ash">{t.units} sold</p></div>
                  <p className="text-[14px] font-semibold tabular-nums">{inr(t.revenue)}</p>
                </li>
              ))}
            </ul>
          )}
        </Card>
        <Card title="Sales by category">
          <ul className="space-y-3">
            {byCat.map(({ c, v }) => (
              <li key={c.slug}>
                <div className="flex justify-between text-[13px]"><span>{c.name}</span><span className="tabular-nums">{inr(v)}</span></div>
                <div className="mt-1 h-2 overflow-hidden rounded-full bg-ink/[0.06]"><div className="h-full rounded-full bg-ink" style={{ width: `${(v / maxCat) * 100}%` }} /></div>
              </li>
            ))}
          </ul>
        </Card>
        <Card title="Low stock" action={<Link href="/admin/inventory?low=1" className="text-[13px] font-medium underline underline-offset-4">Restock</Link>}>
          {low.length === 0 ? <p className="text-[14px] text-ash">Everything is well stocked.</p> : (
            <ul className="space-y-2">
              {low.slice(0, 7).map(({ p, k, n }) => (
                <li key={p.id + k} className="flex items-center justify-between gap-3 text-[13px]">
                  <span className="truncate">{p.name} <span className="text-ash">· {k.replace("__", " / ")}</span></span>
                  <span className={`shrink-0 font-semibold ${n === 0 ? "text-rose-600" : "text-amber-700"}`}>{n === 0 ? "Sold out" : `${n} left`}</span>
                </li>
              ))}
              {low.length > 7 && <li className="pt-1 text-[12px] text-ash">+{low.length - 7} more variants</li>}
            </ul>
          )}
        </Card>
      </div>

      <Card title="Recent orders" pad={false} action={<Link href="/admin/orders" className={abtnLine}>View all</Link>}>
        {orders.length === 0 ? <p className="p-10 text-center text-[14px] text-ash">No orders yet.</p> : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-[14px]">
              <thead><tr className="text-left text-[12px] text-ash"><th className="px-5 py-3 font-medium">Order</th><th className="font-medium">Customer</th><th className="font-medium">Date</th><th className="font-medium">Status</th><th className="px-5 text-right font-medium">Total</th></tr></thead>
              <tbody>
                {orders.slice(0, 8).map((o) => (
                  <tr key={o.id} className="border-t border-ink/[0.06] hover:bg-ink/[0.02]">
                    <td className="px-5 py-3"><Link href={`/admin/orders/${o.id}`} className="font-semibold hover:underline">#{o.number}</Link></td>
                    <td>{o.address.name}</td>
                    <td className="text-ash">{new Date(o.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}</td>
                    <td><StatusBadge status={o.status} /></td>
                    <td className="px-5 text-right font-semibold tabular-nums">{inr(o.total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
