import type { Metadata } from "next";
import Link from "next/link";
import { getCurrentUser } from "@/lib/server/auth";
import { listOrders } from "@/lib/server/orders";
import { listProducts } from "@/lib/server/products";
import { getSettings } from "@/lib/server/settings";
import { AdminShell } from "@/components/admin/AdminShell";
import { Toasts } from "@/components/layout/Overlays";

export const metadata: Metadata = { title: "Admin", robots: { index: false } };

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  if (!user || user.role !== "admin")
    return (
      <div className="grid min-h-screen place-items-center bg-ink p-6 text-bone">
        <div className="max-w-sm text-center">
          <p className="display text-[40px]">OUT WEST</p>
          <p className="mt-3 text-bone/70">{user ? "Your account doesn't have admin access." : "Sign in with an admin account to manage products, stock and orders."}</p>
          <Link href="/account/login?next=/admin" className="btn-light mt-6 w-full">Admin sign in</Link>
          <Link href="/" className="mt-4 block text-[13px] text-bone/60 hover:text-bone">← Back to store</Link>
        </div>
      </div>
    );
  const [orders, products, settings] = await Promise.all([listOrders(), listProducts({ includeInactive: true }), getSettings()]);
  const toFulfil = orders.filter((o) => ["placed", "confirmed", "packed"].includes(o.status)).length;
  const lowStock = products.reduce((a, p) => a + Object.values(p.stock).filter((n) => n <= settings.lowStockThreshold).length, 0);
  return (
    <AdminShell name={user.name} toFulfil={toFulfil} lowStock={lowStock}>
      {children}
      <Toasts />
    </AdminShell>
  );
}
