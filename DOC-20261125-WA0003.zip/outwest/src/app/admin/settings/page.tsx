import { getCurrentUser, listUsers } from "@/lib/server/auth";
import { getSettings } from "@/lib/server/settings";
import { razorpayEnabled } from "@/lib/server/razorpay";
import { AdminTitle } from "@/components/admin/AdminShell";
import { SettingsForm } from "@/components/admin/SettingsForm";

export default async function Settings() {
  const [settings, users, me] = await Promise.all([getSettings(), listUsers(), getCurrentUser()]);
  const integrations = [
    { name: "Database", ok: !!process.env.DATABASE_URL, on: "Connected to Postgres (Supabase)", off: "Using local file storage — set DATABASE_URL before going live" },
    { name: "Razorpay payments", ok: razorpayEnabled(), on: `Live keys connected${process.env.RAZORPAY_KEY_ID?.startsWith("rzp_test") ? " (test mode)" : ""}`, off: "Demo mode — add RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET" },
    { name: "Razorpay webhook", ok: !!process.env.RAZORPAY_WEBHOOK_SECRET, on: "Webhook secret set", off: "Add RAZORPAY_WEBHOOK_SECRET" },
    { name: "Photo uploads", ok: !!(process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY), on: "Supabase Storage connected", off: "Add SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY (local dev saves to /public/uploads)" },
    { name: "Instagram feed", ok: !!process.env.INSTAGRAM_ACCESS_TOKEN, on: "Showing your latest posts", off: "Add INSTAGRAM_ACCESS_TOKEN to show real posts" },
    { name: "Login security", ok: !!process.env.AUTH_SECRET && !!process.env.ADMIN_PASSWORD, on: "AUTH_SECRET and admin password set", off: "Set AUTH_SECRET, ADMIN_EMAIL and ADMIN_PASSWORD" },
  ];
  return (
    <div>
      <AdminTitle title="Settings" sub="Shipping, payments, homepage content, invoices and your team" />
      <SettingsForm settings={settings} admins={users.filter((u) => u.role === "admin")} meEmail={me?.email ?? ""} integrations={integrations} />
    </div>
  );
}
