import { listCoupons } from "@/lib/server/coupons";
import { AdminTitle } from "@/components/admin/AdminShell";
import { CouponsView } from "@/components/admin/CouponsView";

export default async function Coupons() {
  const coupons = await listCoupons();
  return (
    <div>
      <AdminTitle title="Coupons" sub="Discount codes shoppers enter in the bag or at checkout" />
      <CouponsView coupons={coupons} />
    </div>
  );
}
