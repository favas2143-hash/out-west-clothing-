import Link from "next/link";
import { listProducts } from "@/lib/server/products";
import { getSettings } from "@/lib/server/settings";
import { AdminTitle } from "@/components/admin/AdminShell";
import { ProductTable } from "@/components/admin/ProductTable";
import { abtnDark } from "@/components/admin/ui";

export default async function AdminProducts() {
  const [products, st] = await Promise.all([listProducts({ includeInactive: true }), getSettings()]);
  return (
    <div>
      <AdminTitle title="Products" sub={`${products.length} products · ${products.filter((p) => p.active).length} live`} action={<Link href="/admin/products/new" className={abtnDark}>+ Add product</Link>} />
      <ProductTable products={products} lowAt={st.lowStockThreshold} />
    </div>
  );
}
