import { notFound } from "next/navigation";
import { getProduct } from "@/lib/server/products";
import { AdminTitle } from "@/components/admin/AdminShell";
import { ProductForm } from "@/components/admin/ProductForm";

export default async function EditProduct({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const product = await getProduct(id);
  if (!product) notFound();
  return (
    <div>
      <AdminTitle back={{ href: "/admin/products", label: "Products" }} title={product.name} sub={product.active ? "Live in store" : "Hidden from store"} />
      <ProductForm product={product} />
    </div>
  );
}
