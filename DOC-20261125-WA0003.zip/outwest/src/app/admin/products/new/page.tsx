import { AdminTitle } from "@/components/admin/AdminShell";
import { ProductForm } from "@/components/admin/ProductForm";

export default function NewProduct() {
  return (
    <div>
      <AdminTitle back={{ href: "/admin/products", label: "Products" }} title="New product" />
      <ProductForm />
    </div>
  );
}
