import { listProducts } from "@/lib/server/products";
import { getSettings } from "@/lib/server/settings";
import { AdminTitle } from "@/components/admin/AdminShell";
import { InventoryView } from "@/components/admin/InventoryView";

export default async function InventoryPage({ searchParams }: { searchParams: Promise<{ low?: string }> }) {
  const { low } = await searchParams;
  const [products, st] = await Promise.all([listProducts({ includeInactive: true }), getSettings()]);
  return (
    <div>
      <AdminTitle title="Inventory" sub="Edit stock for every colour and size, then save." />
      <InventoryView products={products} lowOnly={!!low} lowAt={st.lowStockThreshold} />
    </div>
  );
}
