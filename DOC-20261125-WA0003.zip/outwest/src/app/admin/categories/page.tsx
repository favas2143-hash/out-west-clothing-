import { listProducts } from "@/lib/server/products";
import { getSettings } from "@/lib/server/settings";
import { AdminTitle } from "@/components/admin/AdminShell";
import { CategoriesManager } from "@/components/admin/CategoriesManager";

export default async function Categories() {
  const [settings, products] = await Promise.all([getSettings(), listProducts({ includeInactive: true })]);
  const counts: Record<string, number> = {};
  products.forEach((p) => (counts[p.category] = (counts[p.category] ?? 0) + 1));
  return (
    <div>
      <AdminTitle title="Categories" sub="Choose which categories shoppers see. Hidden categories keep their products — switch them on whenever you're ready." />
      <CategoriesManager categories={settings.categories} counts={counts} />
    </div>
  );
}
