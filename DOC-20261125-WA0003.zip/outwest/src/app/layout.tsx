import type { Metadata, Viewport } from "next";
import { Archivo, Inter_Tight } from "next/font/google";
import "./globals.css";
import { StoreProvider, type IndexItem } from "@/components/providers/StoreProvider";
import { listProducts } from "@/lib/server/products";
import { getCurrentUser, publicUser } from "@/lib/server/auth";
import { getSettings } from "@/lib/server/settings";

const archivo = Archivo({ subsets: ["latin"], axes: ["wdth"], variable: "--font-archivo", display: "swap" });
const inter = Inter_Tight({ subsets: ["latin"], variable: "--font-inter", display: "swap" });

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"),
  title: { default: "OUT WEST — Premium Streetwear, Made in India", template: "%s · OUT WEST" },
  description:
    "OUT WEST makes premium streetwear in India: heavyweight oversized tees, 400 GSM hoodies, cargos and accessories. Free shipping above ₹1,999, COD available.",
  openGraph: { siteName: "OUT WEST", type: "website", locale: "en_IN" },
};

export const viewport: Viewport = { themeColor: "#0b0b0b", width: "device-width", initialScale: 1 };

export const dynamic = "force-dynamic";

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const index: IndexItem[] = (await listProducts()).map((p) => ({
    id: p.id,
    slug: p.slug,
    name: p.name,
    category: p.category,
    kind: p.kind,
    hex: p.colours[0]?.hex ?? "#111111",
    price: p.price,
    mrp: p.mrp,
    image: p.images[0],
  }));
  const [user, settings] = await Promise.all([getCurrentUser(), getSettings()]);

  return (
    <html lang="en-IN" className={`${archivo.variable} ${inter.variable}`}>
      <body>
        <StoreProvider index={index} initialUser={user ? publicUser(user) : null} settings={settings}>
          {children}
        </StoreProvider>
      </body>
    </html>
  );
}
