/** Shared between client and server so the totals a shopper sees are the totals they pay. */
import type { AppliedCoupon, StoreSettings } from "./types";
import { CATEGORIES } from "./catalog";

export const DEFAULT_SETTINGS: StoreSettings = {
  id: "store",
  shippingFee: 99,
  freeShippingThreshold: 1999,
  codEnabled: true,
  codFee: 49,
  codMaxOrder: 7500,
  announcements: [
    "Free shipping on orders above ₹1,999",
    "Cash on Delivery available",
    "7-day easy returns & exchanges",
    "Use WELCOME10 for 10% off your first order",
  ],
  heroEyebrow: "Fall / Winter 2026 · Drop 04",
  heroTitle: "Concrete Season",
  heroText: "Heavyweight fleece, boxy tees and utility cargos cut in stone, shadow and bone. Built for cities that never cool down.",
  supportEmail: "support@outwest.in",
  supportPhone: "+91 90000 00000",
  lowStockThreshold: 3,
  categories: CATEGORIES,
  businessName: "OUT WEST",
  businessAddress: "Indiranagar, Bengaluru 560038, Karnataka",
  gstin: "",
};

export function inr(n: number) {
  return "₹" + Math.round(n).toLocaleString("en-IN");
}

export function couponLabel(c: AppliedCoupon) {
  const off = c.type === "percent" ? `${c.value}% off` : `${inr(c.value)} off`;
  return c.minOrder > 0 ? `${off} orders above ${inr(c.minOrder)}` : off;
}

export function computeTotals(
  subtotal: number,
  opts: { coupon?: AppliedCoupon | null; cod?: boolean; settings?: StoreSettings } = {},
) {
  const st = opts.settings ?? DEFAULT_SETTINGS;
  const c = opts.coupon;
  const couponValid = !!c && subtotal >= c.minOrder;
  const raw = !couponValid ? 0 : c!.type === "percent" ? (subtotal * c!.value) / 100 : c!.value;
  const discount = Math.min(subtotal, Math.round(raw));
  const afterDiscount = subtotal - discount;
  const shipping = subtotal === 0 || afterDiscount >= st.freeShippingThreshold ? 0 : st.shippingFee;
  const codFee = opts.cod ? st.codFee : 0;
  return {
    subtotal,
    discount,
    coupon: couponValid ? c!.code : undefined,
    couponError: c && !couponValid ? `Minimum order ${inr(c.minOrder)}` : undefined,
    shipping,
    codFee,
    total: afterDiscount + shipping + codFee,
    toFreeShipping: Math.max(0, st.freeShippingThreshold - afterDiscount),
  };
}

export const INDIAN_STATES = [
  "Andaman and Nicobar Islands", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chandigarh",
  "Chhattisgarh", "Dadra and Nagar Haveli and Daman and Diu", "Delhi", "Goa", "Gujarat", "Haryana",
  "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand", "Karnataka", "Kerala", "Ladakh", "Lakshadweep",
  "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Puducherry",
  "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand",
  "West Bengal",
];

/** Rough delivery estimate from the first digit of the PIN code (postal zone). */
export function deliveryEstimate(pincode: string) {
  if (!/^[1-9][0-9]{5}$/.test(pincode)) return null;
  const zone = +pincode[0];
  const days = [5, 4, 4, 3, 3, 3, 3, 5, 6, 6][zone] ?? 5;
  const d = new Date();
  d.setDate(d.getDate() + days);
  return {
    days,
    date: d.toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" }),
  };
}
