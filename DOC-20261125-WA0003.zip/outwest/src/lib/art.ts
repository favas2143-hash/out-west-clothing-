/**
 * OUT WEST studio renders.
 * Generates colour-accurate SVG product imagery (front / back / detail / flat-lay)
 * so the demo catalogue looks consistent before real photography is uploaded.
 * Replace by adding photo URLs to a product's `images` in the admin panel.
 */
import type { ArtView, GarmentKind } from "./types";

type RGB = [number, number, number];

function hexToRgb(hex: string): RGB {
  const h = hex.replace("#", "");
  const n = parseInt(h.length === 3 ? h.split("").map((c) => c + c).join("") : h, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function rgbToHex([r, g, b]: RGB) {
  return "#" + [r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, "0")).join("");
}

/** amt > 0 lightens towards white, amt < 0 darkens towards black */
export function shade(hex: string, amt: number) {
  const rgb = hexToRgb(hex);
  return rgbToHex(rgb.map((v) => (amt >= 0 ? v + (255 - v) * amt : v * (1 + amt))) as RGB);
}

export function isDark(hex: string) {
  const [r, g, b] = hexToRgb(hex);
  return 0.299 * r + 0.587 * g + 0.114 * b < 140;
}

const WORD = "font-family=\"Archivo, 'Arial Black', sans-serif\" font-weight=\"800\" font-stretch=\"125%\"";

interface Shape {
  body: string;
  /** drawn on top of the body: seams, collars, pockets */
  front: (c: Pal) => string;
  back: (c: Pal) => string;
  chest: [number, number]; // print anchor
  backPrint: [number, number, number]; // x, y, size
  floor: number;
  detailBox: string;
}

interface Pal {
  base: string;
  dark: string;
  darker: string;
  light: string;
  ink: string;
  stitch: string;
  id: string;
}

const stitch = (d: string, c: Pal) =>
  `<path d="${d}" fill="none" stroke="${c.stitch}" stroke-width="1.6" stroke-dasharray="5 4" opacity=".7"/>`;
const fold = (d: string, o = 0.13) =>
  `<path d="${d}" fill="none" stroke="#000" stroke-width="3" stroke-linecap="round" opacity="${o}"/>`;
const line = (d: string, col: string, w = 2) =>
  `<path d="${d}" fill="none" stroke="${col}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round"/>`;

const TEE: Shape = {
  body: "M232 150 C262 172 338 172 368 150 L452 178 L522 290 L462 322 L440 280 L446 620 C350 632 250 632 154 620 L160 280 L138 322 L78 290 L148 178 Z",
  front: (c) =>
    `<path d="M236 150 C266 138 334 138 364 150 C334 166 266 166 236 150 Z" fill="${c.darker}"/>` +
    `<path d="M232 150 C262 190 338 190 368 150 L358 152 C330 176 270 176 242 152 Z" fill="${c.dark}"/>` +
    line("M148 178 Q154 232 160 280", c.dark) + line("M452 178 Q446 232 440 280", c.dark) +
    stitch("M86 302 L140 330", c) + stitch("M514 302 L460 330", c) + stitch("M158 606 C250 618 350 618 442 606", c) +
    fold("M200 330 C210 420 196 500 206 590") + fold("M396 360 C390 450 404 520 396 600", 0.1),
  back: (c) =>
    `<path d="M236 150 C266 160 334 160 364 150 L358 156 C330 166 270 166 242 156 Z" fill="${c.dark}"/>` +
    line("M148 178 Q154 232 160 280", c.dark) + line("M452 178 Q446 232 440 280", c.dark) +
    stitch("M158 606 C250 618 350 618 442 606", c),
  chest: [300, 250],
  backPrint: [300, 300, 46],
  floor: 650,
  detailBox: "180 130 240 300",
};

const OVERSIZED: Shape = {
  body: "M226 140 C260 164 340 164 374 140 L474 168 L552 332 L478 362 L462 318 L468 642 C350 654 250 654 132 642 L138 318 L122 362 L48 332 L126 168 Z",
  front: (c) =>
    `<path d="M230 140 C262 128 338 128 370 140 C338 158 262 158 230 140 Z" fill="${c.darker}"/>` +
    `<path d="M226 140 C258 186 342 186 374 140 L362 142 C334 170 266 170 238 142 Z" fill="${c.dark}"/>` +
    line("M126 168 Q120 250 138 318", c.dark) + line("M474 168 Q480 250 462 318", c.dark) +
    stitch("M56 344 L124 374", c) + stitch("M544 344 L476 374", c) + stitch("M136 628 C250 640 350 640 464 628", c) +
    fold("M190 340 C204 430 186 520 200 620") + fold("M410 330 C398 430 414 520 402 620", 0.1) + fold("M300 420 C296 480 306 540 300 610", 0.06),
  back: (c) =>
    `<path d="M230 140 C262 152 338 152 370 140 L362 148 C334 160 266 160 238 148 Z" fill="${c.dark}"/>` +
    line("M126 168 Q120 250 138 318", c.dark) + line("M474 168 Q480 250 462 318", c.dark) +
    stitch("M136 628 C250 640 350 640 464 628", c),
  chest: [300, 248],
  backPrint: [300, 300, 56],
  floor: 672,
  detailBox: "170 120 260 325",
};

const HOODIE: Shape = {
  body: "M232 168 C262 188 338 188 368 168 L458 190 Q500 222 515 332 L545 550 L496 562 L462 362 L462 602 L138 602 L138 362 L104 562 L55 550 L85 332 Q100 222 142 190 Z",
  front: (c) =>
    `<path d="M210 178 C202 96 254 54 300 54 C346 54 398 96 390 178 C360 152 240 152 210 178 Z" fill="${c.dark}"/>` +
    `<path d="M244 176 C248 124 274 102 300 102 C326 102 352 124 356 176 C330 198 270 198 244 176 Z" fill="${c.darker}"/>` +
    `<path d="M232 168 C246 206 284 212 300 196 C316 212 354 206 368 168 C350 192 318 196 300 184 C282 196 250 192 232 168 Z" fill="${c.base}"/>` +
    line("M278 196 L272 300", c.light, 4) + line("M322 196 L328 300", c.light, 4) +
    `<rect x="267" y="298" width="9" height="16" rx="2" fill="${c.ink}" opacity=".8"/><rect x="324" y="298" width="9" height="16" rx="2" fill="${c.ink}" opacity=".8"/>` +
    `<path d="M196 468 L404 468 L432 588 L168 588 Z" fill="${c.base}"/>` +
    line("M196 468 L404 468", c.dark, 2) + line("M196 468 L172 588", c.darker, 3) + line("M404 468 L428 588", c.darker, 3) +
    `<path d="M138 602 L462 602 L460 644 C350 652 250 652 140 644 Z" fill="${c.dark}"/>` +
    `<path d="M496 562 L545 550 L551 590 L502 600 Z" fill="${c.dark}"/><path d="M104 562 L55 550 L49 590 L98 600 Z" fill="${c.dark}"/>` +
    line("M142 190 Q150 280 138 362", c.dark) + line("M458 190 Q450 280 462 362", c.dark) +
    fold("M110 400 C118 460 104 500 112 540", 0.12) + fold("M490 400 C482 460 496 500 488 540", 0.12) + fold("M220 330 C230 380 212 420 222 460", 0.1),
  back: (c) =>
    `<path d="M212 180 C194 118 240 70 300 66 C360 70 406 118 388 180 C402 252 362 304 300 312 C238 304 198 252 212 180 Z" fill="${c.base}" stroke="${c.dark}" stroke-width="3"/>` +
    fold("M232 200 C240 250 262 280 300 296", 0.08) + line("M300 70 L300 310", c.dark, 2) +
    `<path d="M138 602 L462 602 L460 644 C350 652 250 652 140 644 Z" fill="${c.dark}"/>` +
    `<path d="M496 562 L545 550 L551 590 L502 600 Z" fill="${c.dark}"/><path d="M104 562 L55 550 L49 590 L98 600 Z" fill="${c.dark}"/>` +
    line("M142 190 Q150 280 138 362", c.dark) + line("M458 190 Q450 280 462 362", c.dark),
  chest: [300, 380],
  backPrint: [300, 410, 52],
  floor: 676,
  detailBox: "170 120 260 325",
};

const SHIRT: Shape = {
  body: "M238 150 C268 160 332 160 362 150 L455 178 Q492 205 505 300 L530 560 L486 572 L462 330 L462 625 C380 642 340 628 300 642 C260 628 220 642 138 625 L138 330 L114 572 L70 560 L95 300 Q108 205 145 178 Z",
  front: (c) => {
    const buttons = [236, 306, 376, 446, 516, 586]
      .map((y) => `<circle cx="300" cy="${y}" r="5.5" fill="${c.darker}"/><circle cx="300" cy="${y}" r="2" fill="${c.base}"/>`)
      .join("");
    return (
      `<path d="M238 150 C268 138 332 138 362 150 L300 190 Z" fill="${c.darker}"/>` +
      `<path d="M238 150 L300 190 L262 226 L222 162 Z" fill="${c.light}"/><path d="M362 150 L300 190 L338 226 L378 162 Z" fill="${c.base}"/>` +
      line("M238 150 L300 190 L262 226 L222 162 Z", c.dark, 1.6) + line("M362 150 L300 190 L338 226 L378 162 Z", c.dark, 1.6) +
      line("M291 196 L291 636", c.dark, 1.5) + line("M309 196 L309 636", c.dark, 1.5) + buttons +
      `<path d="M344 248 L404 248 L404 316 L374 326 L344 316 Z" fill="none" stroke="${c.dark}" stroke-width="1.8"/>` +
      `<path d="M486 572 L530 560 L535 604 L491 614 Z" fill="${c.dark}"/><path d="M114 572 L70 560 L65 604 L109 614 Z" fill="${c.dark}"/>` +
      line("M145 178 Q150 260 138 330", c.dark) + line("M455 178 Q450 260 462 330", c.dark) +
      fold("M200 360 C212 440 198 520 210 600") + fold("M400 360 C390 440 404 520 394 600", 0.1) + fold("M90 380 C100 440 92 500 98 540", 0.1)
    );
  },
  back: (c) =>
    `<path d="M238 150 C268 162 332 162 362 150 L358 166 C330 176 270 176 242 166 Z" fill="${c.dark}"/>` +
    line("M190 196 C240 214 360 214 410 196", c.dark, 1.6) + line("M300 200 L300 236", c.dark, 1.6) +
    `<path d="M486 572 L530 560 L535 604 L491 614 Z" fill="${c.dark}"/><path d="M114 572 L70 560 L65 604 L109 614 Z" fill="${c.dark}"/>`,
  chest: [372, 290],
  backPrint: [300, 330, 44],
  floor: 668,
  detailBox: "180 120 240 300",
};

const PANTS: Shape = {
  body: "M172 112 L428 112 L432 150 L456 652 L330 652 L304 304 L296 304 L270 652 L144 652 L168 150 Z",
  front: (c) =>
    `<path d="M172 112 L428 112 L431 148 L169 148 Z" fill="${c.dark}"/>` +
    [200, 262, 338, 400].map((x) => `<rect x="${x - 5}" y="108" width="10" height="44" rx="2" fill="${c.base}" stroke="${c.dark}" stroke-width="1.4"/>`).join("") +
    `<circle cx="300" cy="130" r="6" fill="${c.darker}"/>` +
    line("M304 150 Q306 232 318 268", c.dark, 2) +
    line("M176 156 Q214 196 206 250", c.dark, 2) + line("M424 156 Q386 196 394 250", c.dark, 2) +
    fold("M232 160 L214 640", 0.12) + fold("M368 160 L386 640", 0.12) +
    stitch("M148 636 L268 636", c) + stitch("M332 636 L452 636", c),
  back: (c) =>
    `<path d="M172 112 L428 112 L431 148 L169 148 Z" fill="${c.dark}"/>` +
    `<path d="M196 178 L272 178 L268 248 L232 258 L200 248 Z" fill="none" stroke="${c.dark}" stroke-width="2"/>` +
    `<path d="M328 178 L404 178 L400 248 L368 258 L332 248 Z" fill="none" stroke="${c.dark}" stroke-width="2"/>` +
    line("M300 150 L300 300", c.dark, 2) +
    stitch("M148 636 L268 636", c) + stitch("M332 636 L452 636", c),
  chest: [212, 200],
  backPrint: [366, 220, 0],
  floor: 676,
  detailBox: "150 90 260 325",
};

const CARGO: Shape = {
  ...PANTS,
  body: "M170 112 L430 112 L434 150 L462 640 C440 652 350 652 328 640 L304 304 L296 304 L272 640 C250 652 160 652 138 640 L166 150 Z",
  front: (c) =>
    PANTS.front(c) +
    `<path d="M150 330 L226 326 L232 448 L156 452 Z" fill="${c.base}" stroke="${c.dark}" stroke-width="2"/>` +
    `<path d="M150 330 L226 326 L228 360 L151 364 Z" fill="${c.light}" stroke="${c.dark}" stroke-width="1.6"/>` +
    `<path d="M450 330 L374 326 L368 448 L444 452 Z" fill="${c.base}" stroke="${c.dark}" stroke-width="2"/>` +
    `<path d="M450 330 L374 326 L372 360 L449 364 Z" fill="${c.light}" stroke="${c.dark}" stroke-width="1.6"/>` +
    `<path d="M138 620 C160 632 250 632 272 620 L272 640 C250 652 160 652 138 640 Z" fill="${c.dark}"/>` +
    `<path d="M328 620 C350 632 440 632 462 620 L462 640 C440 652 350 652 328 640 Z" fill="${c.dark}"/>`,
};

const CAP: Shape = {
  body: "M168 420 C168 262 236 206 300 206 C364 206 432 262 432 420 Z",
  front: (c) =>
    line("M300 212 Q300 320 300 416", c.dark, 1.6) + line("M296 212 Q232 290 228 416", c.dark, 1.6) + line("M304 212 Q368 290 372 416", c.dark, 1.6) +
    `<circle cx="300" cy="208" r="10" fill="${c.dark}"/>` +
    `<path d="M146 420 C200 398 400 398 454 420 C468 466 424 494 300 494 C176 494 132 466 146 420 Z" fill="${c.dark}"/>` +
    stitch("M160 430 C210 414 390 414 440 430", c) + stitch("M170 452 C220 436 380 436 430 452", c),
  back: (c) =>
    line("M300 212 Q300 320 300 416", c.dark, 1.6) +
    `<circle cx="300" cy="208" r="10" fill="${c.dark}"/>` +
    `<path d="M250 420 C250 380 350 380 350 420 Z" fill="#00000033"/>` +
    `<rect x="262" y="396" width="76" height="12" rx="4" fill="${c.darker}"/>`,
  chest: [300, 340],
  backPrint: [300, 300, 0],
  floor: 520,
  detailBox: "170 200 260 325",
};

const TOTE: Shape = {
  body: "M176 300 L424 300 L446 650 L154 650 Z",
  front: (c) =>
    `<path d="M226 302 C226 150 374 150 374 302" fill="none" stroke="${c.dark}" stroke-width="20" stroke-linecap="round"/>` +
    `<path d="M226 302 C226 150 374 150 374 302" fill="none" stroke="${c.base}" stroke-width="12" stroke-linecap="round"/>` +
    stitch("M182 316 L418 316", c) + fold("M220 340 C228 460 214 560 224 636", 0.08) + fold("M392 340 C384 460 398 560 388 636", 0.08),
  back: (c) =>
    `<path d="M226 302 C226 150 374 150 374 302" fill="none" stroke="${c.dark}" stroke-width="20" stroke-linecap="round"/>` +
    `<path d="M226 302 C226 150 374 150 374 302" fill="none" stroke="${c.base}" stroke-width="12" stroke-linecap="round"/>` +
    stitch("M182 316 L418 316", c),
  chest: [300, 470],
  backPrint: [300, 470, 0],
  floor: 680,
  detailBox: "170 330 260 325",
};

const BEANIE: Shape = {
  body: "M188 480 C176 310 236 222 300 222 C364 222 424 310 412 480 Z",
  front: (c) =>
    Array.from({ length: 13 }, (_, i) => line(`M${206 + i * 16} 470 Q${220 + i * 13} 320 300 232`, c.dark, 1.2)).join("") +
    `<path d="M176 452 L424 452 L428 552 L172 552 Z" fill="${c.dark}"/>` +
    Array.from({ length: 21 }, (_, i) => line(`M${184 + i * 12} 460 L${184 + i * 12} 546`, c.darker, 1.4)).join("") +
    `<rect x="262" y="478" width="76" height="40" rx="3" fill="${c.ink}"/>`,
  back: (c) =>
    `<path d="M176 452 L424 452 L428 552 L172 552 Z" fill="${c.dark}"/>` +
    Array.from({ length: 21 }, (_, i) => line(`M${184 + i * 12} 460 L${184 + i * 12} 546`, c.darker, 1.4)).join(""),
  chest: [300, 503],
  backPrint: [300, 300, 0],
  floor: 580,
  detailBox: "170 300 260 325",
};

const SHAPES: Record<GarmentKind, Shape> = {
  tee: TEE,
  oversized: OVERSIZED,
  hoodie: HOODIE,
  shirt: SHIRT,
  pants: PANTS,
  cargo: CARGO,
  cap: CAP,
  tote: TOTE,
  beanie: BEANIE,
};

export interface ArtOptions {
  kind: GarmentKind;
  hex: string;
  view?: ArtView;
  /** backdrop colour */
  bg?: string;
  /** hide the wordmark print */
  plain?: boolean;
}

/** Returns a standalone SVG string (4:5 portrait, 600×750). */
export function garmentSVG({ kind, hex, view = "front", bg, plain }: ArtOptions): string {
  const s = SHAPES[kind] ?? TEE;
  const dark = isDark(hex);
  const id = `ow${kind}${hex.replace("#", "")}${view}${plain ? "p" : ""}${(bg ?? "").replace(/[^a-z0-9]/gi, "")}`;
  const c: Pal = {
    base: hex,
    dark: shade(hex, dark ? 0.11 : -0.12),
    darker: shade(hex, dark ? -0.55 : -0.3),
    light: shade(hex, dark ? 0.1 : 0.12),
    ink: dark ? "#efe9df" : "#141414",
    stitch: dark ? shade(hex, 0.28) : shade(hex, -0.28),
    id,
  };
  const flat = view === "flat";
  const backdrop = bg ?? (flat ? (dark ? "#d9cfbf" : "#2b2a28") : "#ece7de");
  const clear = backdrop === "transparent";
  const bgDark = clear ? true : isDark(backdrop);
  const vb = view === "detail" ? s.detailBox : "0 0 600 750";

  let print = "";
  if (!plain) {
    const [px, py] = s.chest;
    if (view === "back") {
      const [bx, by, size] = s.backPrint;
      if (size > 0) {
        print =
          `<text x="${bx}" y="${by}" text-anchor="middle" ${WORD} font-size="${size}" fill="${c.ink}" letter-spacing="-1">OUT WEST</text>` +
          `<text x="${bx}" y="${by + size * 0.62}" text-anchor="middle" font-family="Inter Tight, Arial, sans-serif" font-weight="600" font-size="${Math.round(size * 0.26)}" letter-spacing="6" fill="${c.ink}" opacity=".8">EST. 2024 · INDIA</text>`;
      }
    } else if (kind === "shirt") {
      print = `<text x="${px}" y="${py}" text-anchor="middle" ${WORD} font-size="11" fill="${c.ink}" opacity=".85">OW</text>`;
    } else if (kind === "pants" || kind === "cargo") {
      print = `<rect x="${px - 22}" y="${py - 10}" width="44" height="16" rx="2" fill="${c.ink}" opacity=".9"/><text x="${px}" y="${py + 2}" text-anchor="middle" ${WORD} font-size="8" fill="${c.base}">OUT WEST</text>`;
    } else if (kind === "beanie") {
      print = `<text x="${px}" y="${py + 4}" text-anchor="middle" ${WORD} font-size="11" fill="${c.base}">OUT WEST</text>`;
    } else if (kind === "cap") {
      print = `<text x="${px}" y="${py}" text-anchor="middle" ${WORD} font-size="30" fill="${c.ink}">OW</text>`;
    } else if (kind === "tote") {
      print = `<text x="${px}" y="${py}" text-anchor="middle" ${WORD} font-size="40" fill="${c.ink}">OUT WEST</text><text x="${px}" y="${py + 28}" text-anchor="middle" font-family="Inter Tight, Arial, sans-serif" font-weight="600" font-size="11" letter-spacing="5" fill="${c.ink}" opacity=".75">CARRY EVERYTHING</text>`;
    } else {
      const size = kind === "hoodie" ? 30 : kind === "oversized" ? 26 : 20;
      print = `<text x="${px}" y="${py}" text-anchor="middle" ${WORD} font-size="${size}" fill="${c.ink}" letter-spacing="-.5">OUT WEST</text>`;
    }
  }

  const detail = view === "back" ? s.back(c) : s.front(c);
  const tilt = flat ? ` transform="rotate(-5 300 380)"` : "";

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${vb}" preserveAspectRatio="xMidYMid slice" role="img">
<defs>
${clear ? "" : `<radialGradient id="${id}sp" cx="50%" cy="38%" r="70%"><stop offset="0" stop-color="${shade(backdrop, bgDark ? 0.1 : 0.45)}"/><stop offset="1" stop-color="${backdrop}"/></radialGradient>`}
<linearGradient id="${id}sh" x1="0" x2="1" y1="0" y2="0"><stop offset="0" stop-color="#fff" stop-opacity=".16"/><stop offset=".45" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".2"/></linearGradient>
<linearGradient id="${id}vs" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".06"/><stop offset=".7" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".16"/></linearGradient>
<filter id="${id}bl" x="-20%" y="-50%" width="140%" height="200%"><feGaussianBlur stdDeviation="14"/></filter>
</defs>
${clear ? "" : `<rect x="-200" y="-200" width="1000" height="1150" fill="url(#${id}sp)"/>`}
<ellipse cx="300" cy="${s.floor + 8}" rx="200" ry="22" fill="#000" opacity="${flat ? 0.28 : 0.18}" filter="url(#${id}bl)"/>
<g${tilt}>
<path d="${s.body}" fill="${c.base}"/>
${detail}
<path d="${s.body}" fill="url(#${id}sh)"/>
<path d="${s.body}" fill="url(#${id}vs)"/>
${print}
</g>
</svg>`;
}

export const ART_VIEWS: ArtView[] = ["front", "back", "detail", "flat"];
