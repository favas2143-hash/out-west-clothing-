import type { OrderStatus } from "./types";

export const STATUS_FLOW: OrderStatus[] = ["placed", "confirmed", "packed", "shipped", "out_for_delivery", "delivered"];

export const STATUS_LABEL: Record<OrderStatus, string> = {
  pending_payment: "Awaiting payment",
  placed: "Order placed",
  confirmed: "Confirmed",
  packed: "Packed",
  shipped: "Shipped",
  out_for_delivery: "Out for delivery",
  delivered: "Delivered",
  cancelled: "Cancelled",
};

export const PAYMENT_LABEL = {
  pending: "Pending",
  paid: "Paid",
  failed: "Failed",
  cod_pending: "Pay on delivery",
  refunded: "Refunded",
} as const;
