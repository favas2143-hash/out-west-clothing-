import type { Category, CategorySlug, Colour, GarmentKind, Product } from "./types";

export const CATEGORIES: Category[] = [
  { slug: "t-shirts", name: "T-Shirts", kind: "tee", colour: "#e9e4da", blurb: "Clean, everyday essentials", active: true },
  { slug: "oversized-t-shirts", name: "Oversized T-Shirts", kind: "oversized", colour: "#111111", blurb: "240 GSM. Dropped. Boxy.", active: true },
  { slug: "hoodies", name: "Hoodies", kind: "hoodie", colour: "#3a3a38", blurb: "400 GSM brushed fleece", active: true },
  // Hidden at launch — switch on in Admin → Categories
  { slug: "shirts", name: "Shirts", kind: "shirt", colour: "#c8b89c", blurb: "Relaxed shirting & overshirts", active: false },
  { slug: "pants", name: "Pants", kind: "cargo", colour: "#111111", blurb: "Cargos, trousers, sweats", active: false },
  { slug: "accessories", name: "Accessories", kind: "cap", colour: "#e9e4da", blurb: "Caps, beanies, totes", active: false },
];

export const categoryBySlug = (slug: string, list: Category[] = CATEGORIES) => list.find((c) => c.slug === slug);
export const liveCategories = (list: Category[]) => list.filter((c) => c.active);

/** Default sizes for a garment type */
export const sizesForKind = (kind: GarmentKind) =>
  kind === "pants" || kind === "cargo" ? ["28", "30", "32", "34", "36"] : ["cap", "tote", "beanie"].includes(kind) ? ["One Size"] : ["S", "M", "L", "XL"];

export const COLOURS: Record<string, Colour> = {
  black: { name: "Jet Black", hex: "#111111" },
  bone: { name: "Bone", hex: "#e9e4da" },
  charcoal: { name: "Charcoal", hex: "#3a3a38" },
  sand: { name: "Sand", hex: "#c8b89c" },
  offwhite: { name: "Off White", hex: "#f3f1ec" },
  stone: { name: "Stone", hex: "#9a958c" },
  washed: { name: "Washed Grey", hex: "#7d7b77" },
  espresso: { name: "Espresso", hex: "#3b2f28" },
  ecru: { name: "Ecru", hex: "#ddd3c0" },
  brownstripe: { name: "Brown Stripe", hex: "#4a2c1f" },
};

/** Real product photography in /public/products — overrides the studio render */
const PHOTOS: Record<string, string[]> = {
  "Striped Rugby Henley": ["/products/striped-rugby-henley-brown-1.jpg", "/products/striped-rugby-henley-brown-2.jpg"],
};

const APPAREL = ["XS", "S", "M", "L", "XL", "XXL"];
const WAIST = ["28", "30", "32", "34", "36"];
const ONE = ["One Size"];

const FABRIC: Record<GarmentKind, [string, string]> = {
  tee: ["100% combed cotton, 200 GSM single jersey, bio-washed", "Regular fit"],
  oversized: ["100% combed cotton, 240 GSM heavyweight jersey, pre-shrunk", "Oversized fit — size down for a regular fit"],
  hoodie: ["80% cotton / 20% polyester, 400 GSM brushed-back fleece", "Relaxed oversized fit"],
  shirt: ["100% cotton Oxford / cotton-linen blend", "Boxy relaxed fit"],
  pants: ["Cotton twill with 2% elastane for movement", "Relaxed straight leg"],
  cargo: ["Water-resistant nylon-cotton ripstop", "Relaxed fit with adjustable toggled hem"],
  cap: ["100% cotton twill, embroidered front", "Adjustable strap with metal buckle"],
  tote: ["16 oz heavy cotton canvas", "42 × 38 cm with 12 cm gusset"],
  beanie: ["Soft acrylic-wool blend rib knit", "Fold-over cuff"],
};

// Small deterministic PRNG so demo stock is stable between restarts
function seeded(seed: number) {
  let s = seed;
  return () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}

type Seed = [
  name: string,
  category: CategorySlug,
  kind: GarmentKind,
  price: number,
  mrp: number,
  colours: (keyof typeof COLOURS)[],
  tags: ("new" | "bestseller")[],
  description: string,
];

const SEEDS: Seed[] = [
  ["Striped Rugby Henley", "t-shirts", "tee", 1699, 2299, ["brownstripe"], ["new"], "Brown and white Breton stripes on a heavyweight body, contrast black raglan sleeves and a three-button henley placket. Relaxed, boxy and easy to layer."],
  ["Essential Logo Tee", "t-shirts", "tee", 1199, 1499, ["black", "bone", "charcoal"], ["bestseller"], "The everyday tee, refined. Soft bio-washed cotton with a tonal OUT WEST wordmark across the chest."],
  ["Signature Wordmark Tee", "t-shirts", "tee", 1299, 1599, ["bone", "black"], ["new"], "Our signature wordmark, screen-printed front and back on a clean regular-fit body."],
  ["Pima Crew Tee", "t-shirts", "tee", 1499, 1799, ["offwhite", "charcoal", "sand"], [], "Long-staple cotton with a silky hand-feel and a rib collar that holds its shape wash after wash."],
  ["Westbound Graphic Tee", "t-shirts", "tee", 1399, 1999, ["black", "ecru"], ["new"], "A quiet graphic for loud cities. Back print, crew neck, regular fit."],
  ["Heavyweight Oversized Tee", "oversized-t-shirts", "oversized", 1499, 1999, ["black", "bone", "charcoal", "sand"], ["bestseller"], "240 GSM heavyweight jersey with dropped shoulders, a thick rib collar and a boxy, structured drape."],
  ["Concrete Season Oversized Tee", "oversized-t-shirts", "oversized", 1599, 2199, ["charcoal", "black"], ["new", "bestseller"], "From the FW26 Concrete Season drop. Oversized body with a large back print."],
  ["Boxy Drop-Shoulder Tee", "oversized-t-shirts", "oversized", 1399, 1899, ["sand", "ecru", "black"], ["bestseller"], "Cropped slightly shorter for a boxy silhouette that sits perfectly over cargos."],
  ["Washed Vintage Oversized Tee", "oversized-t-shirts", "oversized", 1699, 2299, ["washed", "espresso"], ["new"], "Garment-dyed and enzyme-washed for a lived-in, vintage feel from day one."],
  ["Signature Heavyweight Hoodie", "hoodies", "hoodie", 2999, 3999, ["black", "bone", "charcoal"], ["bestseller", "new"], "400 GSM brushed fleece, double-layer hood, kangaroo pocket and a back wordmark. The one you'll live in."],
  ["Essential Fleece Hoodie", "hoodies", "hoodie", 2499, 3299, ["sand", "black", "stone"], [], "A cleaner take with tonal embroidery and ribbed cuffs. Pairs with everything."],
  ["Concrete Season Hoodie", "hoodies", "hoodie", 3299, 4299, ["charcoal", "ecru"], ["new"], "The FW26 campaign hoodie. Boxy fit, heavy hand-feel, puff-print wordmark."],
  ["Washed Oversized Hoodie", "hoodies", "hoodie", 3199, 3999, ["washed", "espresso"], ["bestseller"], "Acid-washed for unique fades. Every piece is slightly different."],
  ["Relaxed Oxford Shirt", "shirts", "shirt", 2199, 2799, ["bone", "black"], [], "A boxy Oxford with a dropped shoulder and a chest pocket. Wear it buttoned or open over a tee."],
  ["Boxy Linen-Blend Shirt", "shirts", "shirt", 2499, 2999, ["sand", "offwhite"], ["new"], "Breathable cotton-linen made for Indian summers. Camp-ready, office-ready."],
  ["Utility Overshirt", "shirts", "shirt", 2799, 3499, ["charcoal", "espresso"], ["bestseller"], "Mid-weight twill overshirt with utility pockets — layer it over hoodies when the temperature drops."],
  ["Parachute Cargo Pants", "pants", "cargo", 2799, 3499, ["black", "sand", "stone"], ["bestseller"], "Wide parachute silhouette with six pockets and toggled hems to adjust the stack."],
  ["Relaxed Pleated Trousers", "pants", "pants", 2599, 3299, ["charcoal", "bone"], ["new"], "Single-pleat trousers with a relaxed straight leg. Smart enough for dinner, easy enough for everything else."],
  ["Heavyweight Sweatpants", "pants", "pants", 2299, 2999, ["black", "washed"], [], "Matching 400 GSM fleece with a straight leg and open hem. Pair with the Signature Hoodie."],
  ["Straight Utility Cargo", "pants", "cargo", 2899, 3599, ["espresso", "ecru"], ["new"], "Straight-leg cargo in durable ripstop with bellowed side pockets."],
  ["Wordmark Dad Cap", "accessories", "cap", 999, 1299, ["black", "bone", "sand"], ["bestseller"], "Six-panel washed cotton cap with an embroidered OW monogram and a metal buckle strap."],
  ["Ribbed Knit Beanie", "accessories", "beanie", 899, 1199, ["black", "charcoal", "ecru"], ["new"], "Chunky rib knit with a woven OUT WEST label on the cuff."],
  ["Heavy Canvas Tote", "accessories", "tote", 1099, 1399, ["ecru", "black"], [], "16 oz canvas tote that carries a laptop, a gym kit and the rest of your day."],
];

export const slugify = (s: string) =>
  s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

export const stockKey = (colour: string, size: string) => `${colour}__${size}`;

export function buildSeedProducts(): Product[] {
  const rand = seeded(42);
  const now = Date.UTC(2026, 10, 20);
  return SEEDS.map(([name, category, kind, price, mrp, colourKeys, tags, description], i) => {
    const colours = colourKeys.map((k) => COLOURS[k]);
    const sizes = category === "accessories" ? ONE : category === "pants" ? WAIST : APPAREL;
    const stock: Record<string, number> = {};
    for (const c of colours)
      for (const s of sizes) {
        const r = rand();
        stock[stockKey(c.name, s)] = r < 0.03 ? 0 : r < 0.08 ? Math.ceil(r * 30) : Math.round(8 + r * 30);
      }
    const [fabric, fit] = FABRIC[kind];
    return {
      id: `p_${(i + 1).toString().padStart(3, "0")}`,
      slug: slugify(name),
      name,
      category,
      kind,
      description,
      details: [
        fabric,
        fit,
        "Designed in Bengaluru, made in Tiruppur",
        "Machine wash cold, inside out. Do not tumble dry.",
      ],
      fabric,
      fit,
      price,
      mrp,
      colours,
      sizes,
      stock,
      images: PHOTOS[name] ?? [],
      tags,
      // real products start without reviews; demo ones get sample numbers
      rating: PHOTOS[name] ? (rand(), 0) : Math.round((4.3 + rand() * 0.6) * 10) / 10,
      reviews: PHOTOS[name] ? (rand(), 0) : Math.round(24 + rand() * 480),
      createdAt: new Date(now - (tags.includes("new") ? i : 40 + i) * 86400000).toISOString(),
      active: true,
    } satisfies Product;
  });
}

export const totalStock = (p: Product) => Object.values(p.stock).reduce((a, b) => a + b, 0);
export const discountPct = (p: { price: number; mrp: number }) =>
  p.mrp > p.price ? Math.round(((p.mrp - p.price) / p.mrp) * 100) : 0;
