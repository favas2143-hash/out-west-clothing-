/** Category slugs are managed in Admin → Categories */
export type CategorySlug = string;

export type GarmentKind =
  | "tee"
  | "oversized"
  | "hoodie"
  | "shirt"
  | "pants"
  | "cargo"
  | "cap"
  | "tote"
  | "beanie";

export type ArtView = "front" | "back" | "detail" | "flat";

export interface Colour {
  name: string;
  hex: string;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  category: CategorySlug;
  kind: GarmentKind;
  description: string;
  details: string[];
  fabric: string;
  fit: string;
  price: number; // selling price, INR
  mrp: number; // maximum retail price, INR
  colours: Colour[];
  sizes: string[];
  /** stock per variant, key = `${colourName}__${size}` */
  stock: Record<string, number>;
  /** optional real photography; when empty the studio render is used */
  images: string[];
  tags: ("new" | "bestseller")[];
  rating: number;
  reviews: number;
  createdAt: string;
  active: boolean;
}

export interface Category {
  slug: CategorySlug;
  name: string;
  /** studio render used for the category tile */
  kind: GarmentKind;
  /** garment colour on the category tile */
  colour: string;
  blurb: string;
  /** shown in the store menus, homepage and shop */
  active: boolean;
}

export interface CartItem {
  productId: string;
  slug: string;
  name: string;
  kind: GarmentKind;
  colour: string;
  hex: string;
  size: string;
  qty: number;
  price: number;
  mrp: number;
  image?: string;
}

export type PaymentMethod = "razorpay" | "cod";
export type PaymentStatus = "pending" | "paid" | "failed" | "cod_pending" | "refunded";
export type OrderStatus =
  | "pending_payment"
  | "placed"
  | "confirmed"
  | "packed"
  | "shipped"
  | "out_for_delivery"
  | "delivered"
  | "cancelled";

export interface Address {
  name: string;
  phone: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  pincode: string;
}

export interface OrderItem {
  productId: string;
  slug: string;
  name: string;
  kind: GarmentKind;
  colour: string;
  hex: string;
  size: string;
  qty: number;
  price: number;
}

export interface Order {
  id: string;
  number: string;
  accessKey: string;
  userId?: string;
  email: string;
  address: Address;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  coupon?: string;
  shipping: number;
  codFee: number;
  total: number;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  razorpayOrderId?: string;
  razorpayPaymentId?: string;
  status: OrderStatus;
  courier?: string;
  awb?: string;
  timeline: { status: OrderStatus; at: string; note?: string }[];
  notes?: OrderNote[];
  createdAt: string;
  stockCommitted: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  passwordHash: string;
  role: "customer" | "admin";
  createdAt: string;
}

export type PublicUser = Omit<User, "passwordHash">;

export interface Coupon {
  id: string;
  code: string;
  type: "percent" | "flat";
  value: number;
  minOrder: number;
  maxUses?: number;
  used: number;
  expiresAt?: string;
  active: boolean;
  description?: string;
  createdAt: string;
}

/** What the browser needs to price a coupon (no usage data) */
export type AppliedCoupon = Pick<Coupon, "code" | "type" | "value" | "minOrder">;

export interface StoreSettings {
  id: "store";
  shippingFee: number;
  freeShippingThreshold: number;
  codEnabled: boolean;
  codFee: number;
  codMaxOrder: number;
  announcements: string[];
  heroEyebrow: string;
  heroTitle: string;
  heroText: string;
  supportEmail: string;
  supportPhone: string;
  lowStockThreshold: number;
  categories: Category[];
  businessName: string;
  businessAddress: string;
  gstin: string;
}

export interface OrderNote {
  at: string;
  by: string;
  text: string;
}
