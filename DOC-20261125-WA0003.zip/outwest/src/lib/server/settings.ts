import { DEFAULT_SETTINGS } from "@/lib/pricing";
import type { Category, GarmentKind, StoreSettings } from "@/lib/types";
import { slugify } from "@/lib/catalog";
import { store } from "./db";

export async function getSettings(): Promise<StoreSettings> {
  const saved = await (await store()).get<StoreSettings>("settings", "store");
  return { ...DEFAULT_SETTINGS, ...(saved ?? {}), id: "store" };
}

const num = (v: unknown, min = 0) => Math.max(min, Math.round(Number(v) || 0));
const KINDS: GarmentKind[] = ["tee", "oversized", "hoodie", "shirt", "pants", "cargo", "cap", "tote", "beanie"];

export function cleanCategories(list: Category[]): Category[] | string {
  const seen = new Set<string>();
  const out: Category[] = [];
  for (const c of list) {
    const name = String(c.name ?? "").trim();
    if (!name) return "Every category needs a name";
    const slug = c.slug?.trim() || slugify(name);
    if (!slug || seen.has(slug)) return `Two categories share the link “${slug}”. Rename one.`;
    seen.add(slug);
    out.push({
      slug,
      name: name.slice(0, 40),
      blurb: String(c.blurb ?? "").trim().slice(0, 80),
      kind: KINDS.includes(c.kind) ? c.kind : "tee",
      colour: /^#[0-9a-f]{6}$/i.test(c.colour) ? c.colour : "#111111",
      active: !!c.active,
    });
  }
  if (!out.length) return "Keep at least one category";
  return out;
}

export async function saveSettings(input: Partial<StoreSettings>) {
  const cur = await getSettings();
  const next: StoreSettings = {
    ...cur,
    shippingFee: input.shippingFee !== undefined ? num(input.shippingFee) : cur.shippingFee,
    freeShippingThreshold: input.freeShippingThreshold !== undefined ? num(input.freeShippingThreshold) : cur.freeShippingThreshold,
    codEnabled: input.codEnabled ?? cur.codEnabled,
    codFee: input.codFee !== undefined ? num(input.codFee) : cur.codFee,
    codMaxOrder: input.codMaxOrder !== undefined ? num(input.codMaxOrder, 1) : cur.codMaxOrder,
    lowStockThreshold: input.lowStockThreshold !== undefined ? num(input.lowStockThreshold) : cur.lowStockThreshold,
    categories: input.categories && Array.isArray(cleanCategories(input.categories)) ? (cleanCategories(input.categories) as Category[]) : cur.categories,
    announcements: input.announcements ? input.announcements.map((a) => String(a).trim()).filter(Boolean).slice(0, 8) : cur.announcements,
    heroEyebrow: input.heroEyebrow?.trim() ?? cur.heroEyebrow,
    heroTitle: input.heroTitle?.trim() || cur.heroTitle,
    heroText: input.heroText?.trim() ?? cur.heroText,
    supportEmail: input.supportEmail?.trim() ?? cur.supportEmail,
    supportPhone: input.supportPhone?.trim() ?? cur.supportPhone,
    businessName: input.businessName?.trim() || cur.businessName,
    businessAddress: input.businessAddress?.trim() ?? cur.businessAddress,
    gstin: input.gstin?.trim().toUpperCase() ?? cur.gstin,
    id: "store",
  };
  await (await store()).put("settings", next);
  return next;
}
