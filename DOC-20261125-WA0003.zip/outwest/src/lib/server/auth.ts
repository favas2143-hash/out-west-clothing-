import crypto from "crypto";
import { cookies } from "next/headers";
import type { PublicUser, User } from "@/lib/types";
import { store, uid } from "./db";

const COOKIE = "ow_session";
const MAX_AGE = 60 * 60 * 24 * 30; // 30 days

function secret() {
  const s = process.env.AUTH_SECRET;
  if (!s && process.env.NODE_ENV === "production") {
    console.warn("[OUT WEST] AUTH_SECRET is not set — using an insecure default. Set it in your environment.");
  }
  return s || "outwest-dev-secret-change-me";
}

export function hashPassword(pw: string) {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(pw, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(pw: string, stored: string) {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const test = crypto.scryptSync(pw, salt, 64);
  const known = Buffer.from(hash, "hex");
  return known.length === test.length && crypto.timingSafeEqual(known, test);
}

function sign(payload: string) {
  return crypto.createHmac("sha256", secret()).update(payload).digest("base64url");
}

export function publicUser(u: User): PublicUser {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { passwordHash, ...rest } = u;
  return rest;
}

/**
 * Keeps the admin login in sync with ADMIN_EMAIL / ADMIN_PASSWORD.
 * Change either value and restart/redeploy: the admin account is updated on the next request,
 * and the built-in demo admin (admin@outwest.in) loses admin access.
 */
const DEMO_ADMIN = "admin@outwest.in";
let adminChecked = false;
export async function ensureAdmin() {
  if (adminChecked) return;
  const s = await store();
  const email = (process.env.ADMIN_EMAIL || "").trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD || "";
  if (email && password) {
    const existing = (await s.find<User>("users", "email", email))[0];
    if (!existing) {
      await s.put("users", { id: uid("u"), name: "Store Admin", email, passwordHash: hashPassword(password), role: "admin", createdAt: new Date().toISOString() } satisfies User);
    } else if (existing.role !== "admin" || !verifyPassword(password, existing.passwordHash)) {
      await s.put("users", { ...existing, role: "admin", passwordHash: hashPassword(password) });
    }
    if (email !== DEMO_ADMIN) {
      const demo = (await s.find<User>("users", "email", DEMO_ADMIN))[0];
      if (demo?.role === "admin") await s.put("users", { ...demo, role: "customer", passwordHash: hashPassword(crypto.randomBytes(24).toString("hex")) });
    }
  } else if ((await s.find<User>("users", "role", "admin")).length === 0) {
    if (process.env.NODE_ENV === "production") console.warn("[OUT WEST] ADMIN_EMAIL / ADMIN_PASSWORD not set — using the demo admin login. Set them now.");
    await s.put("users", { id: uid("u"), name: "Store Admin", email: DEMO_ADMIN, passwordHash: hashPassword("outwest-admin"), role: "admin", createdAt: new Date().toISOString() } satisfies User);
  }
  adminChecked = true;
}

export async function findUserByEmail(email: string) {
  await ensureAdmin();
  return (await (await store()).find<User>("users", "email", email.trim().toLowerCase()))[0] ?? null;
}

export async function createUser(input: { name: string; email: string; phone?: string; password: string }) {
  const user: User = {
    id: uid("u"),
    name: input.name.trim(),
    email: input.email.trim().toLowerCase(),
    phone: input.phone?.trim() || undefined,
    passwordHash: hashPassword(input.password),
    role: "customer",
    createdAt: new Date().toISOString(),
  };
  await (await store()).put("users", user);
  return user;
}

export async function startSession(userId: string) {
  const exp = Math.floor(Date.now() / 1000) + MAX_AGE;
  const payload = Buffer.from(JSON.stringify({ uid: userId, exp })).toString("base64url");
  const jar = await cookies();
  jar.set(COOKIE, `${payload}.${sign(payload)}`, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: MAX_AGE,
  });
}

export async function endSession() {
  const jar = await cookies();
  jar.delete(COOKIE);
}

export async function getCurrentUser(): Promise<User | null> {
  const jar = await cookies();
  const raw = jar.get(COOKIE)?.value;
  if (!raw) return null;
  const [payload, sig] = raw.split(".");
  if (!payload || !sig) return null;
  const expected = sign(payload);
  if (expected.length !== sig.length || !crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(sig))) return null;
  try {
    const { uid: id, exp } = JSON.parse(Buffer.from(payload, "base64url").toString()) as { uid: string; exp: number };
    if (exp < Date.now() / 1000) return null;
    await ensureAdmin();
    return await (await store()).get<User>("users", id);
  } catch {
    return null;
  }
}

export async function requireAdmin() {
  const u = await getCurrentUser();
  return u?.role === "admin" ? u : null;
}

export async function listUsers() {
  await ensureAdmin();
  return (await (await store()).list<User>("users")).map(publicUser);
}

export async function setUserRole(email: string, role: "admin" | "customer") {
  const s = await store();
  const u = (await s.find<User>("users", "email", email.trim().toLowerCase()))[0];
  if (!u) return null;
  await s.put("users", { ...u, role });
  return publicUser({ ...u, role });
}
