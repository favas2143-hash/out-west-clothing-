import type { IgPost } from "@/components/home/InstagramSection";

/**
 * Latest posts via the Instagram API with Instagram Login.
 * Set INSTAGRAM_ACCESS_TOKEN (long-lived token for the brand's professional account).
 * Cached for an hour; returns [] on any failure so the designed grid is shown instead.
 */
export async function getInstagramPosts(): Promise<IgPost[]> {
  const token = process.env.INSTAGRAM_ACCESS_TOKEN;
  if (!token) return [];
  try {
    const res = await fetch(
      `https://graph.instagram.com/me/media?fields=id,caption,media_type,media_url,thumbnail_url,permalink&limit=12&access_token=${token}`,
      { next: { revalidate: 3600 } },
    );
    if (!res.ok) return [];
    const json = (await res.json()) as {
      data: { id: string; caption?: string; media_type: string; media_url: string; thumbnail_url?: string; permalink: string }[];
    };
    return json.data
      .map((m) => ({
        id: m.id,
        image: m.media_type === "VIDEO" ? m.thumbnail_url ?? "" : m.media_url,
        permalink: m.permalink,
        caption: m.caption,
      }))
      .filter((p) => p.image)
      .slice(0, 6);
  } catch {
    return [];
  }
}
