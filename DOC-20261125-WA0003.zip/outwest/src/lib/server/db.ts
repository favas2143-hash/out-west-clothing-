/**
 * OUT WEST data store.
 *
 * - Production: Postgres (Supabase, Neon, any Postgres) when DATABASE_URL is set.
 *   Tables are created and demo products seeded automatically on first request.
 * - Local development without DATABASE_URL: a JSON file at data/db.json.
 *
 * Every record is stored as a JSON document (`data jsonb`), so the repository
 * modules (products.ts, orders.ts, auth.ts) work the same on both backends.
 * Stock changes run inside transactions with row locks, so two shoppers can't
 * buy the last item at the same time.
 */
import fs from "fs";
import path from "path";
import postgres from "postgres";
import { buildSeedProducts } from "@/lib/catalog";

export type Table = "products" | "orders" | "users" | "subscribers" | "coupons" | "settings";
const TABLES: Table[] = ["products", "orders", "users", "subscribers", "coupons", "settings"];
type Doc = { id: string };

export interface Store {
  /** newest first */
  list<T>(t: Table): Promise<T[]>;
  get<T>(t: Table, id: string, opts?: { lock?: boolean }): Promise<T | null>;
  /** exact match on a top-level JSON field, e.g. find("orders", "number", "OW123456") */
  find<T>(t: Table, field: string, value: string): Promise<T[]>;
  put<T extends Doc>(t: Table, doc: T): Promise<void>;
  del(t: Table, id: string): Promise<boolean>;
}

export const uid = (prefix: string) =>
  `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;

const usePg = () => !!process.env.DATABASE_URL;

/* ───────────────────────── Postgres ───────────────────────── */

const SCHEMA = `
create table if not exists products (id text primary key, pos bigserial, data jsonb not null);
create table if not exists orders (id text primary key, pos bigserial, data jsonb not null);
create table if not exists users (id text primary key, pos bigserial, data jsonb not null);
create table if not exists subscribers (id text primary key, pos bigserial, data jsonb not null);
create table if not exists coupons (id text primary key, pos bigserial, data jsonb not null);
create table if not exists settings (id text primary key, pos bigserial, data jsonb not null);
create unique index if not exists coupons_code_idx on coupons ((data->>'code'));
create unique index if not exists products_slug_idx on products ((data->>'slug'));
create unique index if not exists orders_number_idx on orders ((data->>'number'));
create index if not exists orders_email_idx on orders ((data->>'email'));
create index if not exists orders_user_idx on orders ((data->>'userId'));
create index if not exists orders_rzp_idx on orders ((data->>'razorpayOrderId'));
create unique index if not exists users_email_idx on users ((data->>'email'));
-- Block Supabase's public REST API from these tables. The app connects as the
-- database owner, which is not affected by row level security.
alter table products enable row level security;
alter table orders enable row level security;
alter table users enable row level security;
alter table subscribers enable row level security;
alter table coupons enable row level security;
alter table settings enable row level security;
`;

const g = globalThis as unknown as {
  __owsql?: postgres.Sql;
  __owready?: Promise<void>;
  __owdb?: Record<Table, Doc[]>;
  __owmtime?: number;
  __owchain?: Promise<unknown>;
};

function sql() {
  if (!g.__owsql) {
    g.__owsql = postgres(process.env.DATABASE_URL!, {
      prepare: false, // required by Supabase's transaction pooler (port 6543)
      max: 5,
      idle_timeout: 20,
      ssl: /localhost|127\.0\.0\.1/.test(process.env.DATABASE_URL!) ? false : "require",
    });
  }
  return g.__owsql;
}

function ready() {
  if (!g.__owready) {
    g.__owready = (async () => {
      const db = sql();
      await db.unsafe(SCHEMA);
      const [{ n }] = await db`select count(*)::int as n from products`;
      if (n === 0) {
        // insert in reverse so the first catalogue item is the "newest" row
        for (const p of buildSeedProducts().reverse()) {
          await db`insert into products (id, data) values (${p.id}, ${db.json(p as unknown as postgres.JSONValue)}) on conflict do nothing`;
        }
      }
    })().catch((e) => {
      g.__owready = undefined;
      throw e;
    });
  }
  return g.__owready;
}

function pgStore(q: postgres.Sql): Store {
  return {
    async list<T>(t: Table) {
      const rows = await q`select data from ${q(t)} order by pos desc`;
      return rows.map((r) => r.data as T);
    },
    async get<T>(t: Table, id: string, opts?: { lock?: boolean }) {
      const rows = opts?.lock
        ? await q`select data from ${q(t)} where id = ${id} for update`
        : await q`select data from ${q(t)} where id = ${id}`;
      return (rows[0]?.data as T) ?? null;
    },
    async find<T>(t: Table, field: string, value: string) {
      const rows = await q`select data from ${q(t)} where data->>${field} = ${value} order by pos desc`;
      return rows.map((r) => r.data as T);
    },
    async put<T extends Doc>(t: Table, doc: T) {
      const json = q.json(doc as unknown as postgres.JSONValue);
      await q`insert into ${q(t)} (id, data) values (${doc.id}, ${json}) on conflict (id) do update set data = excluded.data`;
    },
    async del(t: Table, id: string) {
      const rows = await q`delete from ${q(t)} where id = ${id} returning id`;
      return rows.length > 0;
    },
  };
}

/* ───────────────────────── JSON file (local dev) ───────────────────────── */

const DIR = path.join(process.cwd(), "data");
const FILE = path.join(DIR, "db.json");

function fileDb() {
  let mtime = 0;
  try {
    mtime = fs.statSync(FILE).mtimeMs;
  } catch {}
  if (!g.__owdb || (mtime && mtime !== g.__owmtime)) {
    try {
      const raw = JSON.parse(fs.readFileSync(FILE, "utf8"));
      g.__owdb = Object.fromEntries(TABLES.map((t) => [t, raw[t] ?? []])) as Record<Table, Doc[]>;
      g.__owmtime = mtime;
    } catch {
      if (!g.__owdb) {
        g.__owdb = { ...(Object.fromEntries(TABLES.map((t) => [t, []])) as unknown as Record<Table, Doc[]>), products: buildSeedProducts() };
        persist();
      }
    }
  }
  return g.__owdb!;
}

function persist() {
  if (!g.__owdb) return;
  try {
    fs.mkdirSync(DIR, { recursive: true });
    fs.writeFileSync(FILE, JSON.stringify(g.__owdb, null, 2));
    g.__owmtime = fs.statSync(FILE).mtimeMs;
  } catch {
    /* read-only filesystem: keep working in memory */
  }
}

const clone = <T>(v: T): T => (v == null ? v : (JSON.parse(JSON.stringify(v)) as T));

const fileStore: Store = {
  async list<T>(t: Table) {
    return clone(fileDb()[t]) as unknown as T[];
  },
  async get<T>(t: Table, id: string) {
    return clone((fileDb()[t].find((d) => d.id === id) as T) ?? null);
  },
  async find<T>(t: Table, field: string, value: string) {
    return clone(fileDb()[t].filter((d) => String((d as Record<string, unknown>)[field] ?? "") === value)) as unknown as T[];
  },
  async put<T extends Doc>(t: Table, doc: T) {
    const arr = fileDb()[t];
    const i = arr.findIndex((d) => d.id === doc.id);
    if (i >= 0) arr[i] = clone(doc);
    else arr.unshift(clone(doc));
    persist();
  },
  async del(t: Table, id: string) {
    const d = fileDb();
    const before = d[t].length;
    d[t] = d[t].filter((x) => x.id !== id);
    persist();
    return d[t].length < before;
  },
};

/* ───────────────────────── public API ───────────────────────── */

/** Plain (non-transactional) access. */
export async function store(): Promise<Store> {
  if (!usePg()) return fileStore;
  await ready();
  return pgStore(sql());
}

/** Runs `fn` in a transaction. Use `get(..., { lock: true })` for rows you will update. */
export async function transaction<R>(fn: (s: Store) => Promise<R>): Promise<R> {
  if (usePg()) {
    await ready();
    return (await sql().begin((t) => fn(pgStore(t as unknown as postgres.Sql)))) as unknown as R;
  }
  // file backend: run transactions one at a time
  const run = (g.__owchain ?? Promise.resolve()).then(() => fn(fileStore));
  g.__owchain = run.catch(() => {});
  return run;
}
