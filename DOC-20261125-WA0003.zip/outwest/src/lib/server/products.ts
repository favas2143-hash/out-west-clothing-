import { slugify, stockKey } from "@/lib/catalog";
import type { Product } from "@/lib/types";
import { store, transaction, uid, type Store } from "./db";
import { getSettings } from "./settings";

/** Store-facing list hides inactive products and products in hidden categories. */
export async function listProducts(opts: { includeInactive?: boolean } = {}) {
  const all = await (await store()).list<Product>("products");
  if (opts.includeInactive) return all;
  const live = new Set((await getSettings()).categories.filter((c) => c.active).map((c) => c.slug));
  return all.filter((p) => p.active && live.has(p.category));
}

/** True when shoppers can see and buy this product */
export async function isOnSale(p: Product) {
  if (!p.active) return false;
  return (await getSettings()).categories.some((c) => c.slug === p.category && c.active);
}

export async function getProduct(idOrSlug: string) {
  const s = await store();
  return (await s.get<Product>("products", idOrSlug)) ?? (await s.find<Product>("products", "slug", idOrSlug))[0] ?? null;
}

export type ProductInput = Omit<Product, "id" | "slug" | "createdAt" | "rating" | "reviews"> & {
  slug?: string;
};

async function uniqueSlug(s: Store, base: string, ignoreId?: string) {
  const root = slugify(base) || "product";
  let slug = root;
  let n = 2;
  while ((await s.find<Product>("products", "slug", slug)).some((p) => p.id !== ignoreId)) slug = `${root}-${n++}`;
  return slug;
}

function normalise(input: ProductInput, existing?: Product): Omit<Product, "id" | "createdAt" | "slug"> {
  const stock: Record<string, number> = {};
  for (const c of input.colours)
    for (const s of input.sizes) stock[stockKey(c.name, s)] = Math.max(0, Math.floor(Number(input.stock?.[stockKey(c.name, s)] ?? 0)));
  return {
    name: input.name.trim(),
    category: input.category,
    kind: input.kind,
    description: input.description ?? "",
    details: (input.details ?? []).filter(Boolean),
    fabric: input.fabric ?? "",
    fit: input.fit ?? "",
    price: Math.max(0, Math.round(Number(input.price))),
    mrp: Math.max(Math.round(Number(input.price)), Math.round(Number(input.mrp))),
    colours: input.colours,
    sizes: input.sizes,
    stock,
    images: (input.images ?? []).filter(Boolean),
    tags: input.tags ?? [],
    rating: existing?.rating ?? 0,
    reviews: existing?.reviews ?? 0,
    active: input.active ?? true,
  };
}

export function validateProduct(input: Partial<ProductInput>): string | null {
  if (!input.name?.trim()) return "Name is required";
  if (!input.category) return "Category is required";
  if (!input.kind) return "Image style is required";
  if (!(Number(input.price) > 0)) return "Price must be greater than 0";
  if (!input.colours?.length) return "Add at least one colour";
  if (!input.sizes?.length) return "Add at least one size";
  return null;
}

export async function createProduct(input: ProductInput) {
  const s = await store();
  const p: Product = {
    id: uid("p"),
    createdAt: new Date().toISOString(),
    slug: await uniqueSlug(s, input.slug || input.name),
    ...normalise(input),
  };
  await s.put("products", p);
  return p;
}

export async function updateProduct(id: string, input: ProductInput) {
  return transaction(async (s) => {
    const existing = await s.get<Product>("products", id, { lock: true });
    if (!existing) return null;
    const p: Product = { ...existing, ...normalise(input, existing), slug: await uniqueSlug(s, input.slug || input.name, id) };
    await s.put("products", p);
    return p;
  });
}

export async function setActive(id: string, active: boolean) {
  return transaction(async (s) => {
    const p = await s.get<Product>("products", id, { lock: true });
    if (!p) return null;
    p.active = active;
    await s.put("products", p);
    return p;
  });
}

export async function deleteProduct(id: string) {
  return (await store()).del("products", id);
}

export async function setStock(updates: { productId: string; key: string; qty: number }[]) {
  await transaction(async (s) => {
    const byProduct = new Map<string, typeof updates>();
    updates.forEach((u) => byProduct.set(u.productId, [...(byProduct.get(u.productId) ?? []), u]));
    for (const [pid, list] of byProduct) {
      const p = await s.get<Product>("products", pid, { lock: true });
      if (!p) continue;
      for (const u of list) if (u.key in p.stock) p.stock[u.key] = Math.max(0, Math.floor(u.qty));
      await s.put("products", p);
    }
  });
}

type Line = { productId: string; colour: string; size: string; qty: number };

/** Returns a list of problems, empty when every line can be fulfilled. */
export async function checkStock(items: Line[], s?: Store, lock = false) {
  const st = s ?? (await store());
  const problems: string[] = [];
  const need = new Map<string, number>();
  for (const it of items) need.set(`${it.productId}|${stockKey(it.colour, it.size)}`, (need.get(`${it.productId}|${stockKey(it.colour, it.size)}`) ?? 0) + it.qty);
  const cache = new Map<string, Product | null>();
  for (const it of items) {
    if (!cache.has(it.productId)) cache.set(it.productId, await st.get<Product>("products", it.productId, { lock }));
    const p = cache.get(it.productId);
    if (!p || !p.active) {
      problems.push("An item in your bag is no longer available");
      continue;
    }
    const k = stockKey(it.colour, it.size);
    const have = p.stock[k] ?? 0;
    if (have < (need.get(`${it.productId}|${k}`) ?? it.qty)) problems.push(`${p.name} (${it.colour}, ${it.size}) — only ${have} left`);
  }
  return [...new Set(problems)];
}

/** Changes stock inside an existing transaction. sign -1 = sell, +1 = restock. */
export async function adjustStock(s: Store, items: Line[], sign: 1 | -1) {
  const ids = [...new Set(items.map((i) => i.productId))];
  for (const id of ids) {
    const p = await s.get<Product>("products", id, { lock: true });
    if (!p) continue;
    for (const it of items.filter((i) => i.productId === id)) {
      const k = stockKey(it.colour, it.size);
      if (k in p.stock) p.stock[k] = Math.max(0, p.stock[k] + sign * it.qty);
    }
    await s.put("products", p);
  }
}

export async function duplicateProduct(id: string) {
  const s = await store();
  const p = await s.get<Product>("products", id);
  if (!p) return null;
  const copy: Product = {
    ...p,
    id: uid("p"),
    name: `${p.name} (copy)`,
    slug: await uniqueSlug(s, `${p.name} copy`),
    active: false,
    rating: 0,
    reviews: 0,
    createdAt: new Date().toISOString(),
  };
  await s.put("products", copy);
  return copy;
}
