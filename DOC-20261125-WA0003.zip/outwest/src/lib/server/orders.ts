import crypto from "crypto";
import type { Order, OrderStatus } from "@/lib/types";
import { store, transaction, uid, type Store } from "./db";
import { adjustStock, checkStock } from "./products";
import { redeemCoupon } from "./coupons";

export { STATUS_FLOW, STATUS_LABEL } from "@/lib/orderStatus";

export class StockError extends Error {}

async function newOrderNumber(s: Store) {
  for (;;) {
    const n = `OW${crypto.randomInt(100000, 999999)}`;
    if ((await s.find<Order>("orders", "number", n)).length === 0) return n;
  }
}

async function commitStock(s: Store, o: Order) {
  if (o.stockCommitted) return;
  await adjustStock(s, o.items, -1);
  o.stockCommitted = true;
}

type NewOrder = Omit<Order, "id" | "number" | "accessKey" | "createdAt" | "timeline" | "stockCommitted">;

/** Creates an order. COD orders reserve stock immediately; online orders when payment is captured. */
export async function insertOrder(o: NewOrder) {
  return transaction(async (s) => {
    const problems = await checkStock(o.items, s, true);
    if (problems.length) throw new StockError(`Some items are low on stock: ${problems.join("; ")}`);
    const now = new Date().toISOString();
    const order: Order = {
      ...o,
      id: uid("o"),
      number: await newOrderNumber(s),
      accessKey: crypto.randomBytes(12).toString("base64url"),
      createdAt: now,
      timeline: [{ status: o.status, at: now }],
      stockCommitted: false,
    };
    if (order.status === "placed") await commitStock(s, order);
    if (order.coupon) await redeemCoupon(s, order.coupon);
    await s.put("orders", order);
    return order;
  });
}

export async function saveOrder(o: Order) {
  await (await store()).put("orders", o);
}

export const listOrders = async () => (await store()).list<Order>("orders");

export async function ordersForUser(userId: string, email: string) {
  const s = await store();
  const [a, b] = await Promise.all([s.find<Order>("orders", "userId", userId), s.find<Order>("orders", "email", email)]);
  const seen = new Set<string>();
  return [...a, ...b].filter((o) => !seen.has(o.id) && seen.add(o.id)).sort((x, y) => y.createdAt.localeCompare(x.createdAt));
}

export const getOrderByNumber = async (n: string) =>
  (await (await store()).find<Order>("orders", "number", n.trim().toUpperCase().replace(/^#/, "")))[0] ?? null;

export const getOrderById = async (id: string) => (await store()).get<Order>("orders", id);

export const getOrderByRazorpayId = async (rzpId: string) =>
  (await (await store()).find<Order>("orders", "razorpayOrderId", rzpId))[0] ?? null;

export async function markPaid(orderId: string, paymentId: string) {
  return transaction(async (s) => {
    const o = await s.get<Order>("orders", orderId, { lock: true });
    if (!o || o.paymentStatus === "paid") return o;
    o.paymentStatus = "paid";
    o.razorpayPaymentId = paymentId;
    if (o.status === "pending_payment") {
      o.status = "placed";
      o.timeline.push({ status: "placed", at: new Date().toISOString(), note: "Payment received" });
    }
    await commitStock(s, o);
    await s.put("orders", o);
    return o;
  });
}

export async function markPaymentFailed(orderId: string) {
  return transaction(async (s) => {
    const o = await s.get<Order>("orders", orderId, { lock: true });
    if (!o || o.paymentStatus === "paid") return o;
    o.paymentStatus = "failed";
    await s.put("orders", o);
    return o;
  });
}

export async function setOrderStatus(orderId: string, status: OrderStatus, extra: { note?: string; courier?: string; awb?: string } = {}) {
  return transaction(async (s) => {
    const o = await s.get<Order>("orders", orderId, { lock: true });
    if (!o) return null;
    if (status === "cancelled" && o.stockCommitted) {
      await adjustStock(s, o.items, 1);
      o.stockCommitted = false;
    }
    if (status !== "cancelled" && status !== "pending_payment") await commitStock(s, o);
    if (status === "delivered" && o.paymentMethod === "cod") o.paymentStatus = "paid";
    o.status = status;
    if (extra.courier !== undefined) o.courier = extra.courier || undefined;
    if (extra.awb !== undefined) o.awb = extra.awb || undefined;
    o.timeline.push({ status, at: new Date().toISOString(), note: extra.note || undefined });
    await s.put("orders", o);
    return o;
  });
}

/** Public tracking: needs the order number plus the email or phone used at checkout. */
export async function findForTracking(number: string, contact: string) {
  const o = await getOrderByNumber(number);
  if (!o) return null;
  const c = contact.trim().toLowerCase();
  const phone = c.replace(/\D/g, "").slice(-10);
  if (o.email.toLowerCase() === c || (phone.length === 10 && o.address.phone.replace(/\D/g, "").slice(-10) === phone)) return o;
  return null;
}

/** Strip the access key before sending to the browser. */
export const publicOrder = (o: Order) => {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { accessKey, ...rest } = o;
  return rest;
};

export async function addOrderNote(orderId: string, text: string, by: string) {
  return transaction(async (s) => {
    const o = await s.get<Order>("orders", orderId, { lock: true });
    if (!o) return null;
    o.notes = [...(o.notes ?? []), { at: new Date().toISOString(), by, text: text.trim().slice(0, 1000) }];
    await s.put("orders", o);
    return o;
  });
}

export async function markRefunded(orderId: string, by: string) {
  return transaction(async (s) => {
    const o = await s.get<Order>("orders", orderId, { lock: true });
    if (!o) return null;
    o.paymentStatus = "refunded";
    o.notes = [...(o.notes ?? []), { at: new Date().toISOString(), by, text: `Marked as refunded (${o.total.toLocaleString("en-IN")} INR)` }];
    await s.put("orders", o);
    return o;
  });
}

/** Which status changes the admin may make from the current one */
export function canMoveTo(from: OrderStatus, to: OrderStatus) {
  if (from === "cancelled" || from === "delivered") return false;
  if (from === "pending_payment") return to === "cancelled";
  if (to === "cancelled") return true;
  const order = ["placed", "confirmed", "packed", "shipped", "out_for_delivery", "delivered"];
  return order.indexOf(to) > order.indexOf(from);
}
