import type { AppliedCoupon, Coupon } from "@/lib/types";
import { inr } from "@/lib/pricing";
import { store, uid, type Store } from "./db";

const SEED: Omit<Coupon, "id" | "createdAt">[] = [
  { code: "WELCOME10", type: "percent", value: 10, minOrder: 0, used: 0, active: true, description: "10% off your first order" },
  { code: "OUTWEST15", type: "percent", value: 15, minOrder: 3999, used: 0, active: true, description: "15% off orders above ₹3,999" },
];

let seeded = false;
async function ensureSeed(s: Store) {
  if (seeded) return;
  if ((await s.list<Coupon>("coupons")).length === 0)
    for (const c of SEED) await s.put("coupons", { ...c, id: uid("c"), createdAt: new Date().toISOString() });
  seeded = true;
}

export async function listCoupons() {
  const s = await store();
  await ensureSeed(s);
  return s.list<Coupon>("coupons");
}

export async function getCouponByCode(code: string) {
  const s = await store();
  await ensureSeed(s);
  return (await s.find<Coupon>("coupons", "code", code.trim().toUpperCase()))[0] ?? null;
}

export const toApplied = (c: Coupon): AppliedCoupon => ({ code: c.code, type: c.type, value: c.value, minOrder: c.minOrder });

/** Validates a code for a basket. Returns the coupon or a shopper-facing error. */
export async function checkCoupon(code: string, subtotal: number): Promise<{ coupon?: Coupon; error?: string }> {
  const c = await getCouponByCode(code);
  if (!c || !c.active) return { error: "This code isn't valid" };
  if (c.expiresAt && new Date(c.expiresAt).getTime() < Date.now()) return { error: "This code has expired" };
  if (c.maxUses && c.used >= c.maxUses) return { error: "This code has reached its usage limit" };
  if (subtotal < c.minOrder) return { error: `Add ${inr(c.minOrder - subtotal)} more to use ${c.code}` };
  return { coupon: c };
}

export function validateCoupon(i: Partial<Coupon>): string | null {
  if (!i.code || !/^[A-Z0-9_-]{3,20}$/.test(i.code.trim().toUpperCase())) return "Code must be 3–20 letters or numbers";
  if (i.type !== "percent" && i.type !== "flat") return "Choose a discount type";
  if (!(Number(i.value) > 0)) return "Discount must be more than 0";
  if (i.type === "percent" && Number(i.value) > 90) return "Percentage can't be more than 90";
  return null;
}

export async function saveCoupon(input: Partial<Coupon>, id?: string) {
  const s = await store();
  const code = input.code!.trim().toUpperCase();
  const clash = (await s.find<Coupon>("coupons", "code", code)).find((c) => c.id !== id);
  if (clash) throw new Error(`${code} already exists`);
  const existing = id ? await s.get<Coupon>("coupons", id) : null;
  const c: Coupon = {
    id: existing?.id ?? uid("c"),
    createdAt: existing?.createdAt ?? new Date().toISOString(),
    used: existing?.used ?? 0,
    code,
    type: input.type!,
    value: Math.round(Number(input.value)),
    minOrder: Math.max(0, Math.round(Number(input.minOrder) || 0)),
    maxUses: input.maxUses ? Math.max(1, Math.round(Number(input.maxUses))) : undefined,
    expiresAt: input.expiresAt || undefined,
    active: input.active ?? true,
    description: input.description?.trim() || undefined,
  };
  await s.put("coupons", c);
  return c;
}

export async function deleteCoupon(id: string) {
  return (await store()).del("coupons", id);
}

/** Called inside the order transaction */
export async function redeemCoupon(s: Store, code: string) {
  const c = (await s.find<Coupon>("coupons", "code", code))[0];
  if (!c) return;
  const locked = await s.get<Coupon>("coupons", c.id, { lock: true });
  if (locked) await s.put("coupons", { ...locked, used: locked.used + 1 });
}
