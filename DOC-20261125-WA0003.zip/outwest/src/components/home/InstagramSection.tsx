"use client";

import { Icon } from "@/components/ui/Icon";
import { ProductArt } from "@/components/product/ProductArt";
import type { GarmentKind } from "@/lib/types";

export interface IgPost {
  id: string;
  image: string;
  permalink: string;
  caption?: string;
}

const IG = process.env.NEXT_PUBLIC_INSTAGRAM_HANDLE || "outwest.in";

// Designed placeholder tiles, shown until INSTAGRAM_ACCESS_TOKEN is set
const TILES: { kind: GarmentKind; hex: string; bg: string; view: "front" | "back" | "flat" | "detail"; caption: string }[] = [
  { kind: "hoodie", hex: "#111111", bg: "#d9cfbf", view: "back", caption: "Concrete Season, out now." },
  { kind: "oversized", hex: "#e9e4da", bg: "#2b2a28", view: "flat", caption: "240 GSM. Built heavy." },
  { kind: "cargo", hex: "#c8b89c", bg: "#ece7de", view: "front", caption: "Parachute cargos in Sand." },
  { kind: "cap", hex: "#111111", bg: "#e8e1d5", view: "flat", caption: "The OW cap." },
  { kind: "shirt", hex: "#3b2f28", bg: "#d9cfbf", view: "detail", caption: "Utility overshirt, espresso." },
  { kind: "oversized", hex: "#3a3a38", bg: "#f4f1ea", view: "back", caption: "Back print season." },
];

export function InstagramSection({ posts }: { posts?: IgPost[] }) {
  const url = `https://instagram.com/${IG}`;
  return (
    <section className="py-16 md:py-24">
      <div className="wrap reveal mb-8 flex flex-col gap-4 md:mb-12 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="eyebrow mb-3 text-ash">#OUTWESTFITS</p>
          <h2 className="display text-[clamp(34px,5.4vw,72px)]">@{IG}</h2>
          <p className="mt-3 max-w-md text-ash">Tag us in your fit for a chance to be featured — and to win next month&apos;s drop before anyone else.</p>
        </div>
        <a href={url} target="_blank" rel="noreferrer" className="btn-dark self-start md:self-auto">
          <Icon name="instagram" size={18} /> Follow on Instagram
        </a>
      </div>
      <div className="grid grid-cols-3 gap-1 md:grid-cols-6">
        {(posts?.length ? posts.slice(0, 6) : TILES).map((t, i) => {
          const isPost = "permalink" in t;
          return (
            <a
              key={isPost ? t.id : i}
              href={isPost ? t.permalink : url}
              target="_blank"
              rel="noreferrer"
              className="group relative block aspect-square overflow-hidden bg-beige"
              aria-label={t.caption ?? "Instagram post"}
            >
              <div className="h-full w-full transition-transform duration-700 group-hover:scale-110">
                {isPost ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={t.image} alt={t.caption ?? ""} loading="lazy" className="h-full w-full object-cover" />
                ) : (
                  <ProductArt kind={t.kind} hex={t.hex} bg={t.bg} view={t.view} alt="" />
                )}
              </div>
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-ink/60 p-3 text-center text-bone opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                <Icon name="instagram" size={26} />
                {t.caption && <p className="line-clamp-2 hidden text-[13px] sm:block">{t.caption}</p>}
              </div>
            </a>
          );
        })}
      </div>
    </section>
  );
}
