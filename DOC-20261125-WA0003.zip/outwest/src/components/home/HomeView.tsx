"use client";

import Link from "next/link";
import { useMemo, useRef, useState } from "react";
import { liveCategories } from "@/lib/catalog";
import type { Product } from "@/lib/types";
import { Icon } from "@/components/ui/Icon";
import { ProductArt } from "@/components/product/ProductArt";
import { ProductCard } from "@/components/product/ProductCard";
import { Newsletter } from "@/components/layout/Footer";
import { useStore } from "@/components/providers/StoreProvider";
import { inr } from "@/lib/pricing";
import { InstagramSection, type IgPost } from "./InstagramSection";

function Hero() {
  const { settings } = useStore();
  return (
    <section className="relative flex min-h-[640px] h-[100svh] max-h-[1000px] flex-col overflow-hidden bg-ink text-bone">
      {/* light */}
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_55%_at_65%_42%,#3a3936_0%,#161615_55%,#0b0b0b_100%)]" />
      <div className="pointer-events-none absolute inset-0 opacity-[0.07] [background-image:repeating-linear-gradient(90deg,#fff_0_1px,transparent_1px_120px)]" />

      {/* garments */}
      <div className="absolute inset-x-[4%] top-[9%] bottom-[46%] md:inset-y-[8%] md:left-[38%] md:right-[2%]">
        <div className="animate-slow-zoom relative h-full w-full">
          <div className="animate-float absolute left-[2%] top-[6%] h-[78%] w-[62%] opacity-90 [animation-delay:-3s]">
            <ProductArt kind="oversized" hex="#3a3a38" bg="transparent" alt="" eager />
          </div>
          <div className="animate-float absolute right-[0%] top-0 h-full w-[72%]">
            <ProductArt kind="hoodie" hex="#e9e4da" view="back" bg="transparent" alt="Concrete Season hoodie in bone" eager />
          </div>
        </div>
      </div>

      {/* giant wordmark */}
      <p
        aria-hidden
        className="display pointer-events-none absolute inset-x-0 bottom-[-0.08em] select-none whitespace-nowrap text-center text-[21vw] leading-none text-bone/[0.08] md:text-[19.5vw]"
      >
        OUT WEST
      </p>

      <div className="wrap relative mt-auto bg-gradient-to-t from-ink via-ink/85 to-transparent pb-10 pt-16 md:mb-auto md:mt-0 md:bg-none md:pb-0 md:pt-24">
        <p className="eyebrow animate-rise text-bone/70">{settings.heroEyebrow}</p>
        <h1 className="display animate-rise mt-4 max-w-[9ch] text-[clamp(50px,8vw,128px)] [animation-delay:.12s]">
          {settings.heroTitle}
        </h1>
        <p className="animate-rise mt-5 max-w-sm text-[16px] leading-relaxed text-bone/75 [animation-delay:.24s]">
          {settings.heroText}
        </p>
        <div className="animate-rise mt-8 grid grid-cols-2 gap-3 sm:flex [animation-delay:.36s]">
          <Link href="/shop?tag=new" className="btn-light px-4 sm:px-7">Shop the drop <Icon name="arrow" size={16} /></Link>
          <Link href="/shop" className="btn border border-bone/40 px-4 text-bone hover:bg-bone hover:text-ink sm:px-7">Explore all</Link>
        </div>
      </div>

      <div className="wrap relative hidden pb-8 md:flex md:items-end md:justify-between">
        <p className="text-[12px] uppercase tracking-[0.18em] text-bone/50">400 GSM fleece · 240 GSM jersey · Made in India</p>
        <a href="#categories" className="flex items-center gap-3 text-[12px] uppercase tracking-[0.18em] text-bone/70 hover:text-bone">
          Scroll <span className="relative block h-10 w-px overflow-hidden bg-bone/25"><span className="absolute inset-x-0 top-0 h-1/2 animate-[marquee_1.6s_linear_infinite] bg-bone" /></span>
        </a>
      </div>
    </section>
  );
}

function WordBand({ words, dark }: { words: string[]; dark?: boolean }) {
  return (
    <div className={`overflow-hidden border-y py-5 ${dark ? "border-bone/10 bg-ink text-bone" : "border-ink/10 bg-bone text-ink"}`}>
      <div className="animate-marquee flex w-max [animation-duration:40s]">
        {[0, 1].map((k) => (
          <div key={k} className="flex shrink-0 items-center" aria-hidden={k === 1}>
            {[...words, ...words].map((w, i) => (
              <span key={i} className="display flex items-center gap-8 px-8 text-[clamp(28px,4vw,52px)]">
                <span className={i % 2 ? "text-transparent [-webkit-text-stroke:1.2px_currentColor]" : ""}>{w}</span>
                <span className="text-[0.5em]">✦</span>
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

function SectionHead({ eyebrow, title, href, cta }: { eyebrow: string; title: string; href?: string; cta?: string }) {
  return (
    <div className="reveal mb-8 flex items-end justify-between gap-6 md:mb-12">
      <div>
        <p className="eyebrow mb-3 text-ash">{eyebrow}</p>
        <h2 className="display text-[clamp(34px,5.4vw,72px)]">{title}</h2>
      </div>
      {href && (
        <Link href={href} className="group hidden shrink-0 items-center gap-2 border-b border-ink pb-1 text-[12px] font-semibold uppercase tracking-[0.16em] sm:inline-flex">
          {cta ?? "View all"} <Icon name="arrow" size={14} className="transition-transform group-hover:translate-x-1" />
        </Link>
      )}
    </div>
  );
}

function Categories({ products }: { products: Product[] }) {
  const { settings } = useStore();
  const cats = liveCategories(settings.categories);
  if (!cats.length) return null;
  const odd = cats.length % 2 === 1;
  return (
    <section id="categories" className="wrap scroll-mt-20 py-16 md:py-24">
      <SectionHead eyebrow="Shop by category" title="Find your uniform" href="/shop" cta="Shop all" />
      <div className={`grid grid-cols-2 gap-2 sm:gap-3 ${cats.length === 2 || cats.length === 4 ? "lg:grid-cols-2" : "lg:grid-cols-3"}`}>
        {cats.map((c, i) => {
          const count = products.filter((p) => p.category === c.slug).length;
          const dark = ["#111111", "#3a3a38"].includes(c.colour);
          return (
            <Link
              key={c.slug}
              href={`/shop?category=${c.slug}`}
              className={`reveal group relative block overflow-hidden ${odd && i === 0 ? "col-span-2 aspect-[16/11] lg:col-span-1 lg:aspect-[5/6]" : "aspect-[4/5] sm:aspect-[5/6]"}`}
              style={{ transitionDelay: `${(i % 3) * 80}ms` }}
            >
              <div className="absolute inset-0 transition-transform duration-[1.2s] ease-out group-hover:scale-[1.06]">
                <ProductArt kind={c.kind} hex={c.colour} view={i % 2 ? "front" : "flat"} bg={dark ? "#d9cfbf" : "#2b2a28"} alt={c.name} />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-ink/60 via-transparent to-transparent" />
              <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-2 p-4 text-bone sm:p-6">
                <div>
                  <h3 className="display text-[clamp(20px,2.6vw,38px)]">{c.name}</h3>
                  <p className="mt-1 hidden text-[13px] opacity-80 sm:block">{c.blurb} · {count} styles</p>
                </div>
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-bone text-ink transition-transform duration-500 group-hover:-rotate-45">
                  <Icon name="arrow" size={16} />
                </span>
              </div>
            </Link>
          );
        })}
      </div>
    </section>
  );
}

function Rail({ products }: { products: Product[] }) {
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (dir: number) => {
    const el = ref.current;
    if (!el) return;
    el.scrollBy({ left: dir * el.clientWidth * 0.8, behavior: "smooth" });
  };
  return (
    <section className="py-16 md:py-24">
      <div className="wrap">
        <div className="flex items-end justify-between gap-6">
          <div className="flex-1"><SectionHead eyebrow="Just landed" title="New Arrivals" /></div>
          <div className="mb-8 hidden gap-2 md:mb-12 md:flex">
            <button aria-label="Previous" onClick={() => scroll(-1)} className="grid h-12 w-12 place-items-center rounded-full border border-ink/20 hover:bg-ink hover:text-bone"><Icon name="arrowLeft" size={18} /></button>
            <button aria-label="Next" onClick={() => scroll(1)} className="grid h-12 w-12 place-items-center rounded-full border border-ink/20 hover:bg-ink hover:text-bone"><Icon name="arrow" size={18} /></button>
          </div>
        </div>
      </div>
      <div
        ref={ref}
        tabIndex={0}
        aria-label="New arrivals"
        onKeyDown={(e) => (e.key === "ArrowRight" ? scroll(1) : e.key === "ArrowLeft" ? scroll(-1) : null)}
        className="no-scrollbar flex snap-x snap-mandatory gap-3 overflow-x-auto scroll-px-4 px-4 sm:scroll-px-6 sm:px-6 lg:scroll-px-10 lg:px-10 [&>*]:min-w-0"
      >
        {products.map((p, i) => (
          <div key={p.id} className="w-[68%] shrink-0 snap-start sm:w-[42%] md:w-[31%] lg:w-[23.5%]">
            <ProductCard product={p} priority={i < 2} />
          </div>
        ))}
        <Link href="/shop?tag=new" className="flex w-[68%] shrink-0 snap-start flex-col items-center justify-center gap-4 bg-ink text-bone sm:w-[42%] md:w-[31%] lg:w-[23.5%]">
          <span className="display text-[34px]">View all</span>
          <span className="grid h-12 w-12 place-items-center rounded-full bg-bone text-ink"><Icon name="arrow" /></span>
        </Link>
      </div>
    </section>
  );
}

function Campaign() {
  return (
    <section className="relative overflow-hidden bg-sand">
      <div className="wrap grid items-center gap-10 py-16 md:grid-cols-2 md:py-0">
        <div className="reveal relative order-2 aspect-square md:order-1 md:aspect-auto md:h-[720px]">
          <div className="absolute left-[2%] top-[8%] h-[80%] w-[58%] -rotate-6">
            <ProductArt kind="oversized" hex="#111111" bg="transparent" alt="" />
          </div>
          <div className="absolute right-[2%] top-[14%] h-[80%] w-[58%] rotate-6">
            <ProductArt kind="oversized" hex="#f3f1ec" view="back" bg="transparent" alt="" />
          </div>
          <div className="absolute left-[24%] top-[4%] h-[86%] w-[54%]">
            <ProductArt kind="oversized" hex="#3a3a38" view="back" bg="transparent" alt="The Oversized Edit" />
          </div>
        </div>
        <div className="reveal order-1 md:order-2 md:pl-10">
          <p className="eyebrow mb-4 text-ink/60">The Oversized Edit</p>
          <h2 className="display text-[clamp(44px,7vw,104px)]">Heavier.<br />Boxier.<br />Better.</h2>
          <p className="mt-6 max-w-md text-[16px] leading-relaxed text-ink/70">
            240 GSM combed cotton, dropped shoulders and a collar that won&apos;t give up. Our best-selling silhouette — now in eight colourways.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/shop?category=oversized-t-shirts" className="btn-dark">Shop oversized <Icon name="arrow" size={16} /></Link>
            <Link href="/help/size-guide" className="btn-line">Size guide</Link>
          </div>
        </div>
      </div>
    </section>
  );
}

function BestSellers({ products }: { products: Product[] }) {
  const tabs = [
    { k: "all", l: "All" },
    { k: "tops", l: "Tees" },
    { k: "hoodies", l: "Hoodies" },
    { k: "bottoms", l: "Pants" },
    { k: "accessories", l: "Accessories" },
  ];
  const [tab, setTab] = useState("all");
  const list = useMemo(() => {
    const f = products.filter((p) =>
      tab === "all"
        ? true
        : tab === "tops"
          ? ["t-shirts", "oversized-t-shirts", "shirts"].includes(p.category)
          : tab === "hoodies"
            ? p.category === "hoodies"
            : tab === "bottoms"
              ? p.category === "pants"
              : p.category === "accessories",
    );
    return f.slice(0, 8);
  }, [tab, products]);

  return (
    <section className="wrap py-16 md:py-24">
      <SectionHead eyebrow="Most wanted" title="Best Sellers" href="/shop?tag=bestseller" />
      <div className="no-scrollbar -mx-4 mb-8 flex gap-2 overflow-x-auto px-4 sm:mx-0 sm:px-0" role="tablist">
        {tabs.map((t) => (
          <button
            key={t.k}
            role="tab"
            aria-selected={tab === t.k}
            onClick={() => setTab(t.k)}
            className={`h-10 shrink-0 rounded-full px-5 text-[13px] font-semibold transition ${tab === t.k ? "bg-ink text-bone" : "border border-ink/15 hover:border-ink"}`}
          >
            {t.l}
          </button>
        ))}
      </div>
      {list.length ? (
        <div className="grid grid-cols-2 gap-x-3 gap-y-10 md:grid-cols-3 lg:grid-cols-4">
          {list.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      ) : (
        <p className="py-10 text-ash">Nothing here yet — check back after the next drop.</p>
      )}
    </section>
  );
}

function Values() {
  const { settings } = useStore();
  const v = [
    { i: "truck" as const, t: "Free shipping", s: `On every order above ${inr(settings.freeShippingThreshold)}` },
    settings.codEnabled
      ? { i: "cash" as const, t: "Cash on Delivery", s: "Pay at your doorstep, pan-India" }
      : { i: "cash" as const, t: "UPI & cards", s: "GPay, PhonePe, Paytm & all cards" },
    { i: "refresh" as const, t: "7-day returns", s: "Easy exchanges, no questions" },
    { i: "shield" as const, t: "Secure payments", s: "UPI, cards & netbanking via Razorpay" },
  ];
  return (
    <section className="border-y border-ink/10">
      <div className="wrap grid grid-cols-2 lg:grid-cols-4">
        {v.map((x, i) => (
          <div key={x.t} className={`flex flex-col gap-3 py-8 sm:flex-row sm:items-center sm:gap-4 ${i % 2 ? "pl-4 sm:pl-6" : "pr-4"} ${i > 1 ? "border-t border-ink/10 lg:border-t-0" : ""} ${i ? "lg:border-l lg:border-ink/10 lg:pl-8" : ""}`}>
            <Icon name={x.i} size={26} strokeWidth={1.3} />
            <div>
              <p className="text-[14px] font-semibold">{x.t}</p>
              <p className="text-[13px] text-ash">{x.s}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Story() {
  return (
    <section className="bg-ink text-bone">
      <div className="wrap grid gap-12 py-20 md:grid-cols-[1.2fr_1fr] md:py-28">
        <h2 className="reveal display text-[clamp(38px,6vw,88px)]">
          Designed in Bengaluru.<br />
          <span className="text-bone/40">Made in India.</span><br />
          Worn everywhere.
        </h2>
        <div className="reveal grid content-end gap-8">
          <p className="max-w-md text-[16px] leading-relaxed text-bone/70">
            OUT WEST started with one heavyweight tee and a simple rule: make the things we couldn&apos;t find. Every piece is cut, knit and finished by partner mills in Tiruppur and Ludhiana — in small runs, so nothing goes to waste.
          </p>
          <dl className="grid grid-cols-3 gap-4 border-t border-bone/15 pt-6">
            {[["240", "GSM jersey"], ["400", "GSM fleece"], ["100%", "Indian made"]].map(([n, l]) => (
              <div key={l}>
                <dt className="display text-[clamp(28px,3.5vw,44px)]">{n}</dt>
                <dd className="mt-1 text-[12px] uppercase tracking-[0.14em] text-bone/50">{l}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </section>
  );
}

export function HomeView({ products, instagram }: { products: Product[]; instagram?: IgPost[] }) {
  const live = products.filter((p) => p.active);
  const fresh = live.filter((p) => p.tags.includes("new")).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const best = live.filter((p) => p.tags.includes("bestseller")).sort((a, b) => b.reviews - a.reviews);
  return (
    <>
      <Hero />
      <WordBand dark words={["Heavyweight", "Boxy fits", "Built to last", "Made in India", "Concrete Season"]} />
      <Categories products={live} />
      <Rail products={fresh.length ? fresh : live.slice(0, 8)} />
      <Campaign />
      <BestSellers products={best.length ? best : live} />
      <Values />
      <Story />
      <InstagramSection posts={instagram} />
      <Newsletter />
    </>
  );
}
