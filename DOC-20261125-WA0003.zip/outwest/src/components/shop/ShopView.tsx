"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { categoryBySlug, discountPct, liveCategories, stockKey } from "@/lib/catalog";
import { useStore } from "@/components/providers/StoreProvider";
import { inr } from "@/lib/pricing";
import type { Product } from "@/lib/types";
import { Icon } from "@/components/ui/Icon";
import { ProductCard } from "@/components/product/ProductCard";

interface Filters {
  category: string;
  tag: string;
  q: string;
  sort: string;
  size: string;
  colour: string;
  maxPrice?: number;
  inStock?: boolean;
}

const SORTS: [string, string][] = [
  ["featured", "Featured"],
  ["newest", "Newest"],
  ["price-asc", "Price: low to high"],
  ["price-desc", "Price: high to low"],
  ["discount", "Biggest discount"],
  ["rating", "Top rated"],
];

export function ShopView({ products, initial }: { products: Product[]; initial: Filters }) {
  const router = useRouter();
  const { settings } = useStore();
  const CATEGORIES = liveCategories(settings.categories);
  const [f, setF] = useState<Filters>(initial);
  const [drawer, setDrawer] = useState(false);
  const [dense, setDense] = useState(false);

  useEffect(() => setF((prev) => ({ ...prev, category: initial.category, tag: initial.tag, q: initial.q })), [initial.category, initial.tag, initial.q]);

  const update = (patch: Partial<Filters>) => {
    const next = { ...f, ...patch };
    setF(next);
    const qs = new URLSearchParams();
    (["category", "tag", "q", "size", "colour"] as const).forEach((k) => next[k] && qs.set(k, next[k]));
    if (next.sort !== "featured") qs.set("sort", next.sort);
    router.replace(`/shop${qs.toString() ? `?${qs}` : ""}`, { scroll: false });
  };

  const priceCeil = Math.max(...products.map((p) => p.price), 0);
  const allSizes = useMemo(() => {
    const order = ["XS", "S", "M", "L", "XL", "XXL", "28", "30", "32", "34", "36", "One Size"];
    return order.filter((s) => products.some((p) => p.sizes.includes(s)));
  }, [products]);
  const allColours = useMemo(() => {
    const m = new Map<string, string>();
    products.forEach((p) => p.colours.forEach((c) => m.set(c.name, c.hex)));
    return [...m.entries()];
  }, [products]);

  const list = useMemo(() => {
    const q = f.q.trim().toLowerCase();
    let r = products.filter(
      (p) =>
        (!f.category || p.category === f.category) &&
        (!f.tag || p.tags.includes(f.tag as "new" | "bestseller")) &&
        (!q || `${p.name} ${p.category} ${p.colours.map((c) => c.name).join(" ")}`.toLowerCase().includes(q)) &&
        (!f.size || p.sizes.includes(f.size)) &&
        (!f.colour || p.colours.some((c) => c.name === f.colour)) &&
        (!f.maxPrice || p.price <= f.maxPrice) &&
        (!f.inStock || Object.values(p.stock).some((n) => n > 0)) &&
        (!f.size || !f.inStock || p.colours.some((c) => (p.stock[stockKey(c.name, f.size)] ?? 0) > 0)),
    );
    const by: Record<string, (a: Product, b: Product) => number> = {
      newest: (a, b) => b.createdAt.localeCompare(a.createdAt),
      "price-asc": (a, b) => a.price - b.price,
      "price-desc": (a, b) => b.price - a.price,
      discount: (a, b) => discountPct(b) - discountPct(a),
      rating: (a, b) => b.rating - a.rating,
    };
    if (by[f.sort]) r = [...r].sort(by[f.sort]);
    return r;
  }, [products, f]);

  const cat = categoryBySlug(f.category, CATEGORIES);
  const title = f.q ? `“${f.q}”` : cat?.name ?? (f.tag === "new" ? "New Arrivals" : f.tag === "bestseller" ? "Best Sellers" : "Shop All");
  const activeCount = [f.size, f.colour, f.maxPrice, f.inStock].filter(Boolean).length;

  return (
    <div className="pb-20">
      <section className="wrap pb-6 pt-10 md:pt-16">
        <nav className="mb-4 text-[12px] text-ash" aria-label="Breadcrumb">
          <Link href="/" className="hover:text-ink">Home</Link> / <Link href="/shop" className="hover:text-ink">Shop</Link>
          {cat && <> / <span className="text-ink">{cat.name}</span></>}
        </nav>
        <h1 className="display text-[clamp(40px,7vw,96px)]">{title}</h1>
        <p className="mt-3 text-ash">{cat?.blurb ?? (f.q ? "Search results" : "Premium streetwear, made in India.")} · {list.length} {list.length === 1 ? "style" : "styles"}</p>
      </section>

      <div className="sticky top-16 z-30 border-y border-ink/10 bg-bone/95 backdrop-blur lg:top-[72px]">
        <div className="wrap flex items-center gap-3 py-3">
          <div className="no-scrollbar -ml-1 flex flex-1 gap-2 overflow-x-auto pl-1">
            <button onClick={() => update({ category: "" })} className={`h-9 shrink-0 rounded-full px-4 text-[13px] font-medium ${!f.category ? "bg-ink text-bone" : "border border-ink/15 hover:border-ink"}`}>All</button>
            {CATEGORIES.map((c) => (
              <button key={c.slug} onClick={() => update({ category: c.slug })} className={`h-9 shrink-0 rounded-full px-4 text-[13px] font-medium ${f.category === c.slug ? "bg-ink text-bone" : "border border-ink/15 hover:border-ink"}`}>
                {c.name}
              </button>
            ))}
          </div>
          <label className="hidden items-center gap-2 text-[13px] md:flex">
            <span className="text-ash">Sort</span>
            <select value={f.sort} onChange={(e) => update({ sort: e.target.value })} className="h-9 border border-ink/15 bg-transparent px-2 text-[14px]">
              {SORTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          </label>
          <button onClick={() => setDense((d) => !d)} aria-label="Toggle grid density" className="hidden h-9 w-9 place-items-center border border-ink/15 lg:grid"><Icon name="grid" size={16} /></button>
          <button onClick={() => setDrawer(true)} className="flex h-9 shrink-0 items-center gap-2 bg-ink px-4 text-[12px] font-semibold uppercase tracking-[0.12em] text-bone">
            Filter{activeCount ? ` (${activeCount})` : ""}
          </button>
        </div>
      </div>

      <div className="wrap pt-8">
        {(f.tag || f.q || activeCount > 0) && (
          <div className="mb-6 flex flex-wrap gap-2">
            {f.tag && <Chip label={f.tag === "new" ? "New in" : "Best sellers"} onClear={() => update({ tag: "" })} />}
            {f.q && <Chip label={`Search: ${f.q}`} onClear={() => update({ q: "" })} />}
            {f.size && <Chip label={`Size ${f.size}`} onClear={() => update({ size: "" })} />}
            {f.colour && <Chip label={f.colour} onClear={() => update({ colour: "" })} />}
            {f.maxPrice && <Chip label={`Under ${inr(f.maxPrice)}`} onClear={() => update({ maxPrice: undefined })} />}
            {f.inStock && <Chip label="In stock" onClear={() => update({ inStock: false })} />}
          </div>
        )}
        {list.length ? (
          <div className={`grid grid-cols-2 gap-x-3 gap-y-10 md:grid-cols-3 ${dense ? "lg:grid-cols-5" : "lg:grid-cols-4"}`}>
            {list.map((p, i) => <ProductCard key={p.id} product={p} priority={i < 4} />)}
          </div>
        ) : (
          <div className="py-24 text-center">
            <p className="display text-[32px]">Nothing matches — yet.</p>
            <p className="mt-3 text-ash">Try removing a filter or browse everything.</p>
            <button onClick={() => update({ category: "", tag: "", q: "", size: "", colour: "", maxPrice: undefined, inStock: false })} className="btn-dark mt-6">Clear all filters</button>
          </div>
        )}
      </div>

      {/* Filter drawer */}
      <div className={`fixed inset-0 z-50 ${drawer ? "" : "pointer-events-none"}`}>
        <div onClick={() => setDrawer(false)} className={`absolute inset-0 bg-ink/50 transition-opacity duration-500 ${drawer ? "opacity-100" : "opacity-0"}`} />
        <aside role="dialog" aria-label="Filters" className={`absolute right-0 top-0 flex h-full w-full max-w-[420px] flex-col bg-bone transition-transform duration-500 ${drawer ? "translate-x-0" : "translate-x-full"}`}>
          <div className="flex h-16 items-center justify-between border-b border-ink/10 px-5">
            <p className="eyebrow">Filter & sort</p>
            <button aria-label="Close filters" className="grid h-11 w-11 place-items-center" onClick={() => setDrawer(false)}><Icon name="close" /></button>
          </div>
          <div className="flex-1 space-y-8 overflow-y-auto px-5 py-6">
            <fieldset>
              <legend className="label">Sort by</legend>
              <div className="grid gap-1">
                {SORTS.map(([v, l]) => (
                  <label key={v} className="flex h-10 cursor-pointer items-center gap-3 text-[15px]">
                    <input type="radio" name="sort" checked={f.sort === v} onChange={() => update({ sort: v })} className="h-4 w-4 accent-ink" /> {l}
                  </label>
                ))}
              </div>
            </fieldset>
            <fieldset>
              <legend className="label">Size</legend>
              <div className="flex flex-wrap gap-2">
                {allSizes.map((s) => (
                  <button key={s} onClick={() => update({ size: f.size === s ? "" : s })} className={`h-10 min-w-12 border px-3 text-[13px] font-semibold ${f.size === s ? "border-ink bg-ink text-bone" : "border-ink/15 hover:border-ink"}`}>{s}</button>
                ))}
              </div>
            </fieldset>
            <fieldset>
              <legend className="label">Colour</legend>
              <div className="grid grid-cols-2 gap-2">
                {allColours.map(([name, hex]) => (
                  <button key={name} onClick={() => update({ colour: f.colour === name ? "" : name })} className={`flex h-11 items-center gap-3 border px-3 text-[14px] ${f.colour === name ? "border-ink" : "border-ink/15 hover:border-ink/50"}`}>
                    <span className="h-5 w-5 rounded-full border border-ink/20" style={{ background: hex }} /> {name}
                  </button>
                ))}
              </div>
            </fieldset>
            <fieldset>
              <legend className="label">Max price: {inr(f.maxPrice ?? priceCeil)}</legend>
              <input type="range" min={500} max={priceCeil} step={100} value={f.maxPrice ?? priceCeil} onChange={(e) => update({ maxPrice: +e.target.value >= priceCeil ? undefined : +e.target.value })} className="w-full accent-ink" />
            </fieldset>
            <label className="flex cursor-pointer items-center gap-3 text-[15px]">
              <input type="checkbox" checked={!!f.inStock} onChange={(e) => update({ inStock: e.target.checked })} className="h-5 w-5 accent-ink" /> Hide sold-out styles
            </label>
          </div>
          <div className="grid grid-cols-2 gap-3 border-t border-ink/10 p-5">
            <button className="btn-line" onClick={() => update({ size: "", colour: "", maxPrice: undefined, inStock: false, sort: "featured" })}>Clear</button>
            <button className="btn-dark" onClick={() => setDrawer(false)}>Show {list.length}</button>
          </div>
        </aside>
      </div>
    </div>
  );
}

function Chip({ label, onClear }: { label: string; onClear: () => void }) {
  return (
    <button onClick={onClear} className="flex h-9 items-center gap-2 border border-ink/15 bg-white px-3 text-[13px] hover:border-ink">
      {label} <Icon name="close" size={14} />
    </button>
  );
}
