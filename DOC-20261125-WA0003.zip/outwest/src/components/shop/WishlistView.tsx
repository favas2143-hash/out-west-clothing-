"use client";

import Link from "next/link";
import type { Product } from "@/lib/types";
import { useStore } from "@/components/providers/StoreProvider";
import { ProductCard } from "@/components/product/ProductCard";
import { Icon } from "@/components/ui/Icon";

export function WishlistView({ products }: { products: Product[] }) {
  const { wishlist, hydrated } = useStore();
  const items = products.filter((p) => wishlist.includes(p.id));
  return (
    <div className="wrap py-10 md:py-16">
      <h1 className="display text-[clamp(40px,6vw,80px)]">Wishlist</h1>
      <p className="mt-2 text-ash">{hydrated ? `${items.length} saved ${items.length === 1 ? "piece" : "pieces"}` : " "}</p>
      {hydrated && items.length === 0 ? (
        <div className="flex flex-col items-center gap-4 py-24 text-center">
          <Icon name="heart" size={40} strokeWidth={1.2} />
          <p className="display text-[28px]">Nothing saved yet</p>
          <p className="text-ash">Tap the heart on any product to keep it here.</p>
          <Link href="/shop" className="btn-dark">Start browsing</Link>
        </div>
      ) : (
        <div className="mt-10 grid grid-cols-2 gap-x-3 gap-y-10 md:grid-cols-3 lg:grid-cols-4">
          {items.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      )}
    </div>
  );
}
