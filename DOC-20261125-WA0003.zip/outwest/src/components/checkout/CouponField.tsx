"use client";

import { useState } from "react";
import { couponLabel } from "@/lib/pricing";
import { useStore } from "@/components/providers/StoreProvider";
import { Icon } from "@/components/ui/Icon";

/** Applies a coupon code against the server and keeps it in the store until checkout. */
export function CouponField({ subtotal, compact }: { subtotal: number; compact?: boolean }) {
  const { coupon, setCoupon } = useStore();
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const apply = async () => {
    if (!code.trim()) return;
    setBusy(true);
    setError("");
    const r = await fetch("/api/coupons/validate", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ code, subtotal }) });
    const j = await r.json();
    setBusy(false);
    if (!r.ok) return setError(j.error || "Couldn't apply this code");
    setCoupon(j.coupon);
    setCode("");
  };

  if (coupon)
    return (
      <div className="flex items-center justify-between gap-3 border border-dashed border-ink/30 bg-beige/60 px-3 py-2.5 text-[13px]">
        <span className="flex min-w-0 items-center gap-2"><Icon name="tag" size={16} /><span className="truncate"><b>{coupon.code}</b> · {couponLabel(coupon)}</span></span>
        <button type="button" onClick={() => setCoupon(null)} className="shrink-0 text-[12px] uppercase tracking-[0.1em] underline underline-offset-4">Remove</button>
      </div>
    );

  return (
    <div>
      <div className="flex">
        <label htmlFor="coupon-code" className="sr-only">Coupon code</label>
        <input
          id="coupon-code"
          value={code}
          onChange={(e) => setCode(e.target.value.toUpperCase())}
          onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); apply(); } }}
          placeholder="Coupon code"
          className="field h-11 uppercase"
        />
        <button type="button" disabled={busy} onClick={apply} className="btn-dark h-11 px-5">{busy ? "…" : "Apply"}</button>
      </div>
      {error && <p className="mt-2 text-[13px] text-sale">{error}</p>}
      {!compact && !error && <p className="mt-2 text-[12px] text-ash">First order? Try WELCOME10</p>}
    </div>
  );
}
