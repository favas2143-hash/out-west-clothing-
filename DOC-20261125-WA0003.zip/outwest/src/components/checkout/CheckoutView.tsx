"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { computeTotals, deliveryEstimate, INDIAN_STATES, inr } from "@/lib/pricing";
import { CouponField } from "./CouponField";
import type { Address } from "@/lib/types";
import { Icon } from "@/components/ui/Icon";
import { lineKey, useStore } from "@/components/providers/StoreProvider";
import { ProductArt } from "@/components/product/ProductArt";
import { Logo } from "@/components/layout/Header";

declare global {
  interface Window {
    Razorpay?: new (opts: Record<string, unknown>) => { open: () => void; on: (e: string, cb: (r: unknown) => void) => void };
  }
}

interface Pending {
  number: string;
  accessKey: string;
  total: number;
  razorpay?: { keyId: string; orderId: string; amount: number; currency: string };
}

const EMPTY: Address = { name: "", phone: "", line1: "", line2: "", city: "", state: "", pincode: "" };

function loadRazorpay() {
  return new Promise<boolean>((resolve) => {
    if (window.Razorpay) return resolve(true);
    const s = document.createElement("script");
    s.src = "https://checkout.razorpay.com/v1/checkout.js";
    s.onload = () => resolve(true);
    s.onerror = () => resolve(false);
    document.body.appendChild(s);
  });
}

export function CheckoutView({ gatewayLive }: { gatewayLive: boolean }) {
  const router = useRouter();
  const { cart, subtotal, hydrated, clearCart, user, settings, coupon } = useStore();
  const [email, setEmail] = useState("");
  const [addr, setAddr] = useState<Address>(EMPTY);
  const [method, setMethod] = useState<"razorpay" | "cod">("razorpay");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [pending, setPending] = useState<Pending | null>(null);
  const [demoOpen, setDemoOpen] = useState(false);
  const [summaryOpen, setSummaryOpen] = useState(false);

  // prefill from account / last order
  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem("ow_address") || "null") as { email: string; addr: Address } | null;
      if (saved) {
        setEmail(saved.email);
        setAddr({ ...EMPTY, ...saved.addr });
      }
    } catch {}
    if (user) {
      setEmail((e) => e || user.email);
      setAddr((a) => ({ ...a, name: a.name || user.name, phone: a.phone || user.phone || "" }));
    }
  }, [user]);

  const t = computeTotals(subtotal, { coupon, cod: method === "cod", settings });
  const codAllowed = settings.codEnabled && computeTotals(subtotal, { coupon, cod: true, settings }).total <= settings.codMaxOrder;
  useEffect(() => {
    if (!codAllowed && method === "cod") setMethod("razorpay");
  }, [codAllowed, method]);
  const eta = deliveryEstimate(addr.pincode);
  const set = (k: keyof Address) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setAddr({ ...addr, [k]: e.target.value });

  const finish = (p: Pending) => {
    clearCart();
    router.push(`/order/${p.number}?k=${p.accessKey}&placed=1`);
  };

  const verify = async (p: Pending, payload: Record<string, unknown>) => {
    const r = await fetch("/api/payments/razorpay/verify", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ orderNumber: p.number, accessKey: p.accessKey, ...payload }),
    });
    const j = await r.json();
    if (!r.ok) {
      setError(j.error || "Payment failed. You can retry — your order is saved.");
      setBusy(false);
      return;
    }
    finish(p);
  };

  const pay = async (p: Pending) => {
    setError("");
    if (!p.razorpay) {
      setDemoOpen(true);
      return;
    }
    setBusy(true);
    const ok = await loadRazorpay();
    if (!ok || !window.Razorpay) {
      setBusy(false);
      return setError("Couldn't load Razorpay. Check your connection and retry.");
    }
    const rzp = new window.Razorpay({
      key: p.razorpay.keyId,
      amount: p.razorpay.amount,
      currency: p.razorpay.currency,
      name: "OUT WEST",
      description: `Order ${p.number}`,
      order_id: p.razorpay.orderId,
      prefill: { name: addr.name, email, contact: addr.phone },
      notes: { order_number: p.number },
      theme: { color: "#0b0b0b" },
      handler: (resp: Record<string, string>) => verify(p, resp),
      modal: {
        ondismiss: () => {
          setBusy(false);
          setError("Payment was cancelled. Your order is saved — tap Pay to try again.");
        },
      },
    });
    rzp.on("payment.failed", () => setError("Payment failed. Try another method or UPI app."));
    rzp.open();
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (pending) return pay(pending);
    setBusy(true);
    try {
      const r = await fetch("/api/orders", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          items: cart.map(({ productId, colour, size, qty }) => ({ productId, colour, size, qty })),
          email,
          address: addr,
          paymentMethod: method,
          coupon: t.coupon,
        }),
      });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "Something went wrong");
      try { localStorage.setItem("ow_address", JSON.stringify({ email, addr })); } catch {}
      const p: Pending = { ...j.order, razorpay: j.razorpay };
      if (method === "cod") return finish(p);
      setPending(p);
      setBusy(false);
      pay(p);
    } catch (err) {
      setError((err as Error).message);
      setBusy(false);
    }
  };

  if (!hydrated) return <div className="min-h-screen" />;
  if (cart.length === 0 && !pending)
    return (
      <div className="wrap flex min-h-[60vh] flex-col items-center justify-center gap-4 py-20 text-center">
        <h1 className="display text-[44px]">Nothing to check out</h1>
        <Link href="/shop" className="btn-dark">Continue shopping</Link>
      </div>
    );

  const Summary = (
    <div className="space-y-5">
      <ul className="space-y-4">
        {cart.map((i) => (
          <li key={lineKey(i)} className="flex items-center gap-4">
            <div className="relative aspect-[4/5] w-16 shrink-0 bg-beige">
              <ProductArt kind={i.kind} hex={i.hex} src={i.image} alt={i.name} />
              <span className="absolute -right-2 -top-2 grid h-5 min-w-5 place-items-center rounded-full bg-ink px-1 text-[11px] font-bold text-bone">{i.qty}</span>
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[14px] font-medium">{i.name}</p>
              <p className="text-[13px] text-ash">{i.colour} · {i.size}</p>
            </div>
            <p className="text-[14px] font-semibold">{inr(i.price * i.qty)}</p>
          </li>
        ))}
      </ul>
      {!pending && (
        <div>
          <CouponField subtotal={subtotal} />
          {t.couponError && <p className="mt-2 text-[13px] text-sale">{t.couponError}</p>}
        </div>
      )}
      <dl className="space-y-2 border-t border-ink/10 pt-4 text-[14px]">
        <div className="flex justify-between"><dt>Subtotal</dt><dd>{inr(t.subtotal)}</dd></div>
        {t.discount > 0 && <div className="flex justify-between"><dt>Coupon ({t.coupon})</dt><dd className="text-sale">−{inr(t.discount)}</dd></div>}
        <div className="flex justify-between"><dt>Shipping</dt><dd>{t.shipping ? inr(t.shipping) : "Free"}</dd></div>
        {t.codFee > 0 && <div className="flex justify-between"><dt>COD handling</dt><dd>{inr(t.codFee)}</dd></div>}
        <div className="flex justify-between border-t border-ink/10 pt-3 text-[18px] font-semibold"><dt>Total</dt><dd>{inr(pending?.total ?? t.total)}</dd></div>
      </dl>
      <p className="text-[12px] text-ash">Prices include GST.</p>
    </div>
  );

  return (
    <div className="min-h-screen bg-bone">
      <header className="border-b border-ink/10 bg-bone">
        <div className="wrap flex h-16 items-center justify-between">
          <Link href="/" aria-label="OUT WEST home"><Logo /></Link>
          <span className="flex items-center gap-2 text-[12px] font-semibold uppercase tracking-[0.14em]"><Icon name="lock" size={16} /> Secure checkout</span>
        </div>
      </header>

      {/* Mobile summary toggle */}
      <div className="border-b border-ink/10 bg-white lg:hidden">
        <button onClick={() => setSummaryOpen((v) => !v)} className="wrap flex h-14 items-center justify-between text-[14px]">
          <span className="flex items-center gap-2 font-medium"><Icon name="bag" size={18} /> {summaryOpen ? "Hide" : "Show"} order summary</span>
          <b>{inr(pending?.total ?? t.total)}</b>
        </button>
        {summaryOpen && <div className="wrap pb-6">{Summary}</div>}
      </div>

      <div className="wrap grid gap-12 py-8 lg:grid-cols-[1fr_420px] lg:py-12">
        <form onSubmit={submit} className="space-y-10">
          {!user && (
            <p className="bg-beige px-4 py-3 text-[14px]">
              Have an account? <Link href="/account/login?next=/checkout" className="font-semibold underline underline-offset-4">Sign in</Link> for faster checkout and order history.
            </p>
          )}

          <fieldset disabled={!!pending} className="space-y-4">
            <legend className="display mb-4 text-[26px]">Contact</legend>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="email" className="label">Email</label>
                <input id="email" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className="field" />
              </div>
              <div>
                <label htmlFor="phone" className="label">Mobile number</label>
                <div className="flex">
                  <span className="grid h-12 place-items-center border border-r-0 border-ink/15 bg-beige px-3 text-[15px]">+91</span>
                  <input id="phone" required inputMode="numeric" autoComplete="tel-national" pattern="[6-9][0-9]{9}" maxLength={10} title="10-digit mobile number" value={addr.phone} onChange={(e) => setAddr({ ...addr, phone: e.target.value.replace(/\D/g, "") })} className="field" />
                </div>
              </div>
            </div>
          </fieldset>

          <fieldset disabled={!!pending} className="space-y-4">
            <legend className="display mb-4 text-[26px]">Delivery address</legend>
            <div>
              <label htmlFor="name" className="label">Full name</label>
              <input id="name" required autoComplete="name" value={addr.name} onChange={set("name")} className="field" />
            </div>
            <div>
              <label htmlFor="line1" className="label">Flat, house no., building</label>
              <input id="line1" required autoComplete="address-line1" value={addr.line1} onChange={set("line1")} className="field" />
            </div>
            <div>
              <label htmlFor="line2" className="label">Area, street, landmark (optional)</label>
              <input id="line2" autoComplete="address-line2" value={addr.line2} onChange={set("line2")} className="field" />
            </div>
            <div className="grid gap-4 sm:grid-cols-3">
              <div>
                <label htmlFor="pincode" className="label">PIN code</label>
                <input id="pincode" required inputMode="numeric" autoComplete="postal-code" pattern="[1-9][0-9]{5}" maxLength={6} title="6-digit PIN code" value={addr.pincode} onChange={(e) => setAddr({ ...addr, pincode: e.target.value.replace(/\D/g, "") })} className="field" />
              </div>
              <div>
                <label htmlFor="city" className="label">City</label>
                <input id="city" required autoComplete="address-level2" value={addr.city} onChange={set("city")} className="field" />
              </div>
              <div>
                <label htmlFor="state" className="label">State</label>
                <select id="state" required autoComplete="address-level1" value={addr.state} onChange={set("state")} className="field">
                  <option value="">Select</option>
                  {INDIAN_STATES.map((s) => <option key={s}>{s}</option>)}
                </select>
              </div>
            </div>
            {eta && <p className="flex items-center gap-2 text-[14px]"><Icon name="truck" size={18} /> Estimated delivery by <b>{eta.date}</b></p>}
          </fieldset>

          <fieldset disabled={!!pending} className="space-y-3">
            <legend className="display mb-4 text-[26px]">Payment</legend>
            <label className={`flex cursor-pointer gap-4 border bg-white p-5 transition ${method === "razorpay" ? "border-ink" : "border-ink/15"}`}>
              <input type="radio" name="pay" className="mt-1 h-5 w-5 accent-ink" checked={method === "razorpay"} onChange={() => setMethod("razorpay")} />
              <div className="flex-1">
                <p className="font-semibold">Pay online</p>
                <p className="text-[14px] text-ash">UPI (GPay, PhonePe, Paytm), cards, netbanking, wallets & EMI — secured by Razorpay</p>
                <div className="mt-3 flex flex-wrap gap-1.5 text-[11px] font-bold uppercase tracking-wider">
                  {["UPI", "Visa", "Mastercard", "RuPay", "Netbanking", "Wallets"].map((x) => <span key={x} className="border border-ink/15 px-2 py-1">{x}</span>)}
                </div>
              </div>
            </label>
            <label className={`flex gap-4 border bg-white p-5 transition ${!codAllowed ? "cursor-not-allowed opacity-50" : "cursor-pointer"} ${method === "cod" ? "border-ink" : "border-ink/15"}`}>
              <input type="radio" name="pay" className="mt-1 h-5 w-5 accent-ink" disabled={!codAllowed} checked={method === "cod"} onChange={() => setMethod("cod")} />
              <div className="flex-1">
                <p className="font-semibold">Cash on Delivery <span className="font-normal text-ash">(+{inr(settings.codFee)})</span></p>
                <p className="text-[14px] text-ash">{codAllowed ? "Pay with cash or UPI when your order arrives." : settings.codEnabled ? `Available on orders up to ${inr(settings.codMaxOrder)}.` : "Not available right now."}</p>
              </div>
              <Icon name="cash" size={24} />
            </label>
            {!gatewayLive && method === "razorpay" && (
              <p className="text-[13px] text-ash">Demo mode: Razorpay keys aren&apos;t configured, so payments are simulated. Add your keys in <code>.env</code> to go live.</p>
            )}
          </fieldset>

          {error && <p role="alert" className="border border-sale/30 bg-sale/10 px-4 py-3 text-[14px] text-sale">{error}</p>}

          <button disabled={busy} className="btn-dark h-14 w-full text-[14px]">
            {busy ? "Processing…" : method === "cod" ? `Place order · ${inr(t.total)}` : `${pending ? "Pay" : "Continue to pay"} ${inr(pending?.total ?? t.total)}`}
          </button>
          <p className="flex items-center justify-center gap-2 text-[12px] text-ash"><Icon name="shield" size={16} /> 256-bit SSL encryption · We never store card details</p>
        </form>

        <aside className="hidden h-fit bg-white p-6 lg:sticky lg:top-8 lg:block">
          <p className="eyebrow mb-5">Order summary</p>
          {Summary}
        </aside>
      </div>

      {demoOpen && pending && (
        <div className="fixed inset-0 z-50 grid place-items-end bg-ink/60 sm:place-items-center" role="dialog" aria-modal="true" aria-label="Test payment">
          <div className="animate-rise w-full max-w-md bg-white p-6 sm:p-8">
            <p className="eyebrow text-ash">Razorpay · Test mode</p>
            <p className="display mt-2 text-[34px]">{inr(pending.total)}</p>
            <p className="mt-1 text-[14px] text-ash">Order {pending.number} · OUT WEST</p>
            <div className="mt-6 grid gap-2">
              {["UPI — GPay / PhonePe / Paytm", "Card — Visa / Mastercard / RuPay", "Netbanking"].map((m, i) => (
                <label key={m} className="flex h-12 cursor-pointer items-center gap-3 border border-ink/15 px-4 text-[14px]">
                  <input type="radio" name="demo-m" defaultChecked={i === 0} className="accent-ink" /> {m}
                </label>
              ))}
            </div>
            <button
              className="btn-dark mt-6 w-full"
              disabled={busy}
              onClick={() => {
                setBusy(true);
                setDemoOpen(false);
                verify(pending, { demo: true });
              }}
            >
              Pay {inr(pending.total)}
            </button>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <button className="btn-line h-11" onClick={() => { setDemoOpen(false); verify(pending, { fail: true }); }}>Simulate failure</button>
              <button className="btn h-11 text-ash" onClick={() => { setDemoOpen(false); setError("Payment was cancelled. Your order is saved — tap Pay to try again."); }}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
