import { PAYMENT_LABEL, STATUS_FLOW, STATUS_LABEL } from "@/lib/orderStatus";
import { inr } from "@/lib/pricing";
import type { Order } from "@/lib/types";
import { ProductArt } from "@/components/product/ProductArt";

type O = Omit<Order, "accessKey">;

const fmt = (iso: string) =>
  new Date(iso).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" });

export function OrderTimeline({ order }: { order: O }) {
  if (order.status === "cancelled")
    return <p className="border border-sale/30 bg-sale/10 p-4 text-[15px] text-sale">This order was cancelled. Any online payment is refunded to the original method within 5–7 business days.</p>;
  if (order.status === "pending_payment")
    return <p className="bg-beige p-4 text-[15px]">We&apos;re waiting for your payment. If money was deducted, it will be confirmed automatically within a few minutes.</p>;
  const idx = STATUS_FLOW.indexOf(order.status);
  return (
    <ol className="relative grid gap-0 sm:grid-cols-6">
      {STATUS_FLOW.map((s, i) => {
        const done = i <= idx;
        const at = [...order.timeline].reverse().find((t) => t.status === s)?.at;
        return (
          <li key={s} className="relative flex gap-4 pb-6 sm:flex-col sm:gap-3 sm:pb-0">
            {i < STATUS_FLOW.length - 1 && (
              <span className={`absolute left-[11px] top-6 h-full w-0.5 sm:left-6 sm:top-[11px] sm:h-0.5 sm:w-full ${i < idx ? "bg-ink" : "bg-ink/15"}`} />
            )}
            <span className={`relative z-10 grid h-6 w-6 shrink-0 place-items-center rounded-full border-2 ${done ? "border-ink bg-ink" : "border-ink/20 bg-bone"}`}>
              {done && <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#f4f1ea" strokeWidth="3"><path d="M5 12.5l4.5 4.5L19 7" /></svg>}
            </span>
            <div>
              <p className={`text-[14px] font-semibold ${done ? "" : "text-ash"}`}>{STATUS_LABEL[s]}</p>
              {at && <p className="text-[12px] text-ash">{fmt(at)}</p>}
            </div>
          </li>
        );
      })}
    </ol>
  );
}

export function OrderDetail({ order }: { order: O }) {
  return (
    <div className="space-y-10">
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-ink/10 pb-6">
        <div>
          <p className="eyebrow text-ash">Order</p>
          <p className="display mt-1 text-[32px]">#{order.number}</p>
          <p className="text-[14px] text-ash">Placed {fmt(order.createdAt)}</p>
        </div>
        <span className="bg-ink px-3 py-1.5 text-[12px] font-semibold uppercase tracking-[0.12em] text-bone">{STATUS_LABEL[order.status]}</span>
      </div>

      <OrderTimeline order={order} />

      {order.awb && (
        <p className="bg-white p-4 text-[14px]">
          Shipped with <b>{order.courier || "our courier partner"}</b> · AWB <b className="tabular-nums">{order.awb}</b>
        </p>
      )}

      <div className="grid gap-10 md:grid-cols-[1.4fr_1fr]">
        <ul className="divide-y divide-ink/10 border-y border-ink/10">
          {order.items.map((i, n) => (
            <li key={n} className="flex items-center gap-4 py-4">
              <div className="aspect-[4/5] w-16 shrink-0 bg-beige"><ProductArt kind={i.kind} hex={i.hex} alt={i.name} /></div>
              <div className="min-w-0 flex-1">
                <p className="font-medium">{i.name}</p>
                <p className="text-[13px] text-ash">{i.colour} · {i.size} · Qty {i.qty}</p>
              </div>
              <p className="font-semibold">{inr(i.price * i.qty)}</p>
            </li>
          ))}
        </ul>
        <div className="space-y-6 text-[14px]">
          <dl className="space-y-2">
            <div className="flex justify-between"><dt>Subtotal</dt><dd>{inr(order.subtotal)}</dd></div>
            {order.discount > 0 && <div className="flex justify-between"><dt>Coupon {order.coupon}</dt><dd>−{inr(order.discount)}</dd></div>}
            <div className="flex justify-between"><dt>Shipping</dt><dd>{order.shipping ? inr(order.shipping) : "Free"}</dd></div>
            {order.codFee > 0 && <div className="flex justify-between"><dt>COD handling</dt><dd>{inr(order.codFee)}</dd></div>}
            <div className="flex justify-between border-t border-ink/10 pt-2 text-[17px] font-semibold"><dt>Total</dt><dd>{inr(order.total)}</dd></div>
          </dl>
          <div>
            <p className="label">Payment</p>
            <p>{order.paymentMethod === "cod" ? "Cash on Delivery" : "Paid online via Razorpay"} · {PAYMENT_LABEL[order.paymentStatus]}</p>
          </div>
          <div>
            <p className="label">Delivering to</p>
            <p className="leading-relaxed">
              {order.address.name}<br />
              {order.address.line1}{order.address.line2 ? `, ${order.address.line2}` : ""}<br />
              {order.address.city}, {order.address.state} {order.address.pincode}<br />
              +91 {order.address.phone}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
