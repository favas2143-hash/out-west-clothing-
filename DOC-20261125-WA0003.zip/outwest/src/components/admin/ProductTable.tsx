"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { categoryBySlug, discountPct, totalStock } from "@/lib/catalog";
import { inr } from "@/lib/pricing";
import type { Product } from "@/lib/types";
import { Icon } from "@/components/ui/Icon";
import { ProductArt } from "@/components/product/ProductArt";
import { useStore } from "@/components/providers/StoreProvider";
import { Pill, abtnDark, abtnLine, ainput, aselect } from "./ui";
import { downloadCSV } from "./csv";

export function ProductTable({ products, lowAt }: { products: Product[]; lowAt: number }) {
  const router = useRouter();
  const { toast, settings } = useStore();
  const CATEGORIES = settings.categories;
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("");
  const [view, setView] = useState<"" | "live" | "hidden" | "low" | "out">("");
  const [sel, setSel] = useState<Set<string>>(new Set());
  const [confirm, setConfirm] = useState<string[] | null>(null);
  const [busy, setBusy] = useState(false);

  const list = useMemo(
    () =>
      products.filter((p) => {
        const st = totalStock(p);
        const lowVariant = Object.values(p.stock).some((n) => n <= lowAt);
        return (
          (!cat || p.category === cat) &&
          p.name.toLowerCase().includes(q.toLowerCase()) &&
          (!view || (view === "live" && p.active) || (view === "hidden" && !p.active) || (view === "low" && lowVariant) || (view === "out" && st === 0))
        );
      }),
    [products, q, cat, view, lowAt],
  );
  const allOn = list.length > 0 && list.every((p) => sel.has(p.id));
  const toggle = (id: string) => setSel((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; });

  const bulk = async (ids: string[], action: "show" | "hide" | "delete") => {
    setBusy(true);
    const r = await fetch("/api/admin/products/bulk", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ ids, action }) });
    setBusy(false);
    setConfirm(null);
    if (!r.ok) return toast("Couldn't update products");
    toast(action === "delete" ? `${ids.length} deleted` : action === "show" ? `${ids.length} published` : `${ids.length} hidden from store`);
    setSel(new Set());
    router.refresh();
  };

  const duplicate = async (p: Product) => {
    const r = await fetch(`/api/admin/products/${p.id}/duplicate`, { method: "POST" });
    const j = await r.json();
    if (!r.ok) return toast("Couldn't duplicate");
    toast("Duplicated as hidden draft");
    router.push(`/admin/products/${j.product.id}`);
  };

  const exportCSV = () => {
    const rows: (string | number)[][] = [["ID", "Name", "Category", "Price", "MRP", "Discount %", "Status", "Tags", "Colour", "Size", "Stock"]];
    (sel.size ? list.filter((p) => sel.has(p.id)) : list).forEach((p) =>
      p.colours.forEach((c) => p.sizes.forEach((s) => rows.push([p.id, p.name, categoryBySlug(p.category, CATEGORIES)?.name ?? p.category, p.price, p.mrp, discountPct(p), p.active ? "Live" : "Hidden", p.tags.join(" "), c.name, s, p.stock[`${c.name}__${s}`] ?? 0]))),
    );
    downloadCSV(`outwest-products-${new Date().toISOString().slice(0, 10)}.csv`, rows);
  };

  const views: [typeof view, string][] = [["", "All"], ["live", "Live"], ["hidden", "Hidden"], ["low", "Low stock"], ["out", "Sold out"]];

  return (
    <div className="overflow-hidden rounded-xl border border-ink/[0.07] bg-white">
      <div className="no-scrollbar flex gap-1 overflow-x-auto border-b border-ink/[0.06] px-3 pt-3">
        {views.map(([k, l]) => (
          <button key={l} onClick={() => setView(k)} className={`-mb-px shrink-0 border-b-2 px-3 pb-3 text-[14px] font-medium ${view === k ? "border-ink" : "border-transparent text-ash hover:text-ink"}`}>{l}</button>
        ))}
      </div>
      <div className="flex flex-wrap gap-2 p-3">
        <div className="relative min-w-[200px] flex-1">
          <Icon name="search" size={16} className="absolute left-3 top-3 text-ash" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search products" aria-label="Search products" className={`${ainput} pl-9`} />
        </div>
        <select value={cat} onChange={(e) => setCat(e.target.value)} aria-label="Category" className={`${aselect}`}>
          <option value="">All categories</option>
          {CATEGORIES.map((c) => <option key={c.slug} value={c.slug}>{c.name}{c.active ? "" : " (hidden)"}</option>)}
        </select>
        <button onClick={exportCSV} className={abtnLine}><Icon name="share" size={16} /> Export CSV</button>
      </div>

      {sel.size > 0 && (
        <div className="flex flex-wrap items-center gap-2 border-y border-ink/[0.06] bg-beige/50 px-4 py-2.5 text-[14px]">
          <b>{sel.size} selected</b>
          <button disabled={busy} onClick={() => bulk([...sel], "show")} className={`${abtnLine} h-9`}>Publish</button>
          <button disabled={busy} onClick={() => bulk([...sel], "hide")} className={`${abtnLine} h-9`}>Hide</button>
          <button disabled={busy} onClick={() => setConfirm([...sel])} className={`${abtnLine} h-9 text-rose-600`}>Delete</button>
          <button onClick={() => setSel(new Set())} className="ml-auto text-[13px] text-ash hover:text-ink">Clear</button>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full min-w-[780px] text-[14px]">
          <thead>
            <tr className="border-b border-ink/[0.06] text-left text-[12px] text-ash">
              <th className="w-10 py-3 pl-4"><input type="checkbox" aria-label="Select all" checked={allOn} onChange={() => setSel(allOn ? new Set() : new Set(list.map((p) => p.id)))} className="h-4 w-4 accent-ink" /></th>
              <th className="font-medium">Product</th><th className="font-medium">Category</th><th className="text-right font-medium">Price</th><th className="text-right font-medium">Stock</th><th className="pl-6 font-medium">Status</th><th />
            </tr>
          </thead>
          <tbody>
            {list.map((p) => {
              const stock = totalStock(p);
              const low = Object.values(p.stock).filter((n) => n <= lowAt).length;
              return (
                <tr key={p.id} className={`border-b border-ink/[0.05] ${sel.has(p.id) ? "bg-beige/40" : "hover:bg-ink/[0.02]"}`}>
                  <td className="py-3 pl-4"><input type="checkbox" aria-label={`Select ${p.name}`} checked={sel.has(p.id)} onChange={() => toggle(p.id)} className="h-4 w-4 accent-ink" /></td>
                  <td className="py-3">
                    <Link href={`/admin/products/${p.id}`} className="flex items-center gap-3">
                      <div className="aspect-[4/5] w-11 shrink-0 overflow-hidden rounded bg-beige"><ProductArt kind={p.kind} hex={p.colours[0]?.hex ?? "#111"} src={p.images[0]} alt="" /></div>
                      <div>
                        <p className="font-medium hover:underline">{p.name}</p>
                        <p className="text-[12px] text-ash">{p.colours.length} colours · {p.sizes.length} sizes{p.tags.length ? ` · ${p.tags.map((t) => (t === "new" ? "New" : "Best seller")).join(", ")}` : ""}</p>
                      </div>
                    </Link>
                  </td>
                  <td className="text-ash">{categoryBySlug(p.category, CATEGORIES)?.name ?? p.category}{categoryBySlug(p.category, CATEGORIES)?.active === false && <span className="block text-[12px] text-amber-700">Category hidden</span>}</td>
                  <td className="text-right tabular-nums">{inr(p.price)}{discountPct(p) > 0 && <span className="block text-[12px] text-ash">−{discountPct(p)}%</span>}</td>
                  <td className="text-right tabular-nums">
                    <span className={stock === 0 ? "font-semibold text-rose-600" : ""}>{stock}</span>
                    {low > 0 && stock > 0 && <span className="block text-[12px] text-amber-700">{low} low</span>}
                  </td>
                  <td className="pl-6">{p.active ? <Pill tone="bg-emerald-50 text-emerald-800 ring-emerald-200">Live</Pill> : <Pill>Hidden</Pill>}</td>
                  <td className="pr-3 text-right">
                    <div className="flex justify-end">
                      <Link aria-label="Edit" title="Edit" href={`/admin/products/${p.id}`} className="grid h-9 w-9 place-items-center rounded-lg hover:bg-ink/5"><Icon name="edit" size={17} /></Link>
                      <button aria-label="Duplicate" title="Duplicate" onClick={() => duplicate(p)} className="grid h-9 w-9 place-items-center rounded-lg hover:bg-ink/5"><Icon name="plus" size={17} /></button>
                      <Link aria-label="View in store" title="View in store" href={`/product/${p.slug}`} target="_blank" className="grid h-9 w-9 place-items-center rounded-lg hover:bg-ink/5"><Icon name="external" size={17} /></Link>
                      <button aria-label="Delete" title="Delete" onClick={() => setConfirm([p.id])} className="grid h-9 w-9 place-items-center rounded-lg text-rose-600 hover:bg-rose-50"><Icon name="trash" size={17} /></button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {list.length === 0 && <p className="p-12 text-center text-ash">No products match.</p>}
      </div>

      {confirm && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/40 p-4" role="dialog" aria-modal="true">
          <div className="w-full max-w-sm rounded-xl bg-white p-6">
            <p className="text-[17px] font-semibold">Delete {confirm.length === 1 ? `“${products.find((p) => p.id === confirm[0])?.name}”` : `${confirm.length} products`}?</p>
            <p className="mt-2 text-[14px] text-ash">This removes them from the store permanently. Past orders keep their details. To take a product down temporarily, hide it instead.</p>
            <div className="mt-6 grid grid-cols-2 gap-2">
              <button className={abtnLine} onClick={() => setConfirm(null)}>Cancel</button>
              <button disabled={busy} className={`${abtnDark} bg-rose-600 hover:bg-rose-700`} onClick={() => bulk(confirm, "delete")}>Delete</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
