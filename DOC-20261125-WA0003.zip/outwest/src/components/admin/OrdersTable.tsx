"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { STATUS_FLOW, STATUS_LABEL } from "@/lib/orderStatus";
import { inr } from "@/lib/pricing";
import type { Order, OrderStatus } from "@/lib/types";
import { useStore } from "@/components/providers/StoreProvider";
import { Icon } from "@/components/ui/Icon";
import { PaymentBadge, StatusBadge, abtnDark, abtnLine, ainput, aselect } from "./ui";
import { downloadCSV } from "./csv";

type O = Omit<Order, "accessKey">;
const when = (iso: string) => new Date(iso).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" });

export function OrdersTable({ orders, initialStatus = "", initialQuery = "" }: { orders: O[]; initialStatus?: OrderStatus | ""; initialQuery?: string }) {
  const router = useRouter();
  const { toast } = useStore();
  const [status, setStatus] = useState<OrderStatus | "">(initialStatus);
  const [pay, setPay] = useState<"" | "cod" | "razorpay">("");
  const [q, setQ] = useState(initialQuery);
  const [sel, setSel] = useState<Set<string>>(new Set());
  const [bulk, setBulk] = useState<OrderStatus>("confirmed");
  const [busy, setBusy] = useState(false);

  const list = useMemo(() => {
    const t = q.trim().toLowerCase();
    return orders.filter(
      (o) =>
        (!status || o.status === status) &&
        (!pay || o.paymentMethod === pay) &&
        (!t || `${o.number} ${o.address.name} ${o.email} ${o.address.phone} ${o.address.city}`.toLowerCase().includes(t)),
    );
  }, [orders, status, pay, q]);

  const counts = useMemo(() => {
    const c: Partial<Record<OrderStatus, number>> = {};
    orders.forEach((o) => (c[o.status] = (c[o.status] ?? 0) + 1));
    return c;
  }, [orders]);

  const allOn = list.length > 0 && list.every((o) => sel.has(o.id));
  const toggle = (id: string) => setSel((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; });

  const applyBulk = async () => {
    setBusy(true);
    const r = await fetch("/api/admin/orders/bulk", { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ ids: [...sel], status: bulk }) });
    const j = await r.json();
    setBusy(false);
    if (!r.ok) return toast(j.error || "Couldn't update orders");
    toast(`${j.updated} order${j.updated === 1 ? "" : "s"} marked ${STATUS_LABEL[bulk].toLowerCase()}`, j.skipped ? `${j.skipped} skipped — status can't move backwards` : undefined);
    setSel(new Set());
    router.refresh();
  };

  const exportCSV = () => {
    const rows: (string | number | undefined)[][] = [["Order", "Date", "Status", "Payment method", "Payment status", "Customer", "Email", "Phone", "Address", "City", "State", "PIN", "Items", "Subtotal", "Discount", "Coupon", "Shipping", "COD fee", "Total", "Courier", "AWB"]];
    (sel.size ? list.filter((o) => sel.has(o.id)) : list).forEach((o) =>
      rows.push([o.number, new Date(o.createdAt).toLocaleString("en-IN"), STATUS_LABEL[o.status], o.paymentMethod === "cod" ? "COD" : "Razorpay", o.paymentStatus, o.address.name, o.email, o.address.phone, [o.address.line1, o.address.line2].filter(Boolean).join(", "), o.address.city, o.address.state, o.address.pincode, o.items.map((i) => `${i.name} (${i.colour}/${i.size}) x${i.qty}`).join("; "), o.subtotal, o.discount, o.coupon, o.shipping, o.codFee, o.total, o.courier, o.awb]),
    );
    downloadCSV(`outwest-orders-${new Date().toISOString().slice(0, 10)}.csv`, rows);
  };

  const tabs: (OrderStatus | "")[] = ["", "placed", "confirmed", "packed", "shipped", "out_for_delivery", "delivered", "pending_payment", "cancelled"];

  return (
    <div className="overflow-hidden rounded-xl border border-ink/[0.07] bg-white">
      <div className="no-scrollbar flex gap-1 overflow-x-auto border-b border-ink/[0.06] px-3 pt-3">
        {tabs.map((s) => (
          <button key={s || "all"} onClick={() => { setStatus(s); setSel(new Set()); }} className={`-mb-px shrink-0 border-b-2 px-3 pb-3 text-[14px] font-medium ${status === s ? "border-ink text-ink" : "border-transparent text-ash hover:text-ink"}`}>
            {s ? STATUS_LABEL[s] : "All"} <span className="ml-1 text-[12px] text-ash">{s ? counts[s] ?? 0 : orders.length}</span>
          </button>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-2 p-3">
        <div className="relative min-w-[220px] flex-1">
          <Icon name="search" size={16} className="absolute left-3 top-3 text-ash" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search order #, name, email, phone, city" aria-label="Search orders" className={`${ainput} pl-9`} />
        </div>
        <select value={pay} onChange={(e) => setPay(e.target.value as typeof pay)} aria-label="Payment method" className={`${aselect}`}>
          <option value="">All payments</option>
          <option value="razorpay">Online</option>
          <option value="cod">COD</option>
        </select>
        <button onClick={exportCSV} className={abtnLine}><Icon name="share" size={16} /> Export{sel.size ? ` ${sel.size}` : ""} CSV</button>
      </div>

      {sel.size > 0 && (
        <div className="flex flex-wrap items-center gap-2 border-y border-ink/[0.06] bg-beige/50 px-4 py-2.5 text-[14px]">
          <b>{sel.size} selected</b>
          <span className="text-ash">· Mark as</span>
          <select value={bulk} onChange={(e) => setBulk(e.target.value as OrderStatus)} aria-label="New status" className={`${aselect} h-9`}>
            {[...STATUS_FLOW.slice(1), "cancelled" as OrderStatus].map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
          </select>
          <button disabled={busy} onClick={applyBulk} className={`${abtnDark} h-9`}>{busy ? "Updating…" : "Apply"}</button>
          <button onClick={() => setSel(new Set())} className="ml-auto text-[13px] text-ash hover:text-ink">Clear</button>
        </div>
      )}

      {/* desktop table */}
      <div className="hidden overflow-x-auto md:block">
        <table className="w-full min-w-[860px] text-[14px]">
          <thead>
            <tr className="border-b border-ink/[0.06] text-left text-[12px] text-ash">
              <th className="w-10 py-3 pl-4"><input type="checkbox" aria-label="Select all" checked={allOn} onChange={() => setSel(allOn ? new Set() : new Set(list.map((o) => o.id)))} className="h-4 w-4 accent-ink" /></th>
              <th className="font-medium">Order</th><th className="font-medium">Date</th><th className="font-medium">Customer</th><th className="font-medium">Payment</th><th className="font-medium">Status</th><th className="pr-5 text-right font-medium">Total</th>
            </tr>
          </thead>
          <tbody>
            {list.map((o) => (
              <tr key={o.id} className={`border-b border-ink/[0.05] ${sel.has(o.id) ? "bg-beige/40" : "hover:bg-ink/[0.02]"}`}>
                <td className="py-3 pl-4"><input type="checkbox" aria-label={`Select ${o.number}`} checked={sel.has(o.id)} onChange={() => toggle(o.id)} className="h-4 w-4 accent-ink" /></td>
                <td><Link href={`/admin/orders/${o.id}`} className="font-semibold hover:underline">#{o.number}</Link><span className="block text-[12px] text-ash">{o.items.reduce((a, b) => a + b.qty, 0)} items</span></td>
                <td className="whitespace-nowrap text-ash">{when(o.createdAt)}</td>
                <td>{o.address.name}<span className="block text-[12px] text-ash">{o.address.city}, {o.address.state}</span></td>
                <td><span className="mb-1 block text-[12px] text-ash">{o.paymentMethod === "cod" ? "COD" : "Online"}</span><PaymentBadge status={o.paymentStatus} /></td>
                <td><StatusBadge status={o.status} /></td>
                <td className="pr-5 text-right font-semibold tabular-nums">{inr(o.total)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* mobile cards */}
      <ul className="divide-y divide-ink/[0.06] md:hidden">
        {list.map((o) => (
          <li key={o.id} className="flex gap-3 px-4 py-3.5">
            <input type="checkbox" aria-label={`Select ${o.number}`} checked={sel.has(o.id)} onChange={() => toggle(o.id)} className="mt-1 h-4 w-4 accent-ink" />
            <Link href={`/admin/orders/${o.id}`} className="min-w-0 flex-1">
              <div className="flex justify-between gap-2"><b>#{o.number}</b><b className="tabular-nums">{inr(o.total)}</b></div>
              <p className="truncate text-[13px] text-ash">{o.address.name} · {o.address.city} · {when(o.createdAt)}</p>
              <div className="mt-2 flex flex-wrap gap-1.5"><StatusBadge status={o.status} /><PaymentBadge status={o.paymentStatus} /></div>
            </Link>
          </li>
        ))}
      </ul>

      {list.length === 0 && <p className="p-12 text-center text-[14px] text-ash">{orders.length ? "No orders match these filters." : "No orders yet — place a test order from the store."}</p>}
    </div>
  );
}
