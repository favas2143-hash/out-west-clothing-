"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Icon, type IconName } from "@/components/ui/Icon";
import { SignOutButton } from "@/components/account/SignOutButton";

type Item = { href: string; label: string; icon: IconName; badge?: number };

export function AdminShell({ children, name, toFulfil = 0, lowStock = 0 }: { children: React.ReactNode; name: string; toFulfil?: number; lowStock?: number }) {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [path]);

  const groups: { title: string; items: Item[] }[] = [
    { title: "", items: [{ href: "/admin", label: "Dashboard", icon: "chart" }] },
    {
      title: "Sales",
      items: [
        { href: "/admin/orders", label: "Orders", icon: "truck", badge: toFulfil },
        { href: "/admin/customers", label: "Customers", icon: "user" },
        { href: "/admin/coupons", label: "Coupons", icon: "tag" },
      ],
    },
    {
      title: "Catalogue",
      items: [
        { href: "/admin/products", label: "Products", icon: "grid" },
        { href: "/admin/categories", label: "Categories", icon: "tag" },
        { href: "/admin/inventory", label: "Inventory", icon: "box", badge: lowStock },
      ],
    },
    { title: "Store", items: [{ href: "/admin/settings", label: "Settings", icon: "edit" }] },
  ];
  const active = (h: string) => (h === "/admin" ? path === h : path.startsWith(h));

  const nav = (
    <nav className="space-y-6 px-3">
      {groups.map((g) => (
        <div key={g.title || "main"}>
          {g.title && <p className="mb-2 px-3 text-[11px] font-semibold uppercase tracking-[0.16em] text-white/35">{g.title}</p>}
          <ul className="space-y-0.5">
            {g.items.map((n) => (
              <li key={n.href}>
                <Link
                  href={n.href}
                  className={`flex h-10 items-center gap-3 rounded-lg px-3 text-[14px] font-medium transition ${
                    active(n.href) ? "bg-white text-ink" : "text-white/70 hover:bg-white/[0.08] hover:text-white"
                  }`}
                >
                  <Icon name={n.icon} size={18} />
                  <span className="flex-1">{n.label}</span>
                  {!!n.badge && <span className={`grid h-5 min-w-5 place-items-center rounded-full px-1.5 text-[11px] font-bold ${active(n.href) ? "bg-ink text-white" : "bg-white/15 text-white"}`}>{n.badge}</span>}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </nav>
  );

  const footer = (
    <div className="space-y-1 border-t border-white/10 p-3">
      <Link href="/" target="_blank" className="flex h-10 items-center gap-3 rounded-lg px-3 text-[14px] text-white/70 hover:bg-white/[0.08] hover:text-white"><Icon name="external" size={17} /> View store</Link>
      <SignOutButton className="flex h-10 w-full items-center gap-3 rounded-lg px-3 text-[14px] text-white/70 hover:bg-white/[0.08] hover:text-white" />
      <div className="flex items-center gap-3 px-3 pt-3">
        <span className="grid h-8 w-8 place-items-center rounded-full bg-white/15 text-[13px] font-semibold text-white">{name.slice(0, 1).toUpperCase()}</span>
        <div className="min-w-0">
          <p className="truncate text-[13px] font-medium text-white">{name}</p>
          <p className="text-[11px] text-white/45">Administrator</p>
        </div>
      </div>
    </div>
  );

  const brand = (
    <Link href="/admin" className="flex items-baseline gap-2">
      <span className="display text-[21px] text-white">OUT WEST</span>
      <span className="rounded bg-white/15 px-1.5 py-0.5 text-[10px] font-semibold tracking-[0.14em] text-white/70">ADMIN</span>
    </Link>
  );

  return (
    <div className="min-h-screen bg-[#f3f2ef] text-ink lg:grid lg:grid-cols-[248px_minmax(0,1fr)]">
      {/* desktop sidebar */}
      <aside className="sticky top-0 hidden h-screen flex-col bg-ink print:hidden lg:flex">
        <div className="flex h-[72px] items-center px-6">{brand}</div>
        <div className="flex-1 overflow-y-auto py-2">{nav}</div>
        {footer}
      </aside>

      {/* mobile top bar + drawer */}
      <header className="sticky top-0 z-40 flex h-14 items-center justify-between bg-ink px-4 print:hidden lg:hidden">
        {brand}
        <button aria-label="Open admin menu" onClick={() => setOpen(true)} className="relative grid h-10 w-10 place-items-center text-white">
          <Icon name="menu" size={22} />
          {toFulfil > 0 && <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-amber-400" />}
        </button>
      </header>
      <div className={`fixed inset-0 z-50 lg:hidden ${open ? "" : "pointer-events-none"}`}>
        <div onClick={() => setOpen(false)} className={`absolute inset-0 bg-black/50 transition-opacity ${open ? "opacity-100" : "opacity-0"}`} />
        <aside className={`absolute inset-y-0 left-0 flex w-[280px] flex-col bg-ink transition-transform duration-300 ${open ? "translate-x-0" : "-translate-x-full"}`}>
          <div className="flex h-14 items-center justify-between px-5">{brand}<button aria-label="Close menu" onClick={() => setOpen(false)} className="grid h-10 w-10 place-items-center text-white"><Icon name="close" /></button></div>
          <div className="flex-1 overflow-y-auto py-3">{nav}</div>
          {footer}
        </aside>
      </div>

      <main className="min-w-0 px-4 py-6 sm:px-6 lg:px-10 lg:py-8 print:p-0">{children}</main>
    </div>
  );
}

export function AdminTitle({ title, sub, action, back }: { title: string; sub?: string; action?: React.ReactNode; back?: { href: string; label: string } }) {
  return (
    <div className="mb-6 print:hidden">
      {back && <Link href={back.href} className="mb-3 inline-flex items-center gap-1.5 text-[13px] text-ash hover:text-ink"><Icon name="arrowLeft" size={14} /> {back.label}</Link>}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-[26px] font-semibold tracking-tight sm:text-[30px]">{title}</h1>
          {sub && <p className="mt-1 text-[14px] text-ash">{sub}</p>}
        </div>
        {action && <div className="flex flex-wrap gap-2">{action}</div>}
      </div>
    </div>
  );
}
