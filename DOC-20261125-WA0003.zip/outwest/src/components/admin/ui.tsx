import type { OrderStatus, PaymentStatus } from "@/lib/types";
import { PAYMENT_LABEL, STATUS_LABEL } from "@/lib/orderStatus";

export function Card({ title, action, children, className = "", pad = true }: { title?: string; action?: React.ReactNode; children: React.ReactNode; className?: string; pad?: boolean }) {
  return (
    <section className={`rounded-xl border border-ink/[0.07] bg-white shadow-[0_1px_2px_rgba(0,0,0,0.03)] ${className}`}>
      {(title || action) && (
        <div className="flex items-center justify-between gap-3 border-b border-ink/[0.06] px-5 py-4">
          {title && <h2 className="text-[15px] font-semibold">{title}</h2>}
          {action}
        </div>
      )}
      <div className={pad ? "p-5" : ""}>{children}</div>
    </section>
  );
}

const STATUS_TONE: Record<OrderStatus, string> = {
  pending_payment: "bg-amber-50 text-amber-800 ring-amber-200",
  placed: "bg-sky-50 text-sky-800 ring-sky-200",
  confirmed: "bg-indigo-50 text-indigo-800 ring-indigo-200",
  packed: "bg-violet-50 text-violet-800 ring-violet-200",
  shipped: "bg-blue-50 text-blue-800 ring-blue-200",
  out_for_delivery: "bg-cyan-50 text-cyan-800 ring-cyan-200",
  delivered: "bg-emerald-50 text-emerald-800 ring-emerald-200",
  cancelled: "bg-rose-50 text-rose-700 ring-rose-200",
};

const PAY_TONE: Record<PaymentStatus, string> = {
  pending: "bg-amber-50 text-amber-800 ring-amber-200",
  paid: "bg-emerald-50 text-emerald-800 ring-emerald-200",
  failed: "bg-rose-50 text-rose-700 ring-rose-200",
  cod_pending: "bg-stone-100 text-stone-700 ring-stone-200",
  refunded: "bg-zinc-100 text-zinc-700 ring-zinc-300",
};

const pill = "inline-flex items-center whitespace-nowrap rounded-full px-2.5 py-0.5 text-[12px] font-medium ring-1 ring-inset";

export const StatusBadge = ({ status }: { status: OrderStatus }) => <span className={`${pill} ${STATUS_TONE[status]}`}>{STATUS_LABEL[status]}</span>;
export const PaymentBadge = ({ status }: { status: PaymentStatus }) => <span className={`${pill} ${PAY_TONE[status]}`}>{PAYMENT_LABEL[status]}</span>;
export const Pill = ({ children, tone = "bg-stone-100 text-stone-700 ring-stone-200" }: { children: React.ReactNode; tone?: string }) => <span className={`${pill} ${tone}`}>{children}</span>;

export const abtn = "inline-flex h-10 cursor-pointer items-center justify-center gap-2 whitespace-nowrap rounded-lg px-4 text-[14px] font-medium transition disabled:cursor-not-allowed disabled:opacity-50";
export const abtnDark = `${abtn} bg-ink text-white hover:bg-charcoal`;
export const abtnLine = `${abtn} border border-ink/15 bg-white hover:border-ink/40`;
const field = "rounded-lg border border-ink/15 bg-white px-3 text-[15px] outline-none transition focus:border-ink focus:ring-2 focus:ring-ink/10";
export const ainput = `h-10 w-full ${field}`;
/** inline select / small input that sizes to its content */
export const aselect = `h-10 w-auto ${field}`;
