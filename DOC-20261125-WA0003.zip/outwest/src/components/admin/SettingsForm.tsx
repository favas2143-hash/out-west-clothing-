"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import type { PublicUser, StoreSettings } from "@/lib/types";
import { useStore } from "@/components/providers/StoreProvider";
import { Icon } from "@/components/ui/Icon";
import { Card, abtnDark, abtnLine, ainput } from "./ui";

const L = ({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) => (
  <label className="block text-[13px] font-medium">
    {label}
    <div className="mt-1">{children}</div>
    {hint && <span className="mt-1 block text-[12px] font-normal text-ash">{hint}</span>}
  </label>
);

export function SettingsForm({
  settings,
  admins,
  meEmail,
  integrations,
}: {
  settings: StoreSettings;
  admins: PublicUser[];
  meEmail: string;
  integrations: { name: string; ok: boolean; on: string; off: string }[];
}) {
  const router = useRouter();
  const { toast } = useStore();
  const [s, setS] = useState(settings);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [invite, setInvite] = useState("");
  const set = <K extends keyof StoreSettings>(k: K, v: StoreSettings[K]) => setS((x) => ({ ...x, [k]: v }));
  const dirty = JSON.stringify(s) !== JSON.stringify(settings);

  const save = async () => {
    setBusy(true);
    setError("");
    const r = await fetch("/api/admin/settings", { method: "PUT", headers: { "content-type": "application/json" }, body: JSON.stringify(s) });
    const j = await r.json();
    setBusy(false);
    if (!r.ok) return setError(j.error || "Couldn't save");
    setS(j.settings);
    toast("Settings saved", "Changes are live on the store");
    router.refresh();
  };

  const team = async (email: string, role: "admin" | "customer") => {
    const r = await fetch("/api/admin/team", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ email, role }) });
    const j = await r.json();
    if (!r.ok) return toast(j.error || "Couldn't update");
    toast(role === "admin" ? `${email} is now an admin` : `Removed admin access for ${email}`);
    setInvite("");
    router.refresh();
  };

  return (
    <div className="grid gap-6 pb-24 xl:grid-cols-[minmax(0,1fr)_380px]">
      <div className="space-y-6">
        <Card title="Shipping & Cash on Delivery">
          <div className="grid gap-4 sm:grid-cols-2">
            <L label="Shipping fee (₹)"><input type="number" min={0} value={s.shippingFee} onChange={(e) => set("shippingFee", +e.target.value)} className={ainput} /></L>
            <L label="Free shipping above (₹)" hint="Set to 0 for free shipping on everything"><input type="number" min={0} value={s.freeShippingThreshold} onChange={(e) => set("freeShippingThreshold", +e.target.value)} className={ainput} /></L>
          </div>
          <label className="mt-5 flex items-center gap-3 text-[14px]"><input type="checkbox" checked={s.codEnabled} onChange={(e) => set("codEnabled", e.target.checked)} className="h-5 w-5 accent-ink" /> Offer Cash on Delivery</label>
          {s.codEnabled && (
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <L label="COD handling fee (₹)"><input type="number" min={0} value={s.codFee} onChange={(e) => set("codFee", +e.target.value)} className={ainput} /></L>
              <L label="COD allowed up to (₹)" hint="Bigger orders must pay online"><input type="number" min={1} value={s.codMaxOrder} onChange={(e) => set("codMaxOrder", +e.target.value)} className={ainput} /></L>
            </div>
          )}
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <L label="Low stock alert at" hint="Variants at or below this count are flagged"><input type="number" min={0} value={s.lowStockThreshold} onChange={(e) => set("lowStockThreshold", +e.target.value)} className={ainput} /></L>
          </div>
        </Card>

        <Card title="Homepage">
          <div className="space-y-4">
            <L label="Campaign label"><input value={s.heroEyebrow} onChange={(e) => set("heroEyebrow", e.target.value)} className={ainput} /></L>
            <L label="Campaign headline"><input value={s.heroTitle} onChange={(e) => set("heroTitle", e.target.value)} className={ainput} /></L>
            <L label="Campaign text"><textarea rows={3} value={s.heroText} onChange={(e) => set("heroText", e.target.value)} className={`${ainput} h-auto py-2`} /></L>
            <L label="Announcement bar messages" hint="One per line — they scroll across the top of every page">
              <textarea rows={4} value={s.announcements.join("\n")} onChange={(e) => set("announcements", e.target.value.split("\n"))} className={`${ainput} h-auto py-2`} />
            </L>
          </div>
        </Card>

        <Card title="Business details & invoices">
          <div className="grid gap-4 sm:grid-cols-2">
            <L label="Business name"><input value={s.businessName} onChange={(e) => set("businessName", e.target.value)} className={ainput} /></L>
            <L label="GSTIN" hint="Printed on invoices"><input value={s.gstin} onChange={(e) => set("gstin", e.target.value.toUpperCase())} maxLength={15} placeholder="29ABCDE1234F1Z5" className={`${ainput} font-mono uppercase`} /></L>
            <div className="sm:col-span-2"><L label="Business address"><textarea rows={2} value={s.businessAddress} onChange={(e) => set("businessAddress", e.target.value)} className={`${ainput} h-auto py-2`} /></L></div>
            <L label="Support email"><input type="email" value={s.supportEmail} onChange={(e) => set("supportEmail", e.target.value)} className={ainput} /></L>
            <L label="Support phone / WhatsApp"><input value={s.supportPhone} onChange={(e) => set("supportPhone", e.target.value)} className={ainput} /></L>
          </div>
        </Card>
      </div>

      <div className="space-y-6">
        <Card title="Team">
          <ul className="space-y-2">
            {admins.map((a) => (
              <li key={a.id} className="flex items-center gap-3">
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-beige text-[13px] font-semibold">{a.name.slice(0, 1).toUpperCase()}</span>
                <div className="min-w-0 flex-1"><p className="truncate text-[14px] font-medium">{a.name}{a.email === meEmail && <span className="text-ash"> (you)</span>}</p><p className="truncate text-[12px] text-ash">{a.email}</p></div>
                {a.email !== meEmail && <button onClick={() => team(a.email, "customer")} className="text-[12px] text-rose-600 hover:underline">Remove</button>}
              </li>
            ))}
          </ul>
          <form className="mt-4 flex gap-2" onSubmit={(e) => { e.preventDefault(); if (invite.trim()) team(invite.trim(), "admin"); }}>
            <input type="email" value={invite} onChange={(e) => setInvite(e.target.value)} placeholder="teammate@email.com" aria-label="Teammate email" className={ainput} />
            <button className={abtnLine}>Add</button>
          </form>
          <p className="mt-2 text-[12px] text-ash">They need a store account first (Create account on the website). Admins can manage everything here.</p>
        </Card>

        <Card title="Connections">
          <ul className="space-y-3">
            {integrations.map((i) => (
              <li key={i.name} className="flex gap-3">
                <span className={`mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full ${i.ok ? "bg-emerald-600 text-white" : "bg-amber-100 text-amber-800"}`}>{i.ok ? <Icon name="check" size={12} strokeWidth={3} /> : <span className="text-[12px] font-bold">!</span>}</span>
                <div><p className="text-[14px] font-medium">{i.name}</p><p className="text-[12px] text-ash">{i.ok ? i.on : i.off}</p></div>
              </li>
            ))}
          </ul>
          <p className="mt-4 text-[12px] text-ash">Connections are set as environment variables in Vercel (Settings → Environment Variables), then redeploy.</p>
        </Card>
      </div>

      <div className={`fixed inset-x-0 bottom-0 z-40 border-t border-ink/10 bg-white/95 px-4 py-3 backdrop-blur transition lg:left-[248px] ${dirty ? "translate-y-0" : "translate-y-full"}`}>
        <div className="mx-auto flex max-w-5xl items-center justify-end gap-3">
          {error && <p className="mr-auto text-[14px] text-rose-600">{error}</p>}
          <span className="mr-auto hidden text-[14px] text-ash sm:block">You have unsaved changes</span>
          <button onClick={() => setS(settings)} className={abtnLine}>Discard</button>
          <button disabled={busy} onClick={save} className={abtnDark}>{busy ? "Saving…" : "Save settings"}</button>
        </div>
      </div>
    </div>
  );
}
