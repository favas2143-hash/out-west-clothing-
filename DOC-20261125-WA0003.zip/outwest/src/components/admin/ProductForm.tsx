"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { COLOURS, discountPct, sizesForKind, stockKey } from "@/lib/catalog";
import { inr } from "@/lib/pricing";
import type { CategorySlug, Colour, GarmentKind, Product } from "@/lib/types";
import { ProductArt } from "@/components/product/ProductArt";
import { Icon } from "@/components/ui/Icon";
import { useStore } from "@/components/providers/StoreProvider";
import { PhotoManager } from "./PhotoManager";

const KINDS: [GarmentKind, string][] = [
  ["tee", "T-shirt"], ["oversized", "Oversized tee"], ["hoodie", "Hoodie"], ["shirt", "Shirt"],
  ["pants", "Trousers"], ["cargo", "Cargo pants"], ["cap", "Cap"], ["beanie", "Beanie"], ["tote", "Tote bag"],
];
const SIZE_SETS: Record<string, string[]> = { apparel: ["XS", "S", "M", "L", "XL", "XXL"], waist: ["28", "30", "32", "34", "36", "38"], one: ["One Size"] };

type Draft = Omit<Product, "id" | "slug" | "createdAt" | "rating" | "reviews">;

const blank: Draft = {
  name: "", category: "oversized-t-shirts", kind: "oversized", description: "", details: [], fabric: "", fit: "",
  price: 1499, mrp: 1999, colours: [COLOURS.black], sizes: ["S", "M", "L", "XL"], stock: {}, images: [], tags: ["new"], active: true,
};

export function ProductForm({ product }: { product?: Product }) {
  const router = useRouter();
  const { toast, settings } = useStore();
  const CATEGORIES = settings.categories;
  const [d, setD] = useState<Draft>(product ?? blank);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [newSize, setNewSize] = useState("");
  const [fill, setFill] = useState(10);
  const set = <K extends keyof Draft>(k: K, v: Draft[K]) => setD((x) => ({ ...x, [k]: v }));

  const setCategory = (c: CategorySlug) => {
    const cat = CATEGORIES.find((x) => x.slug === c);
    const kind = cat?.kind ?? d.kind;
    setD((x) => ({ ...x, category: c, kind, sizes: sizesForKind(kind).some((s) => x.sizes.includes(s)) ? x.sizes : sizesForKind(kind) }));
  };

  const setColour = (i: number, patch: Partial<Colour>) => {
    const old = d.colours[i];
    const colours = d.colours.map((c, n) => (n === i ? { ...c, ...patch } : c));
    // carry stock over when a colour is renamed
    const stock = { ...d.stock };
    if (patch.name !== undefined && patch.name !== old.name)
      d.sizes.forEach((s) => {
        stock[stockKey(patch.name!, s)] = stock[stockKey(old.name, s)] ?? 0;
        delete stock[stockKey(old.name, s)];
      });
    setD((x) => ({ ...x, colours, stock }));
  };

  const toggleSize = (s: string) => set("sizes", d.sizes.includes(s) ? d.sizes.filter((x) => x !== s) : [...d.sizes, s]);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    const r = await fetch(product ? `/api/admin/products/${product.id}` : "/api/admin/products", {
      method: product ? "PUT" : "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(d),
    });
    const j = await r.json();
    setBusy(false);
    if (!r.ok) return setError(j.error || "Couldn't save");
    toast(product ? "Product updated" : "Product created");
    router.push("/admin/products");
    router.refresh();
  };

  const preview = d.colours[0] ?? COLOURS.black;
  const base = ["pants", "cargo"].includes(d.kind) ? SIZE_SETS.waist : ["cap", "tote", "beanie"].includes(d.kind) ? SIZE_SETS.one : SIZE_SETS.apparel;
  const allSizes = [...new Set([...base, ...d.sizes])];
  const catHidden = CATEGORIES.find((c) => c.slug === d.category)?.active === false;

  return (
    <form onSubmit={save} className="grid gap-6 xl:grid-cols-[1fr_340px]">
      <div className="space-y-6">
        <section className="space-y-4 rounded-xl border border-ink/[0.07] bg-white p-5 sm:p-6">
          <h2 className="text-[15px] font-semibold">Details</h2>
          <div>
            <label className="mb-1 block text-[13px] font-medium" htmlFor="pname">Product name</label>
            <input id="pname" required value={d.name} onChange={(e) => set("name", e.target.value)} className="h-10 w-full rounded-lg border border-ink/15 bg-white px-3 text-[15px] outline-none transition focus:border-ink focus:ring-2 focus:ring-ink/10" placeholder="e.g. Heavyweight Oversized Tee" />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-[13px] font-medium" htmlFor="pcat">Category</label>
              <select id="pcat" value={d.category} onChange={(e) => setCategory(e.target.value as CategorySlug)} className="h-10 w-full rounded-lg border border-ink/15 bg-white px-3 text-[15px] outline-none transition focus:border-ink focus:ring-2 focus:ring-ink/10">
                {CATEGORIES.map((c) => <option key={c.slug} value={c.slug}>{c.name}{c.active ? "" : " (hidden in store)"}</option>)}
              </select>
              {catHidden && <p className="mt-1 text-[12px] text-amber-700">This category is hidden, so shoppers won&apos;t see this product until you show the category in Categories.</p>}
            </div>
            <div>
              <label className="mb-1 block text-[13px] font-medium" htmlFor="pkind">Studio render style</label>
              <select id="pkind" value={d.kind} onChange={(e) => set("kind", e.target.value as GarmentKind)} className="h-10 w-full rounded-lg border border-ink/15 bg-white px-3 text-[15px] outline-none transition focus:border-ink focus:ring-2 focus:ring-ink/10">
                {KINDS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="mb-1 block text-[13px] font-medium" htmlFor="pdesc">Description</label>
            <textarea id="pdesc" rows={3} value={d.description} onChange={(e) => set("description", e.target.value)} className="w-full rounded-lg border border-ink/15 bg-white px-3 text-[15px] outline-none transition focus:border-ink focus:ring-2 focus:ring-ink/10 h-auto py-3" />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-[13px] font-medium" htmlFor="pfab">Fabric</label>
              <input id="pfab" value={d.fabric} onChange={(e) => set("fabric", e.target.value)} className="h-10 w-full rounded-lg border border-ink/15 bg-white px-3 text-[15px] outline-none transition focus:border-ink focus:ring-2 focus:ring-ink/10" placeholder="100% cotton, 240 GSM" />
            </div>
            <div>
              <label className="mb-1 block text-[13px] font-medium" htmlFor="pfit">Fit</label>
              <input id="pfit" value={d.fit} onChange={(e) => set("fit", e.target.value)} className="h-10 w-full rounded-lg border border-ink/15 bg-white px-3 text-[15px] outline-none transition focus:border-ink focus:ring-2 focus:ring-ink/10" placeholder="Oversized fit" />
            </div>
          </div>
          <div>
            <label className="mb-1 block text-[13px] font-medium" htmlFor="pdet">Product details (one per line)</label>
            <textarea id="pdet" rows={4} value={d.details.join("\n")} onChange={(e) => set("details", e.target.value.split("\n"))} className="w-full rounded-lg border border-ink/15 bg-white px-3 text-[15px] outline-none transition focus:border-ink focus:ring-2 focus:ring-ink/10 h-auto py-3" />
          </div>
        </section>

        <section className="space-y-4 rounded-xl border border-ink/[0.07] bg-white p-5 sm:p-6">
          <h2 className="text-[15px] font-semibold">Pricing</h2>
          <div className="grid gap-4 sm:grid-cols-3">
            <div>
              <label className="mb-1 block text-[13px] font-medium" htmlFor="pprice">Selling price (₹)</label>
              <input id="pprice" type="number" min={1} required value={d.price} onChange={(e) => set("price", +e.target.value)} className="h-10 w-full rounded-lg border border-ink/15 bg-white px-3 text-[15px] outline-none transition focus:border-ink focus:ring-2 focus:ring-ink/10" />
            </div>
            <div>
              <label className="mb-1 block text-[13px] font-medium" htmlFor="pmrp">MRP (₹)</label>
              <input id="pmrp" type="number" min={1} value={d.mrp} onChange={(e) => set("mrp", +e.target.value)} className="h-10 w-full rounded-lg border border-ink/15 bg-white px-3 text-[15px] outline-none transition focus:border-ink focus:ring-2 focus:ring-ink/10" />
            </div>
            <div className="flex items-end pb-3 text-[14px]">{discountPct(d) > 0 ? <span>Shows <b>{discountPct(d)}% off</b></span> : <span className="text-ash">No discount</span>}</div>
          </div>
        </section>

        <section className="space-y-4 rounded-xl border border-ink/[0.07] bg-white p-5 sm:p-6">
          <h2 className="text-[15px] font-semibold">Colours</h2>
          <div className="space-y-2">
            {d.colours.map((c, i) => (
              <div key={i} className="flex items-center gap-2">
                <input type="color" aria-label="Colour swatch" value={c.hex} onChange={(e) => setColour(i, { hex: e.target.value })} className="h-11 w-12 cursor-pointer border border-ink/15 bg-white p-1" />
                <input aria-label="Colour name" value={c.name} onChange={(e) => setColour(i, { name: e.target.value })} className="w-full rounded-lg border border-ink/15 bg-white px-3 text-[15px] outline-none transition focus:border-ink focus:ring-2 focus:ring-ink/10 h-11" />
                <button type="button" aria-label="Remove colour" disabled={d.colours.length === 1} onClick={() => set("colours", d.colours.filter((_, n) => n !== i))} className="grid h-11 w-11 shrink-0 place-items-center text-ash hover:text-sale disabled:opacity-30"><Icon name="trash" size={17} /></button>
              </div>
            ))}
          </div>
          <div className="flex flex-wrap gap-2">
            {Object.values(COLOURS).filter((c) => !d.colours.some((x) => x.name === c.name)).map((c) => (
              <button type="button" key={c.name} onClick={() => set("colours", [...d.colours, c])} className="flex h-9 items-center gap-2 border border-ink/15 px-3 text-[13px] hover:border-ink">
                <span className="h-4 w-4 rounded-full border border-ink/20" style={{ background: c.hex }} /> + {c.name}
              </button>
            ))}
            <button type="button" onClick={() => set("colours", [...d.colours, { name: `Colour ${d.colours.length + 1}`, hex: "#777777" }])} className="h-9 border border-dashed border-ink/30 px-3 text-[13px]">+ Custom</button>
          </div>
        </section>

        <section className="space-y-4 rounded-xl border border-ink/[0.07] bg-white p-5 sm:p-6">
          <h2 className="text-[15px] font-semibold">Sizes & stock</h2>
          <div className="flex flex-wrap gap-2">
            {allSizes.map((s) => (
              <button type="button" key={s} onClick={() => toggleSize(s)} aria-pressed={d.sizes.includes(s)} className={`h-10 min-w-12 border px-3 text-[13px] font-semibold ${d.sizes.includes(s) ? "border-ink bg-ink text-bone" : "border-ink/15"}`}>{s}</button>
            ))}
            <div className="flex">
              <input aria-label="Custom size" value={newSize} onChange={(e) => setNewSize(e.target.value)} placeholder="Other" className="rounded-lg border border-ink/15 bg-white px-3 text-[15px] outline-none transition focus:border-ink focus:ring-2 focus:ring-ink/10 h-10 w-24" />
              <button type="button" onClick={() => { if (newSize.trim() && !d.sizes.includes(newSize.trim())) set("sizes", [...d.sizes, newSize.trim()]); setNewSize(""); }} className="h-10 border border-l-0 border-ink/15 px-3 text-[13px]">Add</button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="text-[13px]">
              <thead>
                <tr><th className="pb-2 pr-3 text-left font-semibold text-ash">Colour \ Size</th>{d.sizes.map((s) => <th key={s} className="px-1 pb-2 font-semibold">{s}</th>)}</tr>
              </thead>
              <tbody>
                {d.colours.map((c) => (
                  <tr key={c.name}>
                    <td className="whitespace-nowrap py-1 pr-3"><span className="mr-2 inline-block h-3 w-3 rounded-full border border-ink/20 align-middle" style={{ background: c.hex }} />{c.name}</td>
                    {d.sizes.map((s) => (
                      <td key={s} className="px-1 py-1">
                        <input type="number" min={0} aria-label={`Stock ${c.name} ${s}`} value={d.stock[stockKey(c.name, s)] ?? 0} onChange={(e) => set("stock", { ...d.stock, [stockKey(c.name, s)]: Math.max(0, +e.target.value) })} className="h-10 w-16 border border-ink/15 px-2 text-right tabular-nums" />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex items-center gap-2 text-[13px]">
            <span>Set every variant to</span>
            <input type="number" min={0} value={fill} onChange={(e) => setFill(+e.target.value)} aria-label="Fill quantity" className="h-9 w-16 border border-ink/15 px-2 text-right" />
            <button type="button" onClick={() => { const st: Record<string, number> = {}; d.colours.forEach((c) => d.sizes.forEach((s) => (st[stockKey(c.name, s)] = fill))); set("stock", st); }} className="h-9 border border-ink/15 px-3 hover:border-ink">Apply</button>
          </div>
        </section>

        <section className="space-y-4 rounded-xl border border-ink/[0.07] bg-white p-5 sm:p-6">
          <h2 className="text-[15px] font-semibold">Photos</h2>
          <PhotoManager images={d.images.filter(Boolean)} onChange={(images) => set("images", images)} />
        </section>
      </div>

      <aside className="space-y-4 xl:sticky xl:top-6 xl:h-fit">
        <div className="rounded-xl border border-ink/[0.07] bg-white p-5">
          <p className="mb-1 block text-[13px] font-medium">Preview</p>
          <div className="aspect-[4/5] overflow-hidden rounded-lg bg-beige"><ProductArt kind={d.kind} hex={preview.hex} src={d.images.find(Boolean)} alt="Preview" /></div>
          <p className="mt-3 font-medium">{d.name || "Product name"}</p>
          <p className="text-[14px]"><b>{inr(d.price || 0)}</b> {discountPct(d) > 0 && <s className="text-ash">{inr(d.mrp)}</s>}</p>
        </div>
        <div className="space-y-3 rounded-xl border border-ink/[0.07] bg-white p-5 text-[14px]">
          <label className="flex items-center gap-3"><input type="checkbox" className="h-5 w-5 accent-ink" checked={d.active} onChange={(e) => set("active", e.target.checked)} /> Visible in store</label>
          <label className="flex items-center gap-3"><input type="checkbox" className="h-5 w-5 accent-ink" checked={d.tags.includes("new")} onChange={(e) => set("tags", e.target.checked ? [...d.tags, "new"] : d.tags.filter((t) => t !== "new"))} /> Show in New Arrivals</label>
          <label className="flex items-center gap-3"><input type="checkbox" className="h-5 w-5 accent-ink" checked={d.tags.includes("bestseller")} onChange={(e) => set("tags", e.target.checked ? [...d.tags, "bestseller"] : d.tags.filter((t) => t !== "bestseller"))} /> Show in Best Sellers</label>
        </div>
        {error && <p role="alert" className="bg-sale/10 p-3 text-[14px] text-sale">{error}</p>}
        <button disabled={busy} className="inline-flex h-11 w-full items-center justify-center rounded-lg bg-ink text-[14px] font-medium text-white hover:bg-charcoal disabled:opacity-50">{busy ? "Saving…" : product ? "Save changes" : "Create product"}</button>
        <button type="button" onClick={() => router.back()} className="inline-flex h-11 w-full items-center justify-center rounded-lg border border-ink/15 bg-white text-[14px] font-medium hover:border-ink/40">Cancel</button>
      </aside>
    </form>
  );
}
