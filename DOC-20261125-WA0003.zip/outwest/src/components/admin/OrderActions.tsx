"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { STATUS_FLOW, STATUS_LABEL } from "@/lib/orderStatus";
import type { Order, OrderNote, OrderStatus } from "@/lib/types";
import { useStore } from "@/components/providers/StoreProvider";
import { Card, abtnDark, abtnLine, ainput } from "./ui";

async function patch(id: string, body: unknown) {
  const r = await fetch(`/api/admin/orders/${id}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
  const j = await r.json();
  return { ok: r.ok, error: j.error as string | undefined };
}

export function OrderActions({ order }: { order: Omit<Order, "accessKey"> }) {
  const router = useRouter();
  const { toast } = useStore();
  const idx = STATUS_FLOW.indexOf(order.status);
  const options = STATUS_FLOW.slice(idx + 1);
  const [status, setStatus] = useState<OrderStatus>(options[0] ?? order.status);
  const [courier, setCourier] = useState(order.courier ?? "Delhivery");
  const [awb, setAwb] = useState(order.awb ?? "");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [confirmCancel, setConfirmCancel] = useState(false);
  const locked = order.status === "cancelled" || order.status === "delivered";

  const update = async (s: OrderStatus) => {
    setBusy(true);
    const r = await patch(order.id, { status: s, note, courier, awb });
    setBusy(false);
    if (!r.ok) return toast(r.error || "Couldn't update");
    toast(`Marked ${STATUS_LABEL[s].toLowerCase()}`);
    router.refresh();
  };

  return (
    <Card title="Fulfilment">
      {locked ? (
        <p className="text-[14px] text-ash">This order is {STATUS_LABEL[order.status].toLowerCase()}. No further changes.</p>
      ) : order.status === "pending_payment" ? (
        <div className="space-y-3">
          <p className="text-[14px] text-ash">Waiting for the customer to pay. Unpaid orders don&apos;t reserve stock.</p>
          <button disabled={busy} onClick={() => update("cancelled")} className={`${abtnLine} w-full text-rose-600`}>Cancel order</button>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex flex-wrap gap-1.5">
            {options.map((s) => (
              <button key={s} onClick={() => setStatus(s)} className={`rounded-full px-3 py-1.5 text-[13px] font-medium ${status === s ? "bg-ink text-white" : "bg-ink/[0.05] text-ink hover:bg-ink/10"}`}>{STATUS_LABEL[s]}</button>
            ))}
          </div>
          {(status === "shipped" || status === "out_for_delivery" || order.awb) && (
            <div className="grid grid-cols-2 gap-2">
              <label className="text-[12px] text-ash">Courier<select value={courier} onChange={(e) => setCourier(e.target.value)} className={`${ainput} mt-1 text-ink`}>{["Delhivery", "Blue Dart", "DTDC", "Ekart", "Xpressbees", "Shadowfax", "India Post", "Shiprocket"].map((c) => <option key={c}>{c}</option>)}</select></label>
              <label className="text-[12px] text-ash">AWB / tracking no.<input value={awb} onChange={(e) => setAwb(e.target.value)} className={`${ainput} mt-1 text-ink`} /></label>
            </div>
          )}
          <input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Note for the timeline (optional)" aria-label="Status note" className={ainput} />
          <button disabled={busy || !options.length} onClick={() => update(status)} className={`${abtnDark} w-full`}>{busy ? "Saving…" : `Mark as ${STATUS_LABEL[status].toLowerCase()}`}</button>
          {confirmCancel ? (
            <div className="rounded-lg bg-rose-50 p-3 text-[13px]">
              <p>Cancel this order and put the items back in stock?{order.paymentStatus === "paid" ? " Refund the payment from Razorpay, then use Mark refunded." : ""}</p>
              <div className="mt-2 flex gap-2"><button disabled={busy} onClick={() => update("cancelled")} className={`${abtn} h-9 bg-rose-600 text-white`}>Yes, cancel</button><button onClick={() => setConfirmCancel(false)} className={`${abtnLine} h-9`}>Keep order</button></div>
            </div>
          ) : (
            <button onClick={() => setConfirmCancel(true)} className="w-full text-[13px] text-rose-600 hover:underline">Cancel order & restock</button>
          )}
        </div>
      )}
    </Card>
  );
}

const abtn = "inline-flex items-center justify-center rounded-lg px-3 text-[13px] font-medium";

export function OrderNotes({ id, notes }: { id: string; notes: OrderNote[] }) {
  const router = useRouter();
  const { toast } = useStore();
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  return (
    <div>
      {notes.length === 0 ? <p className="mb-3 text-[14px] text-ash">Only your team sees these notes.</p> : (
        <ul className="mb-4 space-y-3">
          {notes.map((n, i) => (
            <li key={i} className="rounded-lg bg-ink/[0.03] p-3 text-[14px]">
              <p>{n.text}</p>
              <p className="mt-1 text-[12px] text-ash">{n.by} · {new Date(n.at).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" })}</p>
            </li>
          ))}
        </ul>
      )}
      <form
        className="flex gap-2"
        onSubmit={async (e) => {
          e.preventDefault();
          if (!text.trim()) return;
          setBusy(true);
          const r = await patch(id, { note: text });
          setBusy(false);
          if (!r.ok) return toast(r.error || "Couldn't save note");
          setText("");
          router.refresh();
        }}
      >
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="e.g. Customer asked to deliver after 6 pm" aria-label="New note" className={ainput} />
        <button disabled={busy} className={abtnDark}>Add</button>
      </form>
    </div>
  );
}

export function RefundButton({ id }: { id: string }) {
  const router = useRouter();
  const { toast } = useStore();
  const [confirm, setConfirm] = useState(false);
  if (!confirm) return <button onClick={() => setConfirm(true)} className={abtnLine}>Mark refunded</button>;
  return (
    <span className="flex items-center gap-2 rounded-lg bg-white px-2 py-1 ring-1 ring-ink/10">
      <span className="text-[13px]">Refunded in Razorpay?</span>
      <button
        className={`${abtn} h-8 bg-ink text-white`}
        onClick={async () => {
          const r = await patch(id, { refund: true });
          if (!r.ok) return toast(r.error || "Couldn't update");
          toast("Marked as refunded");
          router.refresh();
        }}
      >
        Yes
      </button>
      <button className={`${abtn} h-8`} onClick={() => setConfirm(false)}>No</button>
    </span>
  );
}
