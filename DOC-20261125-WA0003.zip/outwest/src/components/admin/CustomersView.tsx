"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { inr } from "@/lib/pricing";
import { Icon } from "@/components/ui/Icon";
import { Pill, abtnLine, ainput, aselect } from "./ui";
import { downloadCSV } from "./csv";

export interface CustomerRow {
  email: string;
  name: string;
  phone?: string;
  city: string;
  account: boolean;
  orders: number;
  spent: number;
  joined: string;
  lastOrder?: string;
  subscribed: boolean;
}

const d = (iso?: string) => (iso ? new Date(iso).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) : "—");

export function CustomersView({ customers, subscribers }: { customers: CustomerRow[]; subscribers: { email: string; at: string }[] }) {
  const [tab, setTab] = useState<"customers" | "subscribers">("customers");
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<"recent" | "spent" | "orders">("recent");

  const list = useMemo(() => {
    const t = q.trim().toLowerCase();
    const f = customers.filter((c) => !t || `${c.name} ${c.email} ${c.phone ?? ""} ${c.city}`.toLowerCase().includes(t));
    if (sort === "spent") return [...f].sort((a, b) => b.spent - a.spent);
    if (sort === "orders") return [...f].sort((a, b) => b.orders - a.orders);
    return f;
  }, [customers, q, sort]);
  const subs = subscribers.filter((s) => s.email.includes(q.trim().toLowerCase()));

  const exportCSV = () =>
    tab === "customers"
      ? downloadCSV("outwest-customers.csv", [["Name", "Email", "Phone", "City", "Account", "Orders", "Total spent", "Last order", "Newsletter"], ...list.map((c) => [c.name, c.email, c.phone, c.city, c.account ? "Yes" : "Guest", c.orders, c.spent, d(c.lastOrder), c.subscribed ? "Yes" : "No"])])
      : downloadCSV("outwest-subscribers.csv", [["Email", "Subscribed on"], ...subs.map((s) => [s.email, d(s.at)])]);

  return (
    <div className="overflow-hidden rounded-xl border border-ink/[0.07] bg-white">
      <div className="flex gap-1 border-b border-ink/[0.06] px-3 pt-3">
        {(["customers", "subscribers"] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`-mb-px border-b-2 px-3 pb-3 text-[14px] font-medium capitalize ${tab === t ? "border-ink" : "border-transparent text-ash hover:text-ink"}`}>
            {t} <span className="ml-1 text-[12px] text-ash">{t === "customers" ? customers.length : subscribers.length}</span>
          </button>
        ))}
      </div>
      <div className="flex flex-wrap gap-2 p-3">
        <div className="relative min-w-[200px] flex-1">
          <Icon name="search" size={16} className="absolute left-3 top-3 text-ash" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={tab === "customers" ? "Search name, email, phone, city" : "Search email"} aria-label="Search" className={`${ainput} pl-9`} />
        </div>
        {tab === "customers" && (
          <select value={sort} onChange={(e) => setSort(e.target.value as typeof sort)} aria-label="Sort" className={`${aselect}`}>
            <option value="recent">Most recent</option>
            <option value="spent">Top spenders</option>
            <option value="orders">Most orders</option>
          </select>
        )}
        <button onClick={exportCSV} className={abtnLine}><Icon name="share" size={16} /> Export CSV</button>
      </div>

      {tab === "customers" ? (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-[14px]">
            <thead><tr className="border-y border-ink/[0.06] text-left text-[12px] text-ash"><th className="px-5 py-3 font-medium">Customer</th><th className="font-medium">Location</th><th className="text-right font-medium">Orders</th><th className="text-right font-medium">Spent</th><th className="pl-6 font-medium">Last order</th><th className="pr-5" /></tr></thead>
            <tbody>
              {list.map((c) => (
                <tr key={c.email} className="border-b border-ink/[0.05] hover:bg-ink/[0.02]">
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-3">
                      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-beige text-[13px] font-semibold">{c.name.slice(0, 1).toUpperCase()}</span>
                      <div className="min-w-0">
                        <p className="font-medium">{c.name} {!c.account && <Pill>Guest</Pill>} {c.subscribed && <Pill tone="bg-sky-50 text-sky-800 ring-sky-200">Newsletter</Pill>}</p>
                        <p className="truncate text-[12px] text-ash">{c.email}{c.phone ? ` · +91 ${c.phone}` : ""}</p>
                      </div>
                    </div>
                  </td>
                  <td className="text-ash">{c.city || "—"}</td>
                  <td className="text-right tabular-nums">{c.orders}</td>
                  <td className="text-right font-semibold tabular-nums">{inr(c.spent)}</td>
                  <td className="pl-6 text-ash">{d(c.lastOrder)}</td>
                  <td className="pr-5 text-right">{c.orders > 0 && <Link href={`/admin/orders?q=${encodeURIComponent(c.email)}`} className="text-[13px] underline underline-offset-4">Orders</Link>}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {list.length === 0 && <p className="p-12 text-center text-ash">{customers.length ? "No customers match." : "Customers appear here after their first order or sign-up."}</p>}
        </div>
      ) : (
        <ul className="divide-y divide-ink/[0.06] border-t border-ink/[0.06]">
          {subs.map((s) => (
            <li key={s.email} className="flex justify-between px-5 py-3 text-[14px]"><span>{s.email}</span><span className="text-ash">{d(s.at)}</span></li>
          ))}
          {subs.length === 0 && <li className="p-12 text-center text-ash">No subscribers yet. The homepage newsletter form adds them here.</li>}
        </ul>
      )}
    </div>
  );
}
