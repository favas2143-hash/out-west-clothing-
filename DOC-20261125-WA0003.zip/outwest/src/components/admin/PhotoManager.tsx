"use client";

import { useRef, useState } from "react";
import { Icon } from "@/components/ui/Icon";
import { useStore } from "@/components/providers/StoreProvider";
import { abtnLine, ainput } from "./ui";

/** Upload, paste, reorder and remove product photos. First photo = main image, second = hover image. */
export function PhotoManager({ images, onChange }: { images: string[]; onChange: (v: string[]) => void }) {
  const { toast } = useStore();
  const input = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(0);
  const [url, setUrl] = useState("");
  const [drag, setDrag] = useState(false);

  const upload = async (files: FileList | File[]) => {
    const list = [...files].filter((f) => f.type.startsWith("image/"));
    if (!list.length) return;
    setBusy(list.length);
    const added: string[] = [];
    for (const f of list) {
      const fd = new FormData();
      fd.append("file", f);
      const r = await fetch("/api/admin/upload", { method: "POST", body: fd });
      const j = await r.json().catch(() => ({}));
      if (r.ok && j.url) added.push(j.url);
      else toast("Upload failed", j.error || f.name);
      setBusy((b) => b - 1);
    }
    if (added.length) onChange([...images, ...added]);
  };

  const move = (i: number, dir: -1 | 1) => {
    const j = i + dir;
    if (j < 0 || j >= images.length) return;
    const next = [...images];
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
  };

  return (
    <div className="space-y-4">
      <div
        onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => { e.preventDefault(); setDrag(false); upload(e.dataTransfer.files); }}
        className={`flex flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed px-4 py-8 text-center transition ${drag ? "border-ink bg-beige/50" : "border-ink/15"}`}
      >
        <Icon name="share" size={24} />
        <p className="text-[14px]"><button type="button" onClick={() => input.current?.click()} className="font-semibold underline underline-offset-4">Upload photos</button> or drag them here</p>
        <p className="text-[12px] text-ash">JPG, PNG or WebP · up to 5 MB · 4:5 portrait looks best</p>
        {busy > 0 && <p className="text-[13px] font-medium">Uploading {busy}…</p>}
        <input ref={input} type="file" accept="image/jpeg,image/png,image/webp,image/avif" multiple hidden onChange={(e) => { if (e.target.files) upload(e.target.files); e.target.value = ""; }} />
      </div>

      <div className="flex gap-2">
        <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="…or paste an image URL" aria-label="Image URL" className={ainput} />
        <button type="button" onClick={() => { if (/^https?:\/\/|^\//.test(url.trim())) { onChange([...images, url.trim()]); setUrl(""); } else toast("Enter a full image URL"); }} className={abtnLine}>Add</button>
      </div>

      {images.length > 0 ? (
        <ul className="grid grid-cols-3 gap-3 sm:grid-cols-4">
          {images.map((src, i) => (
            <li key={src + i} className="group relative">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={src} alt="" className="aspect-[4/5] w-full rounded-lg bg-beige object-cover" />
              {i < 2 && <span className="absolute left-1.5 top-1.5 rounded bg-ink/80 px-1.5 py-0.5 text-[10px] font-semibold text-white">{i === 0 ? "Main" : "Hover"}</span>}
              <div className="absolute inset-x-1.5 bottom-1.5 flex justify-between gap-1">
                <span className="flex gap-1">
                  <button type="button" aria-label="Move left" onClick={() => move(i, -1)} className="grid h-7 w-7 place-items-center rounded bg-white/90 shadow"><Icon name="arrowLeft" size={14} /></button>
                  <button type="button" aria-label="Move right" onClick={() => move(i, 1)} className="grid h-7 w-7 place-items-center rounded bg-white/90 shadow"><Icon name="arrow" size={14} /></button>
                </span>
                <button type="button" aria-label="Remove photo" onClick={() => onChange(images.filter((_, n) => n !== i))} className="grid h-7 w-7 place-items-center rounded bg-white/90 text-rose-600 shadow"><Icon name="trash" size={14} /></button>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-[13px] text-ash">No photos yet — the colour-matched studio render is shown in the store until you add some.</p>
      )}
    </div>
  );
}
