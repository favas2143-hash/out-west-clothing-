"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { couponLabel, inr } from "@/lib/pricing";
import type { Coupon } from "@/lib/types";
import { useStore } from "@/components/providers/StoreProvider";
import { Icon } from "@/components/ui/Icon";
import { Pill, abtnDark, abtnLine, ainput } from "./ui";

type Draft = Partial<Coupon>;
const EMPTY: Draft = { code: "", type: "percent", value: 10, minOrder: 0, active: true };

function state(c: Coupon) {
  if (!c.active) return <Pill>Paused</Pill>;
  if (c.expiresAt && new Date(c.expiresAt).getTime() < Date.now()) return <Pill tone="bg-rose-50 text-rose-700 ring-rose-200">Expired</Pill>;
  if (c.maxUses && c.used >= c.maxUses) return <Pill tone="bg-amber-50 text-amber-800 ring-amber-200">Used up</Pill>;
  return <Pill tone="bg-emerald-50 text-emerald-800 ring-emerald-200">Active</Pill>;
}

export function CouponsView({ coupons }: { coupons: Coupon[] }) {
  const router = useRouter();
  const { toast } = useStore();
  const [edit, setEdit] = useState<{ id?: string; d: Draft } | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k: keyof Coupon, v: unknown) => setEdit((e) => (e ? { ...e, d: { ...e.d, [k]: v } } : e));

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!edit) return;
    setBusy(true);
    setError("");
    const r = await fetch(edit.id ? `/api/admin/coupons/${edit.id}` : "/api/admin/coupons", { method: edit.id ? "PUT" : "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(edit.d) });
    const j = await r.json();
    setBusy(false);
    if (!r.ok) return setError(j.error || "Couldn't save");
    toast(edit.id ? "Coupon updated" : "Coupon created", j.coupon.code);
    setEdit(null);
    router.refresh();
  };

  const quick = async (c: Coupon, patch: Partial<Coupon>) => {
    const r = await fetch(`/api/admin/coupons/${c.id}`, { method: "PUT", headers: { "content-type": "application/json" }, body: JSON.stringify({ ...c, ...patch }) });
    if (r.ok) { toast(patch.active ? "Coupon activated" : "Coupon paused"); router.refresh(); }
  };

  const [del, setDel] = useState<string | null>(null);
  const remove = async (c: Coupon) => {
    setDel(null);
    const r = await fetch(`/api/admin/coupons/${c.id}`, { method: "DELETE" });
    if (r.ok) { toast("Coupon deleted"); router.refresh(); }
  };

  const d = edit?.d ?? EMPTY;

  return (
    <div>
      <div className="mb-4 flex justify-end"><button onClick={() => { setError(""); setEdit({ d: { ...EMPTY } }); }} className={abtnDark}>+ New coupon</button></div>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {coupons.map((c) => (
          <div key={c.id} className="flex flex-col rounded-xl border border-ink/[0.07] bg-white p-5">
            <div className="flex items-start justify-between gap-3">
              <p className="rounded-md border border-dashed border-ink/30 bg-beige/50 px-2.5 py-1 font-mono text-[15px] font-semibold tracking-wider">{c.code}</p>
              {state(c)}
            </div>
            <p className="mt-3 text-[15px] font-medium">{couponLabel(c)}</p>
            {c.description && <p className="text-[13px] text-ash">{c.description}</p>}
            <dl className="mt-3 grid grid-cols-2 gap-2 text-[13px]">
              <div><dt className="text-ash">Used</dt><dd className="font-medium tabular-nums">{c.used}{c.maxUses ? ` / ${c.maxUses}` : ""}</dd></div>
              <div><dt className="text-ash">Expires</dt><dd className="font-medium">{c.expiresAt ? new Date(c.expiresAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) : "Never"}</dd></div>
            </dl>
            <div className="mt-4 flex gap-2 border-t border-ink/[0.06] pt-4">
              <button onClick={() => { setError(""); setEdit({ id: c.id, d: { ...c } }); }} className={`${abtnLine} h-9 flex-1`}><Icon name="edit" size={15} /> Edit</button>
              <button onClick={() => quick(c, { active: !c.active })} className={`${abtnLine} h-9 flex-1`}>{c.active ? "Pause" : "Activate"}</button>
              <button aria-label="Delete" onClick={() => setDel(c.id)} className={`${abtnLine} h-9 px-3 text-rose-600`}><Icon name="trash" size={15} /></button>
            </div>
            {del === c.id && (
              <div className="mt-3 flex items-center justify-between gap-2 rounded-lg bg-rose-50 px-3 py-2 text-[13px]">
                <span>Delete {c.code}?</span>
                <span className="flex gap-2"><button onClick={() => remove(c)} className="font-semibold text-rose-700">Delete</button><button onClick={() => setDel(null)} className="text-ash">Keep</button></span>
              </div>
            )}
          </div>
        ))}
        {coupons.length === 0 && <p className="rounded-xl bg-white p-10 text-center text-ash sm:col-span-2 xl:col-span-3">No coupons yet.</p>}
      </div>

      {edit && (
        <div className="fixed inset-0 z-50 grid place-items-end bg-black/40 sm:place-items-center sm:p-4" role="dialog" aria-modal="true" aria-label="Coupon">
          <form onSubmit={save} className="max-h-[92dvh] w-full max-w-lg space-y-4 overflow-y-auto rounded-t-2xl bg-white p-6 sm:rounded-2xl">
            <div className="flex items-center justify-between"><h2 className="text-[19px] font-semibold">{edit.id ? "Edit coupon" : "New coupon"}</h2><button type="button" aria-label="Close" onClick={() => setEdit(null)} className="grid h-9 w-9 place-items-center"><Icon name="close" /></button></div>
            <label className="block text-[13px] font-medium">Code<input required value={d.code ?? ""} onChange={(e) => set("code", e.target.value.toUpperCase().replace(/\s/g, ""))} placeholder="DIWALI20" className={`${ainput} mt-1 font-mono uppercase tracking-wider`} /></label>
            <div className="grid grid-cols-2 gap-3">
              <label className="block text-[13px] font-medium">Type<select value={d.type} onChange={(e) => set("type", e.target.value)} className={`${ainput} mt-1`}><option value="percent">Percentage off</option><option value="flat">Flat ₹ off</option></select></label>
              <label className="block text-[13px] font-medium">{d.type === "percent" ? "Percent" : "Amount (₹)"}<input type="number" min={1} max={d.type === "percent" ? 90 : undefined} required value={d.value ?? ""} onChange={(e) => set("value", +e.target.value)} className={`${ainput} mt-1`} /></label>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <label className="block text-[13px] font-medium">Minimum order (₹)<input type="number" min={0} value={d.minOrder ?? 0} onChange={(e) => set("minOrder", +e.target.value)} className={`${ainput} mt-1`} /></label>
              <label className="block text-[13px] font-medium">Usage limit<input type="number" min={1} value={d.maxUses ?? ""} onChange={(e) => set("maxUses", e.target.value ? +e.target.value : undefined)} placeholder="Unlimited" className={`${ainput} mt-1`} /></label>
            </div>
            <label className="block text-[13px] font-medium">Expires on<input type="date" value={d.expiresAt ? d.expiresAt.slice(0, 10) : ""} onChange={(e) => set("expiresAt", e.target.value ? `${e.target.value}T23:59:59+05:30` : undefined)} className={`${ainput} mt-1`} /></label>
            <label className="block text-[13px] font-medium">Description (shown to shoppers)<input value={d.description ?? ""} onChange={(e) => set("description", e.target.value)} placeholder="20% off for Diwali" className={`${ainput} mt-1`} /></label>
            <label className="flex items-center gap-2 text-[14px]"><input type="checkbox" checked={d.active ?? true} onChange={(e) => set("active", e.target.checked)} className="h-5 w-5 accent-ink" /> Active</label>
            {d.code && d.value ? <p className="rounded-lg bg-beige/60 p-3 text-[13px]">Shoppers get <b>{couponLabel({ code: d.code, type: d.type ?? "percent", value: d.value, minOrder: d.minOrder ?? 0 })}</b>{d.type === "percent" ? ` — e.g. ${inr(Math.round(((d.value ?? 0) * 2999) / 100))} off a ₹2,999 hoodie` : ""}.</p> : null}
            {error && <p role="alert" className="text-[14px] text-rose-600">{error}</p>}
            <div className="flex gap-2 pt-1"><button type="button" onClick={() => setEdit(null)} className={`${abtnLine} flex-1`}>Cancel</button><button disabled={busy} className={`${abtnDark} flex-1`}>{busy ? "Saving…" : "Save coupon"}</button></div>
          </form>
        </div>
      )}
    </div>
  );
}
