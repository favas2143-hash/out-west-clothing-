"use client";

import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { stockKey } from "@/lib/catalog";
import type { Product } from "@/lib/types";
import { ProductArt } from "@/components/product/ProductArt";
import { useStore } from "@/components/providers/StoreProvider";
import { Icon } from "@/components/ui/Icon";
import { abtnLine, ainput } from "./ui";
import { downloadCSV } from "./csv";

export function InventoryView({ products, lowOnly, lowAt = 3 }: { products: Product[]; lowOnly: boolean; lowAt?: number }) {
  const router = useRouter();
  const { toast } = useStore();
  const [edits, setEdits] = useState<Record<string, number>>({});
  const [low, setLow] = useState(lowOnly);
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const id = (p: Product, k: string) => `${p.id}|${k}`;
  const val = (p: Product, k: string) => edits[id(p, k)] ?? p.stock[k] ?? 0;

  const list = useMemo(
    () => products.filter((p) => p.name.toLowerCase().includes(q.toLowerCase()) && (!low || Object.values(p.stock).some((n) => n <= lowAt))),
    [products, q, low, lowAt],
  );
  const changed = Object.keys(edits).length;

  const save = async () => {
    setBusy(true);
    const updates = Object.entries(edits).map(([k, qty]) => {
      const [productId, key] = k.split("|");
      return { productId, key, qty };
    });
    const r = await fetch("/api/admin/inventory", { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ updates }) });
    setBusy(false);
    if (r.ok) {
      toast("Stock updated", `${updates.length} variant${updates.length === 1 ? "" : "s"} saved`);
      setEdits({});
      router.refresh();
    } else toast("Couldn't save stock");
  };

  return (
    <div className="space-y-4 pb-24">
      <div className="flex flex-wrap items-center gap-3 rounded-xl border border-ink/[0.07] bg-white p-3">
        <div className="relative min-w-[200px] flex-1">
          <Icon name="search" size={16} className="absolute left-3 top-3 text-ash" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search products" aria-label="Search" className={`${ainput} pl-9`} />
        </div>
        <label className="flex items-center gap-2 text-[14px]"><input type="checkbox" checked={low} onChange={(e) => setLow(e.target.checked)} className="h-5 w-5 accent-ink" /> Only low stock (≤ {lowAt})</label>
        <button
          onClick={() => {
            const rows: (string | number)[][] = [["Product", "Colour", "Size", "Stock"]];
            list.forEach((p) => p.colours.forEach((c) => p.sizes.forEach((s) => rows.push([p.name, c.name, s, val(p, stockKey(c.name, s))]))));
            downloadCSV(`outwest-stock-${new Date().toISOString().slice(0, 10)}.csv`, rows);
          }}
          className={abtnLine}
        >
          <Icon name="share" size={16} /> Export CSV
        </button>
      </div>
      {list.map((p) => (
        <section key={p.id} className="rounded-xl border border-ink/[0.07] bg-white p-4 sm:p-5">
          <div className="mb-3 flex items-center gap-3">
            <div className="aspect-[4/5] w-10 shrink-0 bg-beige"><ProductArt kind={p.kind} hex={p.colours[0]?.hex ?? "#111"} src={p.images[0]} alt="" /></div>
            <div>
              <p className="font-semibold">{p.name}</p>
              <p className="text-[12px] text-ash">{Object.values(p.stock).reduce((a, b) => a + b, 0)} units{!p.active && " · hidden"}</p>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="text-[13px]">
              <thead><tr><th className="pb-2 pr-4 text-left font-semibold text-ash">Colour</th>{p.sizes.map((s) => <th key={s} className="px-1 pb-2 font-semibold">{s}</th>)}</tr></thead>
              <tbody>
                {p.colours.map((c) => (
                  <tr key={c.name}>
                    <td className="whitespace-nowrap py-1 pr-4"><span className="mr-2 inline-block h-3 w-3 rounded-full border border-ink/20 align-middle" style={{ background: c.hex }} />{c.name}</td>
                    {p.sizes.map((s) => {
                      const k = stockKey(c.name, s);
                      const v = val(p, k);
                      const dirty = id(p, k) in edits;
                      return (
                        <td key={s} className="px-1 py-1">
                          <input
                            type="number"
                            min={0}
                            aria-label={`${p.name} ${c.name} ${s}`}
                            value={v}
                            onChange={(e) => setEdits({ ...edits, [id(p, k)]: Math.max(0, +e.target.value) })}
                            className={`h-10 w-16 rounded-md border px-2 text-right tabular-nums ${dirty ? "border-ink bg-beige" : v === 0 ? "border-rose-300 bg-rose-50 text-rose-700" : v <= lowAt ? "border-amber-300 bg-amber-50 font-semibold" : "border-ink/15"}`}
                          />
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      ))}
      {list.length === 0 && <p className="rounded-xl bg-white p-10 text-center text-ash">Nothing to show.</p>}
      <div className={`fixed bottom-4 right-4 z-40 flex items-center gap-3 rounded-xl bg-ink p-3 pl-5 text-bone shadow-xl transition ${changed ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-4 opacity-0"}`}>
        <span className="text-[14px]">{changed} unsaved change{changed === 1 ? "" : "s"}</span>
        <button onClick={() => setEdits({})} className="h-10 px-3 text-[13px] text-bone/70 hover:text-bone">Discard</button>
        <button onClick={save} disabled={busy} className="btn-light h-10 px-5">{busy ? "Saving…" : "Save stock"}</button>
      </div>
    </div>
  );
}
