"use client";

import { Icon } from "@/components/ui/Icon";
import { abtnDark } from "./ui";

export function PrintButton() {
  return <button onClick={() => window.print()} className={abtnDark}><Icon name="box" size={16} /> Print / save PDF</button>;
}
