"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { slugify } from "@/lib/catalog";
import type { Category, GarmentKind } from "@/lib/types";
import { useStore } from "@/components/providers/StoreProvider";
import { ProductArt } from "@/components/product/ProductArt";
import { Icon } from "@/components/ui/Icon";
import { Pill, abtnDark, abtnLine, ainput } from "./ui";

const KINDS: [GarmentKind, string][] = [
  ["tee", "T-shirt"], ["oversized", "Oversized tee"], ["hoodie", "Hoodie"], ["shirt", "Shirt"],
  ["pants", "Trousers"], ["cargo", "Cargo pants"], ["cap", "Cap"], ["beanie", "Beanie"], ["tote", "Tote bag"],
];

export function CategoriesManager({ categories, counts }: { categories: Category[]; counts: Record<string, number> }) {
  const router = useRouter();
  const { toast } = useStore();
  const [list, setList] = useState<Category[]>(categories);
  const [open, setOpen] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const dirty = JSON.stringify(list) !== JSON.stringify(categories);

  const save = async (next = list, msg = "Categories saved") => {
    setBusy(true);
    setError("");
    // new categories get their link from the final name
    const body = next.map((c) => (categories.some((x) => x.slug === c.slug) ? c : { ...c, slug: slugify(c.name) }));
    const r = await fetch("/api/admin/settings", { method: "PUT", headers: { "content-type": "application/json" }, body: JSON.stringify({ categories: body }) });
    const j = await r.json();
    setBusy(false);
    if (!r.ok) {
      setError(j.error || "Couldn't save");
      return false;
    }
    setList(j.settings.categories);
    toast(msg, "The store is updated");
    router.refresh();
    return true;
  };

  const patch = (slug: string, p: Partial<Category>) => setList((l) => l.map((c) => (c.slug === slug ? { ...c, ...p } : c)));
  const move = (i: number, dir: -1 | 1) => {
    const j = i + dir;
    if (j < 0 || j >= list.length) return;
    const n = [...list];
    [n[i], n[j]] = [n[j], n[i]];
    setList(n);
  };
  // show/hide saves straight away — it's the most common action
  const toggle = (c: Category) => {
    const next = list.map((x) => (x.slug === c.slug ? { ...x, active: !x.active } : x));
    save(next, c.active ? `${c.name} hidden from the store` : `${c.name} is now live`);
  };
  const add = () => {
    let name = "New category";
    let n = 2;
    while (list.some((c) => c.slug === slugify(name))) name = `New category ${n++}`;
    const c: Category = { slug: slugify(name), name, blurb: "", kind: "tee", colour: "#111111", active: false };
    setList([...list, c]);
    setOpen(c.slug);
  };

  return (
    <div className="pb-24">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <p className="text-[14px] text-ash">{list.filter((c) => c.active).length} of {list.length} categories live</p>
        <button onClick={add} className={abtnDark}>+ Add category</button>
      </div>

      <ul className="space-y-3">
        {list.map((c, i) => {
          const isNew = !categories.some((x) => x.slug === c.slug);
          const count = counts[c.slug] ?? 0;
          return (
            <li key={c.slug} className={`overflow-hidden rounded-xl border bg-white ${c.active ? "border-ink/[0.07]" : "border-dashed border-ink/20"}`}>
              <div className="flex items-center gap-3 p-3 sm:gap-4 sm:p-4">
                <div className="hidden flex-col sm:flex">
                  <button aria-label="Move up" disabled={i === 0} onClick={() => move(i, -1)} className="grid h-6 w-6 place-items-center rounded text-ash hover:bg-ink/5 disabled:opacity-30"><Icon name="arrow" size={13} className="-rotate-90" /></button>
                  <button aria-label="Move down" disabled={i === list.length - 1} onClick={() => move(i, 1)} className="grid h-6 w-6 place-items-center rounded text-ash hover:bg-ink/5 disabled:opacity-30"><Icon name="arrow" size={13} className="rotate-90" /></button>
                </div>
                <div className={`aspect-[4/5] w-12 shrink-0 overflow-hidden rounded-lg sm:w-14 ${c.active ? "" : "opacity-50 grayscale"}`}>
                  <ProductArt kind={c.kind} hex={c.colour} bg={["#111111", "#3a3a38", "#3b2f28"].includes(c.colour) ? "#d9cfbf" : "#2b2a28"} alt="" plain />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="flex flex-wrap items-center gap-2 font-semibold">
                    {c.name}
                    {c.active ? <Pill tone="bg-emerald-50 text-emerald-800 ring-emerald-200">Live</Pill> : <Pill>Hidden</Pill>}
                    {isNew && <Pill tone="bg-amber-50 text-amber-800 ring-amber-200">Unsaved</Pill>}
                  </p>
                  <p className="truncate text-[13px] text-ash">{count} product{count === 1 ? "" : "s"}{c.blurb ? ` · ${c.blurb}` : ""}</p>
                </div>
                <button
                  role="switch"
                  aria-checked={c.active}
                  aria-label={`${c.active ? "Hide" : "Show"} ${c.name}`}
                  disabled={busy || isNew}
                  onClick={() => toggle(c)}
                  title={isNew ? "Save the new category first" : c.active ? "Hide from store" : "Show in store"}
                  className={`relative h-7 w-12 shrink-0 rounded-full transition disabled:opacity-40 ${c.active ? "bg-emerald-600" : "bg-ink/20"}`}
                >
                  <span className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-all ${c.active ? "left-6" : "left-1"}`} />
                </button>
                <button aria-label="Edit" onClick={() => setOpen(open === c.slug ? null : c.slug)} className="grid h-9 w-9 shrink-0 place-items-center rounded-lg hover:bg-ink/5"><Icon name={open === c.slug ? "close" : "edit"} size={17} /></button>
              </div>

              {open === c.slug && (
                <div className="grid gap-4 border-t border-ink/[0.06] bg-ink/[0.015] p-4 sm:grid-cols-2">
                  <label className="text-[13px] font-medium">Name<input value={c.name} onChange={(e) => patch(c.slug, { name: e.target.value })} className={`${ainput} mt-1`} /></label>
                  <label className="text-[13px] font-medium">Short description<input value={c.blurb} onChange={(e) => patch(c.slug, { blurb: e.target.value })} placeholder="e.g. 400 GSM brushed fleece" className={`${ainput} mt-1`} /></label>
                  <label className="text-[13px] font-medium">Tile image style<select value={c.kind} onChange={(e) => patch(c.slug, { kind: e.target.value as GarmentKind })} className={`${ainput} mt-1`}>{KINDS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></label>
                  <label className="text-[13px] font-medium">Tile colour<div className="mt-1 flex gap-2"><input type="color" value={c.colour} onChange={(e) => patch(c.slug, { colour: e.target.value })} className="h-10 w-12 cursor-pointer rounded-lg border border-ink/15 bg-white p-1" /><input value={c.colour} onChange={(e) => patch(c.slug, { colour: e.target.value })} className={ainput} /></div></label>
                  <div className="flex flex-wrap items-center gap-2 sm:col-span-2">
                    <span className="text-[12px] text-ash">Link: /shop?category={c.slug}</span>
                    <span className="flex-1" />
                    {count > 0 ? (
                      <Link href="/admin/products" className="text-[13px] text-ash underline underline-offset-4">Manage its {count} products</Link>
                    ) : (
                      <button onClick={() => { setList(list.filter((x) => x.slug !== c.slug)); setOpen(null); }} className="text-[13px] text-rose-600 hover:underline">Delete category</button>
                    )}
                  </div>
                </div>
              )}
            </li>
          );
        })}
      </ul>
      <p className="mt-4 text-[13px] text-ash">Tip: the order here (use the arrows) is the order shoppers see in menus and on the homepage. To add products to a new category, save it, then pick it when you add or edit a product.</p>

      <div className={`fixed inset-x-0 bottom-0 z-40 border-t border-ink/10 bg-white/95 px-4 py-3 backdrop-blur transition lg:left-[248px] ${dirty ? "translate-y-0" : "translate-y-full"}`}>
        <div className="mx-auto flex max-w-5xl items-center justify-end gap-3">
          {error ? <p className="mr-auto text-[14px] text-rose-600">{error}</p> : <span className="mr-auto hidden text-[14px] text-ash sm:block">Unsaved changes</span>}
          <button onClick={() => { setList(categories); setError(""); }} className={abtnLine}>Discard</button>
          <button disabled={busy} onClick={() => save()} className={abtnDark}>{busy ? "Saving…" : "Save categories"}</button>
        </div>
      </div>
    </div>
  );
}
