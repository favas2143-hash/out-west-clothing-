"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { AppliedCoupon, CartItem, CategorySlug, GarmentKind, PublicUser, StoreSettings } from "@/lib/types";
import { DEFAULT_SETTINGS } from "@/lib/pricing";

export interface IndexItem {
  id: string;
  slug: string;
  name: string;
  category: CategorySlug;
  kind: GarmentKind;
  hex: string;
  price: number;
  mrp: number;
  image?: string;
}

interface Toast {
  id: number;
  title: string;
  body?: string;
}

interface Store {
  index: IndexItem[];
  cart: CartItem[];
  cartCount: number;
  subtotal: number;
  addToCart: (item: CartItem, opts?: { silent?: boolean }) => void;
  setQty: (key: string, qty: number) => void;
  removeFromCart: (key: string) => void;
  clearCart: () => void;
  wishlist: string[];
  toggleWishlist: (productId: string) => void;
  cartOpen: boolean;
  setCartOpen: (v: boolean) => void;
  searchOpen: boolean;
  setSearchOpen: (v: boolean) => void;
  menuOpen: boolean;
  setMenuOpen: (v: boolean) => void;
  toasts: Toast[];
  toast: (title: string, body?: string) => void;
  user: PublicUser | null;
  setUser: (u: PublicUser | null) => void;
  hydrated: boolean;
  settings: StoreSettings;
  coupon: AppliedCoupon | null;
  setCoupon: (c: AppliedCoupon | null) => void;
}

const Ctx = createContext<Store | null>(null);

export const lineKey = (i: Pick<CartItem, "productId" | "colour" | "size">) =>
  `${i.productId}|${i.colour}|${i.size}`;

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function save(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable — cart still works in memory */
  }
}

export function StoreProvider({
  children,
  index,
  initialUser = null,
  settings = DEFAULT_SETTINGS,
}: {
  children: React.ReactNode;
  index: IndexItem[];
  initialUser?: PublicUser | null;
  settings?: StoreSettings;
}) {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [user, setUser] = useState<PublicUser | null>(initialUser);
  const [coupon, setCoupon] = useState<AppliedCoupon | null>(null);

  useEffect(() => {
    setCart(load("ow_cart", []));
    setWishlist(load("ow_wishlist", []));
    setCoupon(load("ow_coupon", null));
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) save("ow_cart", cart);
  }, [cart, hydrated]);
  useEffect(() => {
    if (hydrated) save("ow_wishlist", wishlist);
  }, [wishlist, hydrated]);
  useEffect(() => {
    if (hydrated) save("ow_coupon", coupon);
  }, [coupon, hydrated]);

  // lock page scroll while an overlay is open
  useEffect(() => {
    const lock = cartOpen || searchOpen || menuOpen;
    document.documentElement.style.overflow = lock ? "hidden" : "";
  }, [cartOpen, searchOpen, menuOpen]);

  const toast = useCallback((title: string, body?: string) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, title, body }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }, []);

  const addToCart = useCallback(
    (item: CartItem, opts?: { silent?: boolean }) => {
      setCart((c) => {
        const k = lineKey(item);
        const existing = c.find((x) => lineKey(x) === k);
        if (existing) return c.map((x) => (lineKey(x) === k ? { ...x, qty: Math.min(10, x.qty + item.qty) } : x));
        return [...c, item];
      });
      if (!opts?.silent) setCartOpen(true);
    },
    [],
  );

  const setQty = useCallback((key: string, qty: number) => {
    setCart((c) =>
      qty <= 0 ? c.filter((x) => lineKey(x) !== key) : c.map((x) => (lineKey(x) === key ? { ...x, qty: Math.min(10, qty) } : x)),
    );
  }, []);

  const removeFromCart = useCallback((key: string) => setCart((c) => c.filter((x) => lineKey(x) !== key)), []);
  const clearCart = useCallback(() => {
    setCart([]);
    setCoupon(null);
  }, []);

  const toggleWishlist = useCallback(
    (id: string) => {
      const has = wishlist.includes(id);
      toast(has ? "Removed from wishlist" : "Saved to wishlist");
      setWishlist((w) => (w.includes(id) ? w.filter((x) => x !== id) : [...w, id]));
    },
    [toast, wishlist],
  );

  const value = useMemo<Store>(
    () => ({
      index,
      cart,
      cartCount: cart.reduce((a, b) => a + b.qty, 0),
      subtotal: cart.reduce((a, b) => a + b.qty * b.price, 0),
      addToCart,
      setQty,
      removeFromCart,
      clearCart,
      wishlist,
      toggleWishlist,
      cartOpen,
      setCartOpen,
      searchOpen,
      setSearchOpen,
      menuOpen,
      setMenuOpen,
      toasts,
      toast,
      user,
      setUser,
      hydrated,
      settings,
      coupon,
      setCoupon,
    }),
    [index, cart, addToCart, setQty, removeFromCart, clearCart, wishlist, toggleWishlist, cartOpen, searchOpen, menuOpen, toasts, toast, user, hydrated, settings, coupon],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore() {
  const s = useContext(Ctx);
  if (!s) throw new Error("useStore must be used inside <StoreProvider>");
  return s;
}
