"use client";

import { useRouter } from "next/navigation";
import { useStore } from "@/components/providers/StoreProvider";
import { Icon } from "@/components/ui/Icon";

export function SignOutButton({ className = "btn-line" }: { className?: string }) {
  const router = useRouter();
  const { setUser, toast } = useStore();
  return (
    <button
      className={className}
      onClick={async () => {
        await fetch("/api/auth/logout", { method: "POST" });
        setUser(null);
        toast("Signed out");
        router.push("/");
        router.refresh();
      }}
    >
      <Icon name="logout" size={16} /> Sign out
    </button>
  );
}
