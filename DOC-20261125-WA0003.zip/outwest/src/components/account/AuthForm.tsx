"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import type { PublicUser } from "@/lib/types";
import { useStore } from "@/components/providers/StoreProvider";

export function AuthForm({ mode, next }: { mode: "login" | "register"; next?: string }) {
  const router = useRouter();
  const { setUser, toast } = useStore();
  const [form, setForm] = useState({ name: "", email: "", phone: "", password: "" });
  const [show, setShow] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    const r = await fetch(`/api/auth/${mode}`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(form) });
    const j = (await r.json()) as { user?: PublicUser; error?: string };
    setBusy(false);
    if (!r.ok || !j.user) return setError(j.error || "Something went wrong");
    setUser(j.user);
    toast(mode === "login" ? `Welcome back, ${j.user.name.split(" ")[0]}` : "Account created");
    const safeNext = next && next.startsWith("/") && !next.startsWith("//") ? next : undefined;
    router.push(safeNext ?? (j.user.role === "admin" ? "/admin" : "/account"));
    router.refresh();
  };

  const login = mode === "login";
  return (
    <div className="wrap grid min-h-[70vh] place-items-center py-12">
      <div className="w-full max-w-md">
        <h1 className="display text-[clamp(40px,6vw,64px)]">{login ? "Sign in" : "Join OUT WEST"}</h1>
        <p className="mt-3 text-ash">{login ? "Track orders, save addresses and check out faster." : "Early access to drops, order tracking and 10% off your first order with WELCOME10."}</p>
        <form onSubmit={submit} className="mt-8 space-y-4">
          {!login && (
            <div>
              <label htmlFor="name" className="label">Full name</label>
              <input id="name" required autoComplete="name" value={form.name} onChange={set("name")} className="field" />
            </div>
          )}
          <div>
            <label htmlFor="email" className="label">Email</label>
            <input id="email" type="email" required autoComplete="email" value={form.email} onChange={set("email")} className="field" />
          </div>
          {!login && (
            <div>
              <label htmlFor="phone" className="label">Mobile (optional)</label>
              <input id="phone" inputMode="numeric" maxLength={10} autoComplete="tel-national" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value.replace(/\D/g, "") })} className="field" />
            </div>
          )}
          <div>
            <label htmlFor="password" className="label">Password</label>
            <div className="relative">
              <input id="password" type={show ? "text" : "password"} required minLength={login ? 1 : 8} autoComplete={login ? "current-password" : "new-password"} value={form.password} onChange={set("password")} className="field pr-20" />
              <button type="button" onClick={() => setShow((s) => !s)} className="absolute right-0 top-0 h-12 px-4 text-[12px] font-semibold uppercase tracking-[0.1em] text-ash">{show ? "Hide" : "Show"}</button>
            </div>
            {!login && <p className="mt-1.5 text-[12px] text-ash">At least 8 characters</p>}
          </div>
          {error && <p role="alert" className="text-[14px] text-sale">{error}</p>}
          <button disabled={busy} className="btn-dark h-14 w-full">{busy ? "Please wait…" : login ? "Sign in" : "Create account"}</button>
        </form>
        <p className="mt-6 text-center text-[14px] text-ash">
          {login ? "New to OUT WEST? " : "Already have an account? "}
          <Link href={`${login ? "/account/register" : "/account/login"}${next ? `?next=${encodeURIComponent(next)}` : ""}`} className="font-semibold text-ink underline underline-offset-4">
            {login ? "Create an account" : "Sign in"}
          </Link>
        </p>
      </div>
    </div>
  );
}
