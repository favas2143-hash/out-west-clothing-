"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";
import { liveCategories } from "@/lib/catalog";
import { computeTotals, inr } from "@/lib/pricing";
import { Icon } from "@/components/ui/Icon";
import { lineKey, useStore } from "@/components/providers/StoreProvider";
import { ProductArt } from "@/components/product/ProductArt";
import { Logo } from "./Header";

function Sheet({
  open,
  onClose,
  side,
  label,
  children,
}: {
  open: boolean;
  onClose: () => void;
  side: "left" | "right" | "top";
  label: string;
  children: React.ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [open, onClose]);

  const pos =
    side === "left"
      ? `left-0 top-0 h-full w-[88%] max-w-[420px] ${open ? "translate-x-0" : "-translate-x-full"}`
      : side === "right"
        ? `right-0 top-0 h-full w-full max-w-[460px] ${open ? "translate-x-0" : "translate-x-full"}`
        : `inset-x-0 top-0 max-h-[100dvh] ${open ? "translate-y-0" : "-translate-y-full"}`;

  return (
    <div className={`fixed inset-0 z-50 ${open ? "" : "pointer-events-none"}`} aria-hidden={!open}>
      <div
        onClick={onClose}
        className={`absolute inset-0 bg-ink/50 backdrop-blur-[2px] transition-opacity duration-500 ${open ? "opacity-100" : "opacity-0"}`}
      />
      <aside
        role="dialog"
        aria-modal="true"
        aria-label={label}
        className={`absolute flex flex-col bg-bone text-ink shadow-2xl transition-transform duration-500 ease-[cubic-bezier(.2,.7,.1,1)] ${pos}`}
      >
        {children}
      </aside>
    </div>
  );
}

function MobileMenu() {
  const { menuOpen, setMenuOpen, user, settings } = useStore();
  const pathname = usePathname();
  useEffect(() => setMenuOpen(false), [pathname, setMenuOpen]);
  const close = () => setMenuOpen(false);
  return (
    <Sheet open={menuOpen} onClose={close} side="left" label="Menu">
      <div className="flex h-16 items-center justify-between border-b border-ink/10 px-5">
        <Logo />
        <button aria-label="Close menu" className="grid h-11 w-11 place-items-center" onClick={close}>
          <Icon name="close" />
        </button>
      </div>
      <nav className="flex-1 overflow-y-auto px-5 py-6">
        <Link href="/shop?tag=new" onClick={close} className="display block py-2 text-[34px]">New In</Link>
        <Link href="/shop?tag=bestseller" onClick={close} className="display block py-2 text-[34px]">Best Sellers</Link>
        <p className="eyebrow mb-2 mt-8 text-ash">Categories</p>
        {liveCategories(settings.categories).map((c) => (
          <Link key={c.slug} href={`/shop?category=${c.slug}`} onClick={close} className="flex items-center justify-between border-b border-ink/10 py-4 text-[17px] font-medium">
            {c.name}
            <Icon name="arrow" size={16} />
          </Link>
        ))}
        <Link href="/shop" onClick={close} className="flex items-center justify-between border-b border-ink/10 py-4 text-[17px] font-medium">
          Shop all <Icon name="arrow" size={16} />
        </Link>
      </nav>
      <div className="grid grid-cols-2 gap-px border-t border-ink/10 bg-ink/10 text-[13px] font-semibold uppercase tracking-[0.12em]">
        <Link href={user ? "/account" : "/account/login"} onClick={close} className="flex h-14 items-center gap-2 bg-bone px-5"><Icon name="user" size={18} /> {user ? "Account" : "Sign in"}</Link>
        <Link href="/track" onClick={close} className="flex h-14 items-center gap-2 bg-bone px-5"><Icon name="truck" size={18} /> Track order</Link>
        <Link href="/wishlist" onClick={close} className="flex h-14 items-center gap-2 bg-bone px-5"><Icon name="heart" size={18} /> Wishlist</Link>
        <a href={`https://instagram.com/${process.env.NEXT_PUBLIC_INSTAGRAM_HANDLE || "outwest.in"}`} target="_blank" rel="noreferrer" className="flex h-14 items-center gap-2 bg-bone px-5"><Icon name="instagram" size={18} /> Instagram</a>
      </div>
    </Sheet>
  );
}

function SearchOverlay() {
  const { searchOpen, setSearchOpen, index } = useStore();
  const [q, setQ] = useState("");
  const input = useRef<HTMLInputElement>(null);
  const router = useRouter();
  const close = () => setSearchOpen(false);

  useEffect(() => {
    if (searchOpen) setTimeout(() => input.current?.focus(), 150);
    else setQ("");
  }, [searchOpen]);

  const results = useMemo(() => {
    const t = q.trim().toLowerCase();
    if (!t) return [];
    return index.filter((p) => `${p.name} ${p.category.replace(/-/g, " ")}`.toLowerCase().includes(t)).slice(0, 8);
  }, [q, index]);

  return (
    <Sheet open={searchOpen} onClose={close} side="top" label="Search">
      <form
        className="wrap flex h-20 items-center gap-3 border-b border-ink/10"
        onSubmit={(e) => {
          e.preventDefault();
          close();
          router.push(`/shop?q=${encodeURIComponent(q)}`);
        }}
      >
        <Icon name="search" size={22} />
        <input
          ref={input}
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search hoodies, cargos, oversized tees…"
          className="h-full flex-1 bg-transparent text-[18px] outline-none placeholder:text-ash"
          aria-label="Search products"
        />
        <button type="button" aria-label="Close search" className="grid h-11 w-11 place-items-center" onClick={close}>
          <Icon name="close" />
        </button>
      </form>
      <div className="wrap max-h-[70dvh] overflow-y-auto py-6">
        {!q && (
          <div>
            <p className="eyebrow mb-4 text-ash">Trending</p>
            <div className="flex flex-wrap gap-2">
              {["Oversized tee", "Hoodie", "Cargo", "Black", "Cap"].map((t) => (
                <button key={t} onClick={() => setQ(t.split(" ")[0])} className="h-10 border border-ink/15 px-4 text-sm hover:border-ink">
                  {t}
                </button>
              ))}
            </div>
          </div>
        )}
        {q && results.length === 0 && <p className="py-6 text-ash">No pieces match “{q}”. Try “hoodie” or “cargo”.</p>}
        {results.length > 0 && (
          <ul className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {results.map((p) => (
              <li key={p.id}>
                <Link href={`/product/${p.slug}`} onClick={close} className="group block">
                  <div className="aspect-[4/5] overflow-hidden bg-beige">
                    <ProductArt kind={p.kind} hex={p.hex} src={p.image} alt={p.name} className="transition-transform duration-500 group-hover:scale-105" />
                  </div>
                  <p className="mt-2 text-sm font-medium">{p.name}</p>
                  <p className="text-sm text-ash">{inr(p.price)}</p>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </div>
    </Sheet>
  );
}

function CartDrawer() {
  const { cartOpen, setCartOpen, cart, setQty, removeFromCart, subtotal, settings } = useStore();
  const close = () => setCartOpen(false);
  const t = computeTotals(subtotal, { settings });
  const pct = Math.min(100, (subtotal / (subtotal + t.toFreeShipping || 1)) * 100);
  return (
    <Sheet open={cartOpen} onClose={close} side="right" label="Shopping bag">
      <div className="flex h-16 items-center justify-between border-b border-ink/10 px-5">
        <p className="eyebrow">Your bag ({cart.reduce((a, b) => a + b.qty, 0)})</p>
        <button aria-label="Close bag" className="grid h-11 w-11 place-items-center" onClick={close}>
          <Icon name="close" />
        </button>
      </div>
      {cart.length === 0 ? (
        <div className="flex flex-1 flex-col items-center justify-center gap-5 px-8 text-center">
          <Icon name="bag" size={40} strokeWidth={1.2} />
          <p className="display text-[28px]">Your bag is empty</p>
          <p className="text-ash">The new season is waiting. Start with our best-selling oversized tee.</p>
          <Link href="/shop?tag=bestseller" onClick={close} className="btn-dark w-full">Shop best sellers</Link>
        </div>
      ) : (
        <>
          <div className="border-b border-ink/10 px-5 py-4">
            <p className="text-[13px]">
              {t.toFreeShipping > 0 ? (
                <>You&apos;re <b>{inr(t.toFreeShipping)}</b> away from free shipping</>
              ) : (
                <>You&apos;ve unlocked <b>free shipping</b></>
              )}
            </p>
            <div className="mt-2 h-[3px] bg-ink/10">
              <div className="h-full bg-ink transition-all duration-700" style={{ width: `${t.toFreeShipping > 0 ? pct : 100}%` }} />
            </div>
          </div>
          <ul className="flex-1 divide-y divide-ink/10 overflow-y-auto px-5">
            {cart.map((i) => {
              const k = lineKey(i);
              return (
                <li key={k} className="flex gap-4 py-5">
                  <Link href={`/product/${i.slug}`} onClick={close} className="aspect-[4/5] w-24 shrink-0 overflow-hidden bg-beige">
                    <ProductArt kind={i.kind} hex={i.hex} src={i.image} alt={i.name} />
                  </Link>
                  <div className="flex min-w-0 flex-1 flex-col">
                    <div className="flex justify-between gap-3">
                      <p className="text-[15px] font-medium leading-snug">{i.name}</p>
                      <p className="whitespace-nowrap text-[15px] font-semibold">{inr(i.price * i.qty)}</p>
                    </div>
                    <p className="mt-1 text-[13px] text-ash">{i.colour} · {i.size}</p>
                    <div className="mt-auto flex items-center justify-between pt-3">
                      <div className="flex h-10 items-center border border-ink/15">
                        <button aria-label="Decrease quantity" className="grid h-10 w-10 place-items-center" onClick={() => setQty(k, i.qty - 1)}><Icon name="minus" size={14} /></button>
                        <span className="w-6 text-center text-sm font-semibold">{i.qty}</span>
                        <button aria-label="Increase quantity" className="grid h-10 w-10 place-items-center" onClick={() => setQty(k, i.qty + 1)}><Icon name="plus" size={14} /></button>
                      </div>
                      <button className="text-[12px] uppercase tracking-[0.12em] text-ash underline-offset-4 hover:text-ink hover:underline" onClick={() => removeFromCart(k)}>
                        Remove
                      </button>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
          <div className="space-y-3 border-t border-ink/10 bg-white px-5 pb-[max(20px,env(safe-area-inset-bottom))] pt-5">
            <div className="flex justify-between text-[15px]"><span>Subtotal</span><b>{inr(subtotal)}</b></div>
            <p className="text-[12px] text-ash">Taxes included. Shipping & COD fee calculated at checkout.</p>
            <Link href="/checkout" onClick={close} className="btn-dark w-full"><Icon name="lock" size={16} /> Secure checkout</Link>
            <Link href="/cart" onClick={close} className="btn-line w-full">View bag</Link>
            <p className="flex items-center justify-center gap-2 text-[11px] uppercase tracking-[0.14em] text-ash">UPI · Cards · Netbanking{settings.codEnabled ? " · COD" : ""}</p>
          </div>
        </>
      )}
    </Sheet>
  );
}

export function Toasts() {
  const { toasts } = useStore();
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-4 z-[60] flex flex-col items-center gap-2 px-4" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className="animate-rise flex items-center gap-3 bg-ink px-5 py-3.5 text-bone shadow-xl">
          <Icon name="check" size={18} />
          <div>
            <p className="text-sm font-semibold">{t.title}</p>
            {t.body && <p className="text-[13px] opacity-75">{t.body}</p>}
          </div>
        </div>
      ))}
    </div>
  );
}

/** Adds the `in` class to `.reveal` elements as they scroll into view. */
function RevealObserver() {
  const pathname = usePathname();
  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && (e.target.classList.add("in"), io.unobserve(e.target))),
      { rootMargin: "0px 0px -8% 0px" },
    );
    const scan = () => document.querySelectorAll(".reveal:not(.in)").forEach((el) => io.observe(el));
    scan();
    const mo = new MutationObserver(scan);
    mo.observe(document.body, { childList: true, subtree: true });
    return () => {
      io.disconnect();
      mo.disconnect();
    };
  }, [pathname]);
  return null;
}

export function Overlays() {
  return (
    <>
      <MobileMenu />
      <SearchOverlay />
      <CartDrawer />
      <Toasts />
      <RevealObserver />
    </>
  );
}
