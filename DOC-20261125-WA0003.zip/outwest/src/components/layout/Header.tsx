"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { liveCategories } from "@/lib/catalog";
import { Icon } from "@/components/ui/Icon";
import { useStore } from "@/components/providers/StoreProvider";
import { ProductArt } from "@/components/product/ProductArt";

export function Logo({ className = "" }: { className?: string }) {
  return (
    <span className={`display whitespace-nowrap text-[22px] leading-none tracking-[-0.03em] sm:text-[26px] ${className}`}>
      OUT WEST
    </span>
  );
}

const NAV = [
  { href: "/shop?tag=new", label: "New In" },
  { href: "/shop", label: "Shop", mega: true },
  { href: "/shop?category=oversized-t-shirts", label: "Oversized" },
  { href: "/shop?category=hoodies", label: "Hoodies" },
  { href: "/shop?tag=bestseller", label: "Best Sellers" },
];

export function Header() {
  const pathname = usePathname();
  const { cartCount, setCartOpen, setSearchOpen, setMenuOpen, wishlist, hydrated, user, settings } = useStore();
  const cats = liveCategories(settings.categories);
  const [scrolled, setScrolled] = useState(false);
  const [mega, setMega] = useState(false);

  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 40);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  useEffect(() => setMega(false), [pathname]);

  const overlay = pathname === "/" && !scrolled && !mega;

  return (
    <header
      className={`sticky top-0 z-40 transition-colors duration-500 ${
        overlay ? "bg-transparent text-bone" : "border-b border-ink/10 bg-bone/92 text-ink backdrop-blur-xl"
      } ${pathname === "/" ? "-mb-16 lg:-mb-[72px]" : ""}`}
      onMouseLeave={() => setMega(false)}
    >
      <div className="wrap grid h-16 grid-cols-[1fr_auto_1fr] items-center lg:h-[72px]">
        <div className="flex items-center gap-1">
          <button aria-label="Open menu" className="-ml-2 grid h-11 w-11 place-items-center lg:hidden" onClick={() => setMenuOpen(true)}>
            <Icon name="menu" size={22} />
          </button>
          <nav className="hidden items-center gap-7 lg:flex" aria-label="Primary">
            {NAV.filter((n) => !n.href.includes("category=") || cats.some((c) => n.href.endsWith(c.slug))).map((n) => (
              <Link
                key={n.label}
                href={n.href}
                onMouseEnter={() => setMega(!!n.mega)}
                className="relative py-6 text-[12px] font-semibold uppercase tracking-[0.16em] after:absolute after:inset-x-0 after:bottom-5 after:h-px after:origin-left after:scale-x-0 after:bg-current after:transition-transform hover:after:scale-x-100"
              >
                {n.label}
              </Link>
            ))}
          </nav>
        </div>

        <Link href="/" aria-label="OUT WEST home">
          <Logo />
        </Link>

        <div className="flex items-center justify-end gap-0.5 sm:gap-1">
          <button aria-label="Search" className="grid h-11 w-11 place-items-center" onClick={() => setSearchOpen(true)}>
            <Icon name="search" />
          </button>
          <Link aria-label="Account" href={user ? (user.role === "admin" ? "/admin" : "/account") : "/account/login"} className="hidden h-11 w-11 place-items-center sm:grid">
            <Icon name="user" />
          </Link>
          <Link aria-label="Wishlist" href="/wishlist" className="relative hidden h-11 w-11 place-items-center sm:grid">
            <Icon name="heart" />
            {hydrated && wishlist.length > 0 && <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-current" />}
          </Link>
          <button aria-label={`Bag, ${cartCount} items`} className="relative -mr-2 grid h-11 w-11 place-items-center" onClick={() => setCartOpen(true)}>
            <Icon name="bag" />
            {hydrated && cartCount > 0 && (
              <span
                className={`absolute right-1 top-1 grid h-[18px] min-w-[18px] place-items-center rounded-full px-1 text-[10px] font-bold ${
                  overlay ? "bg-bone text-ink" : "bg-ink text-bone"
                }`}
              >
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Desktop mega menu */}
      <div
        className={`absolute inset-x-0 top-full hidden border-b border-ink/10 bg-bone text-ink transition-all duration-300 lg:block ${
          mega ? "visible translate-y-0 opacity-100" : "invisible -translate-y-2 opacity-0"
        }`}
        onMouseEnter={() => setMega(true)}
      >
        <div className="wrap grid grid-cols-[1fr_2fr] gap-10 py-10">
          <div>
            <p className="eyebrow mb-5 text-ash">Shop by category</p>
            <ul className="space-y-3">
              {cats.map((c) => (
                <li key={c.slug}>
                  <Link href={`/shop?category=${c.slug}`} className="display text-[28px] transition-opacity hover:opacity-50">
                    {c.name}
                  </Link>
                </li>
              ))}
              <li className="pt-3">
                <Link href="/shop" className="eyebrow inline-flex items-center gap-2 underline-offset-4 hover:underline">
                  Shop all <Icon name="arrow" size={14} />
                </Link>
              </li>
            </ul>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[
              { t: "Concrete Season", s: "The FW26 campaign", href: "/shop?tag=new", kind: "hoodie" as const, hex: "#3a3a38", bg: "#d9cfbf" },
              { t: "The Oversized Edit", s: "240 GSM heavyweights", href: "/shop?category=oversized-t-shirts", kind: "oversized" as const, hex: "#e9e4da", bg: "#2b2a28" },
            ].map((f) => (
              <Link key={f.t} href={f.href} className="group relative block aspect-[16/11] overflow-hidden">
                <div className="absolute inset-0 transition-transform duration-700 group-hover:scale-105">
                  <ProductArt kind={f.kind} hex={f.hex} view="flat" bg={f.bg} alt={f.t} />
                </div>
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/70 to-transparent p-5 text-bone">
                  <p className="display text-[24px]">{f.t}</p>
                  <p className="text-sm opacity-80">{f.s}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </header>
  );
}
