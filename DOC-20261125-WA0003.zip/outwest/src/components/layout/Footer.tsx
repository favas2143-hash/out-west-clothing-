"use client";

import Link from "next/link";
import { useState } from "react";
import { liveCategories } from "@/lib/catalog";
import { Icon } from "@/components/ui/Icon";
import { useStore } from "@/components/providers/StoreProvider";

const IG = process.env.NEXT_PUBLIC_INSTAGRAM_HANDLE || "outwest.in";

export function AnnouncementBar() {
  const { settings } = useStore();
  const items = settings.announcements.length ? settings.announcements : ["Premium streetwear, made in India"];
  return (
    <div className="relative z-50 overflow-hidden bg-ink text-bone">
      <div className="animate-marquee flex w-max py-2.5">
        {[0, 1].map((k) => (
          <div key={k} className="flex shrink-0" aria-hidden={k === 1}>
            {[...items, ...items].map((t, i) => (
              <span key={i} className="flex items-center gap-10 px-5 text-[11px] font-medium uppercase tracking-[0.18em]">
                {t}
                <span className="h-1 w-1 rounded-full bg-bone/50" />
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

export function Newsletter() {
  const { toast } = useStore();
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);
  return (
    <section className="bg-beige">
      <div className="wrap grid items-end gap-8 py-16 md:grid-cols-2 md:py-24">
        <div className="reveal">
          <p className="eyebrow mb-4 text-ash">The OUT WEST list</p>
          <h2 className="display text-[clamp(36px,6vw,72px)]">First to the drop.</h2>
          <p className="mt-4 max-w-md text-ash">Early access to limited releases, restocks and members-only pricing. No spam — just the good stuff.</p>
        </div>
        <form
          className="reveal flex w-full flex-col gap-3 sm:flex-row"
          onSubmit={(e) => {
            e.preventDefault();
            if (!/^\S+@\S+\.\S+$/.test(email)) return toast("Enter a valid email address");
            setDone(true);
            toast("You're on the list", "Use WELCOME10 for 10% off your first order");
            try {
              fetch("/api/newsletter", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ email }) }).catch(() => {});
            } catch {}
          }}
        >
          <label htmlFor="nl-email" className="sr-only">Email address</label>
          <input id="nl-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Your email address" className="field h-14 flex-1 border-ink/20 bg-bone" disabled={done} />
          <button className="btn-dark h-14" disabled={done}>{done ? "Subscribed" : "Join the list"}</button>
        </form>
      </div>
    </section>
  );
}

export function Footer() {
  const { settings } = useStore();
  const CATEGORIES = liveCategories(settings.categories);
  const cols = [
    { t: "Shop", l: [["New In", "/shop?tag=new"], ["Best Sellers", "/shop?tag=bestseller"], ...CATEGORIES.map((c) => [c.name, `/shop?category=${c.slug}`])] },
    { t: "Help", l: [["Track your order", "/track"], ["Shipping & delivery", "/help/shipping"], ["Returns & exchanges", "/help/returns"], ["Size guide", "/help/size-guide"], ["Contact us", "/help/contact"]] },
    { t: "Account", l: [["Sign in", "/account/login"], ["Create account", "/account/register"], ["My orders", "/account"], ["Wishlist", "/wishlist"]] },
  ];
  return (
    <footer className="bg-ink text-bone">
      <div className="wrap grid gap-12 pb-10 pt-16 md:grid-cols-[1.3fr_repeat(3,1fr)] md:pt-20">
        <div>
          <p className="display text-[40px]">OUT WEST</p>
          <p className="mt-4 max-w-xs text-[15px] text-bone/60">Premium streetwear, designed in Bengaluru and made in India. Heavy fabrics, clean lines, built to be worn hard.</p>
          <a href={`https://instagram.com/${IG}`} target="_blank" rel="noreferrer" className="mt-6 inline-flex items-center gap-2 text-sm font-semibold hover:opacity-70">
            <Icon name="instagram" /> @{IG}
          </a>
        </div>
        {cols.map((c) => (
          <div key={c.t}>
            <p className="eyebrow mb-5 text-bone/50">{c.t}</p>
            <ul className="space-y-3 text-[15px]">
              {c.l.map(([label, href]) => (
                <li key={label}><Link href={href} className="text-bone/85 transition hover:text-bone hover:underline hover:underline-offset-4">{label}</Link></li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="wrap flex flex-col gap-4 border-t border-bone/15 py-6 text-[12px] text-bone/50 md:flex-row md:items-center md:justify-between">
        <p>© {new Date().getFullYear()} OUT WEST. All rights reserved.</p>
        <div className="flex flex-wrap items-center gap-x-5 gap-y-2 uppercase tracking-[0.14em]">
          <span className="flex items-center gap-1.5"><Icon name="lock" size={14} /> Secure payments by Razorpay</span>
          <span>UPI</span><span>Visa</span><span>Mastercard</span><span>RuPay</span><span>COD</span>
        </div>
        <div className="flex gap-5">
          <Link href="/help/privacy" className="hover:text-bone">Privacy</Link>
          <Link href="/help/terms" className="hover:text-bone">Terms</Link>
        </div>
      </div>
    </footer>
  );
}
