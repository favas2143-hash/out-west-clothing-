"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useRef, useState } from "react";
import { categoryBySlug, discountPct, stockKey } from "@/lib/catalog";
import { deliveryEstimate, inr } from "@/lib/pricing";
import type { ArtView, Product } from "@/lib/types";
import { Icon } from "@/components/ui/Icon";
import { useStore } from "@/components/providers/StoreProvider";
import { ProductArt } from "./ProductArt";
import { ProductCard } from "./ProductCard";
import { SizeGuide } from "./SizeGuide";

const VIEWS: ArtView[] = ["front", "back", "detail", "flat"];

export function ProductView({ product: p, related, initialColour }: { product: Product; related: Product[]; initialColour?: string }) {
  const router = useRouter();
  const { addToCart, toggleWishlist, wishlist, hydrated, toast, settings } = useStore();
  const [ci, setCi] = useState(Math.max(0, p.colours.findIndex((c) => c.name === initialColour)));
  const [size, setSize] = useState(p.sizes.length === 1 ? p.sizes[0] : "");
  const [qty, setQty] = useState(1);
  const [sizeError, setSizeError] = useState(false);
  const [guide, setGuide] = useState(false);
  const [pin, setPin] = useState("");
  const [eta, setEta] = useState<ReturnType<typeof deliveryEstimate> | "bad" | null>(null);
  const [slide, setSlide] = useState(0);
  const scroller = useRef<HTMLDivElement>(null);

  const colour = p.colours[ci] ?? p.colours[0];
  const off = discountPct(p);
  const stockOf = (s: string) => p.stock[stockKey(colour.name, s)] ?? 0;
  const left = size ? stockOf(size) : 0;
  const saved = hydrated && wishlist.includes(p.id);
  const cat = categoryBySlug(p.category, settings.categories);
  const photos = p.images.length > 0;
  const slides = photos ? p.images : VIEWS;

  const add = (buyNow = false) => {
    if (!size) {
      setSizeError(true);
      document.getElementById("size-picker")?.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
    if (left < qty) return toast("Not enough stock", `Only ${left} left in ${size}`);
    addToCart(
      { productId: p.id, slug: p.slug, name: p.name, kind: p.kind, colour: colour.name, hex: colour.hex, size, qty, price: p.price, mrp: p.mrp, image: p.images[0] },
      { silent: buyNow },
    );
    if (buyNow) router.push("/checkout");
  };

  const share = async () => {
    const url = window.location.href;
    try {
      if (navigator.share) await navigator.share({ title: `${p.name} — OUT WEST`, url });
      else {
        await navigator.clipboard.writeText(url);
        toast("Link copied");
      }
    } catch {
      /* dismissed */
    }
  };

  const go = (i: number) => {
    const el = scroller.current;
    if (el) el.scrollTo({ left: i * el.clientWidth, behavior: "smooth" });
  };

  return (
    <div className="pb-28 lg:pb-0">
      <div className="lg:wrap lg:grid lg:grid-cols-[1.35fr_1fr] lg:gap-12 lg:pt-8">
        {/* Gallery */}
        <div className="relative">
          <div
            ref={scroller}
            onScroll={(e) => setSlide(Math.round(e.currentTarget.scrollLeft / e.currentTarget.clientWidth))}
            className="no-scrollbar flex snap-x snap-mandatory overflow-x-auto lg:grid lg:grid-cols-2 lg:gap-2 lg:overflow-visible"
            aria-label="Product images"
          >
            {slides.map((v, i) => (
              <div key={i} className="aspect-[4/5] w-full shrink-0 snap-center overflow-hidden bg-beige lg:w-auto">
                {photos ? (
                  <ProductArt kind={p.kind} hex={colour.hex} src={v} alt={`${p.name} — image ${i + 1}`} eager={i === 0} />
                ) : (
                  <ProductArt kind={p.kind} hex={colour.hex} view={v as ArtView} alt={`${p.name} in ${colour.name} — ${v} view`} eager={i === 0} className="transition-transform duration-700 hover:scale-[1.03]" />
                )}
              </div>
            ))}
          </div>
          <div className="absolute inset-x-0 bottom-4 flex justify-center gap-1.5 lg:hidden">
            {slides.map((_, i) => (
              <button key={i} aria-label={`Image ${i + 1}`} onClick={() => go(i)} className={`h-1.5 rounded-full transition-all ${slide === i ? "w-6 bg-ink" : "w-1.5 bg-ink/30"}`} />
            ))}
          </div>
          <button onClick={() => toggleWishlist(p.id)} aria-label="Save to wishlist" aria-pressed={saved} className="absolute right-3 top-3 grid h-11 w-11 place-items-center rounded-full bg-bone/80 backdrop-blur lg:hidden">
            <Icon name="heart" fill={saved ? "currentColor" : "none"} />
          </button>
        </div>

        {/* Buy box */}
        <div className="px-4 pt-6 sm:px-6 lg:px-0 lg:pt-0">
          <div className="lg:sticky lg:top-28">
            <nav className="mb-3 text-[12px] text-ash" aria-label="Breadcrumb">
              <Link href="/shop" className="hover:text-ink">Shop</Link> / <Link href={`/shop?category=${p.category}`} className="hover:text-ink">{cat?.name}</Link>
            </nav>
            <div className="flex items-start justify-between gap-4">
              <h1 className="display text-[clamp(30px,3.4vw,46px)]">{p.name}</h1>
              <button onClick={share} aria-label="Share" className="grid h-11 w-11 shrink-0 place-items-center border border-ink/15 hover:border-ink"><Icon name="share" size={18} /></button>
            </div>
            {p.reviews > 0 && (
              <p className="mt-3 flex items-center gap-2 text-[13px]">
                <span className="flex">{[1, 2, 3, 4, 5].map((s) => <Icon key={s} name="star" size={14} fill={s <= Math.round(p.rating) ? "currentColor" : "none"} />)}</span>
                <b>{p.rating.toFixed(1)}</b><span className="text-ash">({p.reviews} reviews)</span>
              </p>
            )}
            <div className="mt-5 flex flex-wrap items-baseline gap-x-3 gap-y-1">
              <span className="text-[24px] font-semibold">{inr(p.price)}</span>
              {off > 0 && <><s className="text-[16px] text-ash">MRP {inr(p.mrp)}</s><span className="bg-ink px-2 py-0.5 text-[12px] font-bold text-bone">{off}% OFF</span></>}
            </div>
            <p className="mt-1 text-[12px] text-ash">Inclusive of all taxes</p>

            <div className="mt-8">
              <p className="label">Colour: <span className="normal-case tracking-normal text-ink">{colour.name}</span></p>
              <div className="flex flex-wrap gap-2">
                {p.colours.map((c, i) => (
                  <button
                    key={c.name}
                    onClick={() => { setCi(i); setSizeError(false); }}
                    aria-label={c.name}
                    aria-pressed={i === ci}
                    className={`relative aspect-[4/5] w-16 overflow-hidden bg-beige ${i === ci ? "ring-2 ring-ink ring-offset-2 ring-offset-bone" : "opacity-80 hover:opacity-100"}`}
                  >
                    <ProductArt kind={p.kind} hex={c.hex} src={p.images[0]} alt="" plain />
                  </button>
                ))}
              </div>
            </div>

            <div id="size-picker" className="mt-7">
              <div className="flex items-center justify-between">
                <p className="label">Size{size && <>: <span className="normal-case tracking-normal text-ink">{size}</span></>}</p>
                {p.sizes.length > 1 && (
                  <button onClick={() => setGuide(true)} className="mb-1.5 flex items-center gap-1.5 text-[12px] underline underline-offset-4"><Icon name="ruler" size={14} /> Size guide</button>
                )}
              </div>
              <div className="grid grid-cols-5 gap-2 sm:grid-cols-6">
                {p.sizes.map((s) => {
                  const n = stockOf(s);
                  return (
                    <button
                      key={s}
                      disabled={n <= 0}
                      onClick={() => { setSize(s); setSizeError(false); setQty(1); }}
                      aria-pressed={size === s}
                      className={`relative h-12 border text-[13px] font-semibold transition ${s === "One Size" ? "col-span-3" : ""} ${
                        size === s ? "border-ink bg-ink text-bone" : "border-ink/15 bg-white hover:border-ink"
                      } disabled:cursor-not-allowed disabled:bg-transparent disabled:text-ash/50 disabled:[background-image:linear-gradient(to_top_right,transparent_calc(50%-0.5px),#a39d92_50%,transparent_calc(50%+0.5px))]`}
                    >
                      {s}
                    </button>
                  );
                })}
              </div>
              {sizeError && <p className="mt-2 text-[13px] font-medium text-sale">Please select a size</p>}
              {size && left > 0 && left <= 5 && <p className="mt-2 text-[13px] font-medium text-sale">Hurry — only {left} left in {size}</p>}
              {p.category === "oversized-t-shirts" && <p className="mt-2 text-[13px] text-ash">Oversized fit. Take your usual size for the intended look.</p>}
            </div>

            <div className="mt-7 flex gap-2">
              <div className="flex h-14 items-center border border-ink/15 bg-white">
                <button aria-label="Decrease quantity" className="grid h-14 w-11 place-items-center" onClick={() => setQty((q) => Math.max(1, q - 1))}><Icon name="minus" size={16} /></button>
                <span className="w-6 text-center font-semibold">{qty}</span>
                <button aria-label="Increase quantity" className="grid h-14 w-11 place-items-center" onClick={() => setQty((q) => Math.min(10, size ? Math.min(left || 10, q + 1) : q + 1))}><Icon name="plus" size={16} /></button>
              </div>
              <button onClick={() => add(false)} className="btn-dark h-14 flex-1">Add to bag</button>
              <button onClick={() => toggleWishlist(p.id)} aria-label="Save to wishlist" aria-pressed={saved} className="hidden h-14 w-14 shrink-0 place-items-center border border-ink/15 hover:border-ink lg:grid">
                <Icon name="heart" fill={saved ? "currentColor" : "none"} />
              </button>
            </div>
            <button onClick={() => add(true)} className="btn-line mt-2 h-14 w-full">Buy it now</button>

            <ul className="mt-6 grid grid-cols-3 gap-2 text-center text-[12px]">
              {[["truck", `Free above ${inr(settings.freeShippingThreshold)}`], ["cash", settings.codEnabled ? "COD available" : "UPI & cards"], ["refresh", "7-day returns"]].map(([i, t]) => (
                <li key={t} className="flex flex-col items-center gap-1.5 bg-beige px-2 py-3"><Icon name={i as "truck"} size={20} /> {t}</li>
              ))}
            </ul>

            <form
              className="mt-6"
              onSubmit={(e) => {
                e.preventDefault();
                setEta(deliveryEstimate(pin) ?? "bad");
              }}
            >
              <label htmlFor="pin" className="label">Check delivery</label>
              <div className="flex">
                <input id="pin" inputMode="numeric" maxLength={6} value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))} placeholder="Enter PIN code" className="field" />
                <button className="btn-dark shrink-0 px-5">Check</button>
              </div>
              {eta === "bad" && <p className="mt-2 text-[13px] text-sale">Enter a valid 6-digit PIN code</p>}
              {eta && eta !== "bad" && <p className="mt-2 text-[13px]">Delivery by <b>{eta.date}</b>{settings.codEnabled ? " · Cash on Delivery available" : ""}</p>}
            </form>

            <div className="mt-6 divide-y divide-ink/10 border-y border-ink/10">
              <Accordion title="Description" open>
                <p>{p.description}</p>
              </Accordion>
              <Accordion title="Fabric & fit">
                <ul className="list-disc space-y-1 pl-5">{p.details.map((d) => <li key={d}>{d}</li>)}</ul>
              </Accordion>
              <Accordion title="Shipping & returns">
                <p>Dispatched within 24 hours. Free shipping above {inr(settings.freeShippingThreshold)}; {inr(settings.shippingFee)} below.{settings.codEnabled ? ` Cash on Delivery available pan-India (${inr(settings.codFee)} handling).` : ""} Easy 7-day returns and size exchanges on unworn items with tags.</p>
              </Accordion>
            </div>
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <section className="wrap py-16 md:py-24">
          <h2 className="display mb-8 text-[clamp(30px,4vw,52px)]">Complete the look</h2>
          <div className="grid grid-cols-2 gap-x-3 gap-y-10 lg:grid-cols-4">
            {related.map((r) => <ProductCard key={r.id} product={r} />)}
          </div>
        </section>
      )}

      {/* Mobile sticky bar */}
      <div className="fixed inset-x-0 bottom-0 z-30 flex items-center gap-3 border-t border-ink/10 bg-bone/95 px-4 pb-[max(12px,env(safe-area-inset-bottom))] pt-3 backdrop-blur lg:hidden">
        <div className="min-w-0 flex-1">
          <p className="truncate text-[13px] font-medium">{colour.name}{size ? ` · ${size}` : ""}</p>
          <p className="text-[15px] font-semibold">{inr(p.price * qty)}</p>
        </div>
        <button onClick={() => add(false)} className="btn-dark flex-1">Add to bag</button>
      </div>

      <SizeGuide open={guide} onClose={() => setGuide(false)} category={p.category} />
    </div>
  );
}

function Accordion({ title, children, open }: { title: string; children: React.ReactNode; open?: boolean }) {
  return (
    <details open={open} className="group">
      <summary className="flex h-14 cursor-pointer list-none items-center justify-between text-[13px] font-semibold uppercase tracking-[0.14em] [&::-webkit-details-marker]:hidden">
        {title}
        <Icon name="plus" size={16} className="transition-transform group-open:rotate-45" />
      </summary>
      <div className="pb-5 text-[15px] leading-relaxed text-ink/75">{children}</div>
    </details>
  );
}
