"use client";

import { useState } from "react";
import { Icon } from "@/components/ui/Icon";

const TOPS: Record<string, { cols: string[]; rows: [string, ...number[]][] }> = {
  regular: {
    cols: ["Size", "Chest", "Length", "Shoulder"],
    rows: [["XS", 36, 26, 16.5], ["S", 38, 27, 17], ["M", 40, 28, 17.5], ["L", 42, 29, 18], ["XL", 44, 30, 18.5], ["XXL", 46, 31, 19]],
  },
  oversized: {
    cols: ["Size", "Chest", "Length", "Shoulder"],
    rows: [["XS", 42, 27, 20], ["S", 44, 28, 21], ["M", 46, 29, 22], ["L", 48, 30, 23], ["XL", 50, 31, 24], ["XXL", 52, 32, 25]],
  },
  pants: {
    cols: ["Size", "Waist", "Hip", "Inseam"],
    rows: [["28", 28, 40, 30], ["30", 30, 42, 30.5], ["32", 32, 44, 31], ["34", 34, 46, 31.5], ["36", 36, 48, 32]],
  },
};

export function SizeGuide({ open, onClose, category, inline }: { open: boolean; onClose: () => void; category: string; inline?: boolean }) {
  const def = category === "pants" ? "pants" : ["oversized-t-shirts", "hoodies", "shirts"].includes(category) ? "oversized" : "regular";
  const [tab, setTab] = useState(def);
  const [unit, setUnit] = useState<"in" | "cm">("in");
  const t = TOPS[tab];
  if (!open) return null;
  const body = (
      <>
        <div className="mb-4 flex flex-wrap gap-2">
          {[["regular", "Regular tees"], ["oversized", "Oversized & hoodies"], ["pants", "Pants"]].map(([k, l]) => (
            <button key={k} onClick={() => setTab(k)} className={`h-9 rounded-full px-4 text-[13px] font-medium ${tab === k ? "bg-ink text-bone" : "border border-ink/15"}`}>{l}</button>
          ))}
          <button onClick={() => setUnit((u) => (u === "in" ? "cm" : "in"))} className="ml-auto h-9 border border-ink/15 px-3 text-[13px] font-semibold">{unit === "in" ? "Inches" : "Centimetres"} ⇄</button>
        </div>
        <table className="w-full text-[14px]">
          <thead>
            <tr className="border-b border-ink">{t.cols.map((c) => <th key={c} className="py-3 text-left font-semibold">{c}</th>)}</tr>
          </thead>
          <tbody>
            {t.rows.map(([s, ...v]) => (
              <tr key={s} className="border-b border-ink/10">
                <td className="py-3 font-semibold">{s}</td>
                {v.map((n, i) => <td key={i} className="py-3 tabular-nums">{unit === "in" ? n : Math.round(n * 2.54)}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
        <p className="mt-4 text-[13px] text-ash">Garment measurements, laid flat and doubled. Between sizes? Size down for a closer fit on oversized styles.</p>
      </>
  );
  if (inline) return <div className="bg-white p-6">{body}</div>;
  return (
    <div className="fixed inset-0 z-50 grid place-items-end sm:place-items-center" role="dialog" aria-modal="true" aria-label="Size guide">
      <div className="absolute inset-0 bg-ink/50" onClick={onClose} />
      <div className="animate-rise relative max-h-[90dvh] w-full overflow-y-auto bg-bone p-6 sm:max-w-xl sm:p-8">
        <div className="mb-6 flex items-center justify-between">
          <h2 className="display text-[30px]">Size guide</h2>
          <button aria-label="Close" onClick={onClose} className="grid h-11 w-11 place-items-center"><Icon name="close" /></button>
        </div>
        {body}
      </div>
    </div>
  );
}
