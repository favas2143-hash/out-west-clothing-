import { garmentSVG } from "@/lib/art";
import type { ArtView, GarmentKind } from "@/lib/types";

/**
 * Product image: shows the uploaded photo when there is one,
 * otherwise the colour-accurate OUT WEST studio render.
 */
export function ProductArt({
  kind,
  hex,
  view = "front",
  src,
  alt,
  bg,
  plain,
  className = "",
  eager,
}: {
  kind: GarmentKind;
  hex: string;
  view?: ArtView;
  src?: string;
  alt: string;
  bg?: string;
  plain?: boolean;
  className?: string;
  eager?: boolean;
}) {
  if (src) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img src={src} alt={alt} loading={eager ? "eager" : "lazy"} className={`h-full w-full object-cover ${className}`} />
    );
  }
  return (
    <div
      role="img"
      aria-label={alt}
      className={`art h-full w-full ${className}`}
      dangerouslySetInnerHTML={{ __html: garmentSVG({ kind, hex, view, bg, plain }) }}
    />
  );
}
