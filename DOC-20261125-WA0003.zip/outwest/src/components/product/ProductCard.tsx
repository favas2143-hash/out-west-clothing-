"use client";

import Link from "next/link";
import { useState } from "react";
import { discountPct, stockKey } from "@/lib/catalog";
import { inr } from "@/lib/pricing";
import type { Product } from "@/lib/types";
import { Icon } from "@/components/ui/Icon";
import { useStore } from "@/components/providers/StoreProvider";
import { ProductArt } from "./ProductArt";

export function ProductCard({ product: p, priority }: { product: Product; priority?: boolean }) {
  const { addToCart, toggleWishlist, wishlist, hydrated, toast } = useStore();
  const [ci, setCi] = useState(0);
  const [picker, setPicker] = useState(false);
  const colour = p.colours[ci] ?? p.colours[0];
  const off = discountPct(p);
  const saved = hydrated && wishlist.includes(p.id);
  const soldOut = p.sizes.every((s) => (p.stock[stockKey(colour.name, s)] ?? 0) <= 0);
  const href = `/product/${p.slug}?colour=${encodeURIComponent(colour.name)}`;

  const add = (size: string) => {
    addToCart({
      productId: p.id,
      slug: p.slug,
      name: p.name,
      kind: p.kind,
      colour: colour.name,
      hex: colour.hex,
      size,
      qty: 1,
      price: p.price,
      mrp: p.mrp,
      image: p.images[0],
    });
    setPicker(false);
    toast("Added to bag", `${p.name} · ${colour.name} · ${size}`);
  };

  return (
    <article className="group relative">
      <div className="relative aspect-[4/5] overflow-hidden bg-beige">
        <Link href={href} className="absolute inset-0" aria-label={p.name}>
          <ProductArt kind={p.kind} hex={colour.hex} src={p.images[0]} alt={`${p.name} in ${colour.name}`} eager={priority} className="transition duration-700 ease-out group-hover:scale-[1.04]" />
          <div className="absolute inset-0 opacity-0 transition-opacity duration-500 [@media(hover:hover)]:group-hover:opacity-100">
            <ProductArt kind={p.kind} hex={colour.hex} src={p.images[1]} view="back" alt="" />
          </div>
        </Link>

        <div className="pointer-events-none absolute left-3 top-3 flex flex-col items-start gap-1.5">
          {p.tags.includes("new") && <span className="bg-bone px-2 py-1 text-[10px] font-bold uppercase tracking-[0.16em]">New</span>}
          {off >= 20 && <span className="bg-ink px-2 py-1 text-[10px] font-bold uppercase tracking-[0.16em] text-bone">−{off}%</span>}
          {soldOut && <span className="bg-ash px-2 py-1 text-[10px] font-bold uppercase tracking-[0.16em] text-bone">Sold out</span>}
        </div>

        <button
          aria-label={saved ? "Remove from wishlist" : "Save to wishlist"}
          aria-pressed={saved}
          onClick={() => toggleWishlist(p.id)}
          className="absolute right-2 top-2 grid h-10 w-10 place-items-center rounded-full transition hover:bg-bone/70"
        >
          <Icon name="heart" size={19} fill={saved ? "currentColor" : "none"} />
        </button>

        {/* quick add */}
        {!soldOut && (
          <>
            <button
              aria-label="Quick add"
              onClick={() => setPicker((v) => !v)}
              className="absolute bottom-2 right-2 grid h-10 w-10 place-items-center rounded-full bg-bone shadow-sm [@media(hover:hover)]:hidden"
            >
              <Icon name={picker ? "close" : "plus"} size={18} />
            </button>
            <div
              className={`absolute inset-x-2 bottom-2 bg-bone/95 p-3 backdrop-blur transition-all duration-300 ${
                picker ? "visible translate-y-0 opacity-100" : "invisible translate-y-3 opacity-0"
              } [@media(hover:hover)]:group-hover:visible [@media(hover:hover)]:group-hover:translate-y-0 [@media(hover:hover)]:group-hover:opacity-100 ${picker ? "mb-12 [@media(hover:hover)]:mb-0" : ""}`}
            >
              <p className="mb-2 text-center text-[10px] font-semibold uppercase tracking-[0.16em] text-ash">Quick add</p>
              <div className="flex flex-wrap justify-center gap-1">
                {p.sizes.map((s) => {
                  const out = (p.stock[stockKey(colour.name, s)] ?? 0) <= 0;
                  return (
                    <button
                      key={s}
                      disabled={out}
                      onClick={() => add(s)}
                      className="h-9 min-w-9 px-2 text-[12px] font-semibold transition hover:bg-ink hover:text-bone disabled:text-ash/50 disabled:line-through disabled:hover:bg-transparent"
                    >
                      {s === "One Size" ? "Add to bag" : s}
                    </button>
                  );
                })}
              </div>
            </div>
          </>
        )}
      </div>

      <div className="mt-3 flex flex-col-reverse gap-2 sm:flex-row sm:items-start sm:justify-between sm:gap-3">
        <Link href={href} className="min-w-0">
          <h3 className="truncate text-[14px] font-medium sm:text-[15px]">{p.name}</h3>
        </Link>
        <div className="-ml-0.5 flex shrink-0 gap-1 sm:ml-0 sm:pt-1">
          {p.colours.map((c, i) => (
            <button
              key={c.name}
              aria-label={c.name}
              title={c.name}
              onClick={() => setCi(i)}
              className={`grid h-5 w-5 place-items-center rounded-full ${i === ci ? "ring-1 ring-ink ring-offset-1 ring-offset-bone" : ""}`}
            >
              <span className="h-3.5 w-3.5 rounded-full border border-ink/20" style={{ background: c.hex }} />
            </button>
          ))}
        </div>
      </div>
      <p className="mt-1 flex flex-wrap items-baseline gap-x-2 text-[14px]">
        <span className="font-semibold">{inr(p.price)}</span>
        {off > 0 && (
          <>
            <s className="text-ash">{inr(p.mrp)}</s>
            <span className="text-[12px] font-semibold text-sale">{off}% off</span>
          </>
        )}
      </p>
    </article>
  );
}
